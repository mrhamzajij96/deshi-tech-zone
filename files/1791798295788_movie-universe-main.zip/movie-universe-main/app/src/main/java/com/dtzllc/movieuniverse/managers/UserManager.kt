package com.dtzllc.movieuniverse.managers

import android.content.Context
import android.util.Log
import com.dtzllc.movieuniverse.models.UserItem
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions

class UserManager private constructor() {

    companion object {
        val instance: UserManager by lazy { UserManager() }
        private const val TAG = "UserManager"
    }

    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private val db: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }

    private var userSnapshotListener: ListenerRegistration? = null
    private var currentUserItem: UserItem? = null
    private val listeners = mutableListOf<(UserItem?) -> Unit>()

    fun registerUserListener(listener: (UserItem?) -> Unit) {
        listeners.add(listener)
        listener(currentUserItem)
    }

    fun unregisterUserListener(listener: (UserItem?) -> Unit) {
        listeners.remove(listener)
    }

    fun getCurrentUser(): UserItem? = currentUserItem

    fun isUserLoggedIn(): Boolean = auth.currentUser != null

    /**
     * Initializes state and listens to real-time user document changes.
     */
    fun initUserSession() {
        val firebaseUser = auth.currentUser
        if (firebaseUser != null) {
            attachFirestoreUserListener(firebaseUser.uid)
        } else {
            currentUserItem = null
            notifyListeners()
        }
    }

    /**
     * Authenticates Firebase using Google IdToken.
     */
    fun authenticateWithFirebaseGoogle(idToken: String, onResult: (Boolean, String?) -> Unit) {
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        auth.signInWithCredential(credential)
            .addOnSuccessListener { authResult ->
                val user = authResult.user
                if (user != null) {
                    syncUserDocument(user) { userItem ->
                        currentUserItem = userItem
                        attachFirestoreUserListener(user.uid)
                        onResult(true, null)
                    }
                } else {
                    onResult(false, "Failed to obtain Firebase User")
                }
            }
            .addOnFailureListener { exception ->
                Log.e(TAG, "Google Auth Failure: ${exception.localizedMessage}", exception)
                onResult(false, exception.localizedMessage)
            }
    }

    private fun syncUserDocument(user: FirebaseUser, onComplete: (UserItem) -> Unit) {
        val userDocRef = db.collection("users").document(user.uid)
        userDocRef.get().addOnSuccessListener { snapshot ->
            if (snapshot.exists()) {
                val existing = snapshot.toObject(UserItem::class.java)
                if (existing != null) {
                    onComplete(existing)
                    return@addOnSuccessListener
                }
            }

            // Create new User Document
            val newUser = UserItem(
                uid = user.uid,
                name = user.displayName ?: "User",
                email = user.email ?: "",
                photoUrl = user.photoUrl?.toString() ?: "",
                isPremium = false,
                watchTimeMinutes = 0L,
                createdAt = System.currentTimeMillis()
            )

            userDocRef.set(newUser, SetOptions.merge())
                .addOnSuccessListener {
                    onComplete(newUser)
                }
                .addOnFailureListener {
                    onComplete(newUser)
                }
        }.addOnFailureListener {
            val fallback = UserItem(
                uid = user.uid,
                name = user.displayName ?: "User",
                email = user.email ?: "",
                photoUrl = user.photoUrl?.toString() ?: ""
            )
            onComplete(fallback)
        }
    }

    private fun attachFirestoreUserListener(uid: String) {
        userSnapshotListener?.remove()
        userSnapshotListener = db.collection("users").document(uid)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "Firestore listen error: ${error.localizedMessage}")
                    return@addSnapshotListener
                }
                if (snapshot != null && snapshot.exists()) {
                    currentUserItem = snapshot.toObject(UserItem::class.java)
                    notifyListeners()
                }
            }
    }

    fun signOut(context: Context, onComplete: () -> Unit) {
        userSnapshotListener?.remove()
        userSnapshotListener = null
        auth.signOut()

        // Google Sign-Out
        try {
            val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).build()
            val client = GoogleSignIn.getClient(context, gso)
            client.signOut().addOnCompleteListener {
                currentUserItem = null
                notifyListeners()
                onComplete()
            }
        } catch (e: Exception) {
            currentUserItem = null
            notifyListeners()
            onComplete()
        }
    }

    private fun notifyListeners() {
        for (listener in listeners) {
            listener(currentUserItem)
        }
    }
}
