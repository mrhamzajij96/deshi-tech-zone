package com.dtzllc.movieuniverse.models

import com.google.firebase.firestore.PropertyName

data class UserItem(
    val uid: String = "",
    val name: String = "Guest User",
    val email: String = "",
    val photoUrl: String = "",
    
    @get:PropertyName("isPremium")
    @set:PropertyName("isPremium")
    var isPremium: Boolean = false,
    
    val watchTimeMinutes: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
)
