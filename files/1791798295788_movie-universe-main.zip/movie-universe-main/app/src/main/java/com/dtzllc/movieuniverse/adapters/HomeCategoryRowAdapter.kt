package com.dtzllc.movieuniverse.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.dtzllc.movieuniverse.R
import com.dtzllc.movieuniverse.models.CategoryRowItem
import com.dtzllc.movieuniverse.models.ContentItem

class HomeCategoryRowAdapter(
    private var rows: List<CategoryRowItem>,
    private var contentsMap: Map<String, List<ContentItem>>,
    private val onMovieClick: (ContentItem) -> Unit,
    private val onViewAllClick: (CategoryRowItem) -> Unit
) : RecyclerView.Adapter<HomeCategoryRowAdapter.RowViewHolder>() {

    fun updateData(newRows: List<CategoryRowItem>, newContentsMap: Map<String, List<ContentItem>>) {
        rows = newRows
        contentsMap = newContentsMap
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_home_category_row, parent, false)
        return RowViewHolder(view)
    }

    override fun onBindViewHolder(holder: RowViewHolder, position: Int) {
        val row = rows[position]
        val movies = contentsMap[row.id] ?: emptyList()
        holder.bind(row, movies)
    }

    override fun getItemCount(): Int = rows.size

    inner class RowViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvRowTitle: TextView = itemView.findViewById(R.id.tvRowTitle)
        private val btnViewAll: LinearLayout = itemView.findViewById(R.id.btnViewAll)
        private val rvHorizontalMovies: RecyclerView = itemView.findViewById(R.id.rvHorizontalMovies)

        fun bind(row: CategoryRowItem, movies: List<ContentItem>) {
            tvRowTitle.text = row.name

            val movieAdapter = HomeMovieAdapter(movies) { content ->
                onMovieClick(content)
            }

            rvHorizontalMovies.layoutManager = LinearLayoutManager(itemView.context, LinearLayoutManager.HORIZONTAL, false)
            rvHorizontalMovies.adapter = movieAdapter

            btnViewAll.setOnClickListener {
                onViewAllClick(row)
            }
        }
    }
}
