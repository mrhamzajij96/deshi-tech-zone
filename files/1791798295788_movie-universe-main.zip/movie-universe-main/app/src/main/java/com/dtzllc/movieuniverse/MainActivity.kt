package com.dtzllc.movieuniverse

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.GravityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.dtzllc.movieuniverse.fragments.ExploreFragment
import com.dtzllc.movieuniverse.fragments.HomeFragment
import com.dtzllc.movieuniverse.fragments.ProfileFragment
import com.dtzllc.movieuniverse.fragments.WatchlistFragment
import com.dtzllc.movieuniverse.managers.UserManager
import com.dtzllc.movieuniverse.models.UserItem
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException

class MainActivity : AppCompatActivity() {

    private lateinit var drawerLayoutMain: DrawerLayout

    // Top Header Views
    private var layoutTopHeaderRoot: View? = null
    private var btnHeaderMenu: ImageView? = null
    private var tvHeaderUniverse: TextView? = null
    private var btnHeaderSearch: ImageView? = null
    private var btnHeaderNotification: FrameLayout? = null
    private var dotNotificationUnread: View? = null

    // Bottom Navigation Views
    private var layoutNavHomePill: LinearLayout? = null
    private var ivNavHomeIcon: ImageView? = null
    private var tvNavHomeText: TextView? = null

    private var layoutNavExplorePill: LinearLayout? = null
    private var ivNavExploreIcon: ImageView? = null
    private var tvNavExploreText: TextView? = null

    private var tabNavCenterPlay: FrameLayout? = null
    private var btnCenterPlayCircle: FrameLayout? = null

    private var layoutNavWatchlistPill: LinearLayout? = null
    private var ivNavWatchlistIcon: ImageView? = null
    private var tvNavWatchlistText: TextView? = null

    private var layoutNavProfilePill: LinearLayout? = null
    private var ivNavProfileIcon: ImageView? = null
    private var tvNavProfileText: TextView? = null

    // Drawer Views & Profile Card
    private var btnDrawerClose: ImageView? = null
    private var tvDrawerUniverse: TextView? = null
    private var cardDrawerUserProfile: LinearLayout? = null
    private var ivDrawerAvatar: ImageView? = null
    private var tvDrawerUserName: TextView? = null
    private var tvDrawerUserEmail: TextView? = null
    private var badgeDrawerPremium: LinearLayout? = null
    private var badgeDrawerFree: TextView? = null
    private var cardDrawerVipBox: LinearLayout? = null

    // Drawer Menu Items & Texts
    private var itemDrawerHome: LinearLayout? = null
    private var tvDrawerHomeText: TextView? = null
    private var itemDrawerExplore: LinearLayout? = null
    private var tvDrawerExploreText: TextView? = null
    private var itemDrawerMovies: LinearLayout? = null
    private var tvDrawerMoviesText: TextView? = null
    private var itemDrawerDrama: LinearLayout? = null
    private var tvDrawerDramaText: TextView? = null
    private var itemDrawerAnime: LinearLayout? = null
    private var tvDrawerAnimeText: TextView? = null
    private var itemDrawerGames: LinearLayout? = null
    private var tvDrawerGamesText: TextView? = null
    private var itemDrawerRequest: LinearLayout? = null
    private var tvDrawerRequestText: TextView? = null
    private var itemDrawerMoreApps: LinearLayout? = null
    private var tvDrawerMoreAppsText: TextView? = null
    private var itemDrawerSettings: LinearLayout? = null
    private var tvDrawerSettingsText: TextView? = null
    private var itemDrawerLogout: LinearLayout? = null

    private lateinit var googleSignInClient: GoogleSignInClient
    private var currentNavIndex = 0

    private val googleSignInLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
            try {
                val account = task.getResult(ApiException::class.java)
                val idToken = account?.idToken
                if (!idToken.isNullOrEmpty()) {
                    authenticateWithFirebase(idToken)
                } else {
                    Toast.makeText(this, "Google Token missing", Toast.LENGTH_SHORT).show()
                }
            } catch (e: ApiException) {
                Toast.makeText(this, "Sign-in error: ${e.statusCode}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            setContentView(R.layout.activity_main)

            initViews()
            applyWindowInsets()
            applyGradientTextShaders()
            setupGoogleSignInClient()
            setupBottomNavListeners()
            setupDrawerListeners()
            setupHeaderListeners()
            setupBackPressHandler()
            observeUserSession()

            if (savedInstanceState == null) {
                loadFragment(HomeFragment())
                updateUnifiedNavigationState(0)
            }

            handleIncomingDeepLink()
        } catch (e: Throwable) {
            e.printStackTrace()
            Toast.makeText(this, "Startup Warning: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun initViews() {
        drawerLayoutMain = findViewById(R.id.drawerLayoutMain)
        drawerLayoutMain.setDrawerShadow(null, GravityCompat.START)

        // Top Header
        val headerView = findViewById<View>(R.id.viewTopHeader) ?: findViewById(R.id.layoutTopHeaderRoot)
        layoutTopHeaderRoot = headerView
        btnHeaderMenu = headerView?.findViewById(R.id.btnHeaderMenu)
        tvHeaderUniverse = headerView?.findViewById(R.id.tvHeaderUniverse)
        btnHeaderSearch = headerView?.findViewById(R.id.btnHeaderSearch)
        btnHeaderNotification = headerView?.findViewById(R.id.btnHeaderNotification)
        dotNotificationUnread = headerView?.findViewById(R.id.dotNotificationUnread)

        // Bottom Nav
        val bottomNavView = findViewById<View>(R.id.viewCustomBottomNav) ?: findViewById(R.id.layoutBottomNavRoot)
        layoutNavHomePill = bottomNavView?.findViewById(R.id.layoutNavHomePill)
        ivNavHomeIcon = bottomNavView?.findViewById(R.id.ivNavHomeIcon)
        tvNavHomeText = bottomNavView?.findViewById(R.id.tvNavHomeText)

        layoutNavExplorePill = bottomNavView?.findViewById(R.id.layoutNavExplorePill)
        ivNavExploreIcon = bottomNavView?.findViewById(R.id.ivNavExploreIcon)
        tvNavExploreText = bottomNavView?.findViewById(R.id.tvNavExploreText)

        tabNavCenterPlay = bottomNavView?.findViewById(R.id.tabNavCenterPlay)
        btnCenterPlayCircle = bottomNavView?.findViewById(R.id.btnCenterPlayCircle)

        layoutNavWatchlistPill = bottomNavView?.findViewById(R.id.layoutNavWatchlistPill)
        ivNavWatchlistIcon = bottomNavView?.findViewById(R.id.ivNavWatchlistIcon)
        tvNavWatchlistText = bottomNavView?.findViewById(R.id.tvNavWatchlistText)

        layoutNavProfilePill = bottomNavView?.findViewById(R.id.layoutNavProfilePill)
        ivNavProfileIcon = bottomNavView?.findViewById(R.id.ivNavProfileIcon)
        tvNavProfileText = bottomNavView?.findViewById(R.id.tvNavProfileText)

        // Navigation Drawer
        val drawerView = findViewById<View>(R.id.viewNavigationDrawer) ?: findViewById(R.id.layoutDrawerRoot)
        btnDrawerClose = drawerView?.findViewById(R.id.btnDrawerClose)
        tvDrawerUniverse = drawerView?.findViewById(R.id.tvDrawerUniverse)
        cardDrawerUserProfile = drawerView?.findViewById(R.id.cardDrawerUserProfile)
        ivDrawerAvatar = drawerView?.findViewById(R.id.ivDrawerAvatar)
        tvDrawerUserName = drawerView?.findViewById(R.id.tvDrawerUserName)
        tvDrawerUserEmail = drawerView?.findViewById(R.id.tvDrawerUserEmail)
        badgeDrawerPremium = drawerView?.findViewById(R.id.badgeDrawerPremium)
        badgeDrawerFree = drawerView?.findViewById(R.id.badgeDrawerFree)
        cardDrawerVipBox = drawerView?.findViewById(R.id.cardDrawerVipBox)

        itemDrawerHome = drawerView?.findViewById(R.id.itemDrawerHome)
        tvDrawerHomeText = drawerView?.findViewById(R.id.tvDrawerHomeText)

        itemDrawerExplore = drawerView?.findViewById(R.id.itemDrawerExplore)
        tvDrawerExploreText = drawerView?.findViewById(R.id.tvDrawerExploreText)

        itemDrawerMovies = drawerView?.findViewById(R.id.itemDrawerMovies)
        tvDrawerMoviesText = drawerView?.findViewById(R.id.tvDrawerMoviesText)

        itemDrawerDrama = drawerView?.findViewById(R.id.itemDrawerDrama)
        tvDrawerDramaText = drawerView?.findViewById(R.id.tvDrawerDramaText)

        itemDrawerAnime = drawerView?.findViewById(R.id.itemDrawerAnime)
        tvDrawerAnimeText = drawerView?.findViewById(R.id.tvDrawerAnimeText)

        itemDrawerGames = drawerView?.findViewById(R.id.itemDrawerGames)
        tvDrawerGamesText = drawerView?.findViewById(R.id.tvDrawerGamesText)

        itemDrawerRequest = drawerView?.findViewById(R.id.itemDrawerRequest)
        tvDrawerRequestText = drawerView?.findViewById(R.id.tvDrawerRequestText)

        itemDrawerMoreApps = drawerView?.findViewById(R.id.itemDrawerMoreApps)
        tvDrawerMoreAppsText = drawerView?.findViewById(R.id.tvDrawerMoreAppsText)

        itemDrawerSettings = drawerView?.findViewById(R.id.itemDrawerSettings)
        tvDrawerSettingsText = drawerView?.findViewById(R.id.tvDrawerSettingsText)

        itemDrawerLogout = drawerView?.findViewById(R.id.itemDrawerLogout)
    }

    private fun applyGradientTextShaders() {
        val startColor = Color.parseColor("#A855F7")
        val endColor = Color.parseColor("#EC4899")

        tvHeaderUniverse?.let { applyGradientToTextView(it, startColor, endColor) }
        tvDrawerUniverse?.let { applyGradientToTextView(it, startColor, endColor) }
    }

    private fun applyGradientToTextView(textView: TextView, startColor: Int, endColor: Int) {
        textView.post {
            val width = textView.paint.measureText(textView.text.toString())
            if (width > 0) {
                val shader = LinearGradient(
                    0f, 0f, width, textView.textSize,
                    startColor, endColor,
                    Shader.TileMode.CLAMP
                )
                textView.paint.shader = shader
                textView.invalidate()
            }
        }
    }

    private fun applyWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layoutMainContent)) { _, insets ->
            val statusBarHeight = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top
            layoutTopHeaderRoot?.setPadding(
                layoutTopHeaderRoot?.paddingLeft ?: 0,
                statusBarHeight + 6,
                layoutTopHeaderRoot?.paddingRight ?: 0,
                layoutTopHeaderRoot?.paddingBottom ?: 0
            )
            insets
        }
    }

    private fun setupGoogleSignInClient() {
        val officialWebClientId = "333190139280-g7o42k0ss3g0nto811dv55gi3nqjgdkh.apps.googleusercontent.com"
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(officialWebClientId)
            .requestEmail()
            .build()
        googleSignInClient = GoogleSignIn.getClient(this, gso)
    }

    private fun observeUserSession() {
        UserManager.instance.initUserSession()
        UserManager.instance.registerUserListener { user ->
            updateDrawerProfileUi(user)
        }
    }

    private fun triggerGoogleSignIn() {
        googleSignInClient.signOut().addOnCompleteListener {
            val signInIntent = googleSignInClient.signInIntent
            googleSignInLauncher.launch(signInIntent)
        }
    }

    private fun authenticateWithFirebase(idToken: String) {
        Toast.makeText(this, "Signing in with Google...", Toast.LENGTH_SHORT).show()
        UserManager.instance.authenticateWithFirebaseGoogle(idToken) { success, errorMsg ->
            if (success) {
                Toast.makeText(this, "Welcome to Movie Universe!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Sign-in failed: $errorMsg", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun updateDrawerProfileUi(user: UserItem?) {
        if (user != null && UserManager.instance.isUserLoggedIn()) {
            tvDrawerUserName?.text = user.name
            tvDrawerUserEmail?.text = user.email

            ivDrawerAvatar?.let {
                if (user.photoUrl.isNotEmpty()) {
                    Glide.with(this)
                        .load(user.photoUrl)
                        .circleCrop()
                        .placeholder(R.drawable.ic_nav_profile)
                        .into(it)
                } else {
                    it.setImageResource(R.drawable.ic_nav_profile)
                }
            }

            if (user.isPremium) {
                badgeDrawerPremium?.visibility = View.VISIBLE
                badgeDrawerFree?.visibility = View.GONE
            } else {
                badgeDrawerPremium?.visibility = View.GONE
                badgeDrawerFree?.visibility = View.VISIBLE
            }
        } else {
            tvDrawerUserName?.text = "Guest User"
            tvDrawerUserEmail?.text = "Tap to sign in with Google"
            ivDrawerAvatar?.setImageResource(R.drawable.ic_nav_profile)
            badgeDrawerPremium?.visibility = View.GONE
            badgeDrawerFree?.visibility = View.GONE
        }
    }

    private fun updateUnifiedNavigationState(selectedIndex: Int) {
        currentNavIndex = selectedIndex

        val activeColor = ContextCompat.getColor(this, R.color.textPrimary)
        val inactiveColor = ContextCompat.getColor(this, R.color.textSecondary)

        btnCenterPlayCircle?.setBackgroundResource(
            if (selectedIndex == 4) R.drawable.bg_center_play_active else R.drawable.bg_center_play_inactive
        )

        layoutNavHomePill?.background = if (selectedIndex == 0) ContextCompat.getDrawable(this, R.drawable.bg_nav_pill_active) else null
        ivNavHomeIcon?.setColorFilter(if (selectedIndex == 0) activeColor else inactiveColor)
        tvNavHomeText?.setTextColor(if (selectedIndex == 0) activeColor else inactiveColor)

        layoutNavExplorePill?.background = if (selectedIndex == 1) ContextCompat.getDrawable(this, R.drawable.bg_nav_pill_active) else null
        ivNavExploreIcon?.setColorFilter(if (selectedIndex == 1) activeColor else inactiveColor)
        tvNavExploreText?.setTextColor(if (selectedIndex == 1) activeColor else inactiveColor)

        layoutNavWatchlistPill?.background = if (selectedIndex == 2) ContextCompat.getDrawable(this, R.drawable.bg_nav_pill_active) else null
        ivNavWatchlistIcon?.setColorFilter(if (selectedIndex == 2) activeColor else inactiveColor)
        tvNavWatchlistText?.setTextColor(if (selectedIndex == 2) activeColor else inactiveColor)

        layoutNavProfilePill?.background = if (selectedIndex == 3) ContextCompat.getDrawable(this, R.drawable.bg_nav_pill_active) else null
        ivNavProfileIcon?.setColorFilter(if (selectedIndex == 3) activeColor else inactiveColor)
        tvNavProfileText?.setTextColor(if (selectedIndex == 3) activeColor else inactiveColor)

        resetDrawerHighlighting()
        when (selectedIndex) {
            0 -> itemDrawerHome?.let { tvDrawerHomeText?.let { t -> highlightDrawerItem(it, t) } }
            1 -> itemDrawerExplore?.let { tvDrawerExploreText?.let { t -> highlightDrawerItem(it, t) } }
            5 -> itemDrawerMovies?.let { tvDrawerMoviesText?.let { t -> highlightDrawerItem(it, t) } }
            6 -> itemDrawerDrama?.let { tvDrawerDramaText?.let { t -> highlightDrawerItem(it, t) } }
            7 -> itemDrawerAnime?.let { tvDrawerAnimeText?.let { t -> highlightDrawerItem(it, t) } }
            8 -> itemDrawerGames?.let { tvDrawerGamesText?.let { t -> highlightDrawerItem(it, t) } }
            9 -> itemDrawerRequest?.let { tvDrawerRequestText?.let { t -> highlightDrawerItem(it, t) } }
            10 -> itemDrawerMoreApps?.let { tvDrawerMoreAppsText?.let { t -> highlightDrawerItem(it, t) } }
            11 -> itemDrawerSettings?.let { tvDrawerSettingsText?.let { t -> highlightDrawerItem(it, t) } }
        }
    }

    private fun resetDrawerHighlighting() {
        val inactiveColor = ContextCompat.getColor(this, R.color.textSecondary)

        itemDrawerHome?.background = null
        tvDrawerHomeText?.setTextColor(inactiveColor)

        itemDrawerExplore?.background = null
        tvDrawerExploreText?.setTextColor(inactiveColor)

        itemDrawerMovies?.background = null
        tvDrawerMoviesText?.setTextColor(inactiveColor)

        itemDrawerDrama?.background = null
        tvDrawerDramaText?.setTextColor(inactiveColor)

        itemDrawerAnime?.background = null
        tvDrawerAnimeText?.setTextColor(inactiveColor)

        itemDrawerGames?.background = null
        tvDrawerGamesText?.setTextColor(inactiveColor)

        itemDrawerRequest?.background = null
        tvDrawerRequestText?.setTextColor(inactiveColor)

        itemDrawerMoreApps?.background = null
        tvDrawerMoreAppsText?.setTextColor(inactiveColor)

        itemDrawerSettings?.background = null
        tvDrawerSettingsText?.setTextColor(inactiveColor)
    }

    private fun highlightDrawerItem(container: LinearLayout, textView: TextView) {
        container.setBackgroundResource(R.drawable.bg_drawer_item_selected)
        textView.setTextColor(ContextCompat.getColor(this, R.color.textPrimary))
    }

    private fun setupBottomNavListeners() {
        findViewById<View>(R.id.tabNavHome)?.setOnClickListener {
            if (currentNavIndex != 0) {
                loadFragment(HomeFragment())
                updateUnifiedNavigationState(0)
            }
        }

        findViewById<View>(R.id.tabNavExplore)?.setOnClickListener {
            if (currentNavIndex != 1) {
                loadFragment(ExploreFragment())
                updateUnifiedNavigationState(1)
            }
        }

        tabNavCenterPlay?.setOnClickListener {
            updateUnifiedNavigationState(4)
            btnCenterPlayCircle?.animate()?.scaleX(0.88f)?.scaleY(0.88f)?.setDuration(120)?.withEndAction {
                btnCenterPlayCircle?.animate()?.scaleX(1.0f)?.scaleY(1.0f)?.setDuration(120)?.start()
            }?.start()
        }

        findViewById<View>(R.id.tabNavWatchlist)?.setOnClickListener {
            if (currentNavIndex != 2) {
                loadFragment(WatchlistFragment())
                updateUnifiedNavigationState(2)
            }
        }

        findViewById<View>(R.id.tabNavProfile)?.setOnClickListener {
            if (currentNavIndex != 3) {
                loadFragment(ProfileFragment())
                updateUnifiedNavigationState(3)
            }
        }
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
            .replace(R.id.navHostContainer, fragment)
            .commitAllowingStateLoss()
    }

    private fun setupDrawerListeners() {
        btnDrawerClose?.setOnClickListener {
            drawerLayoutMain.closeDrawer(GravityCompat.START)
        }

        cardDrawerUserProfile?.setOnClickListener {
            if (!UserManager.instance.isUserLoggedIn()) {
                triggerGoogleSignIn()
            } else {
                drawerLayoutMain.closeDrawer(GravityCompat.START)
                loadFragment(ProfileFragment())
                updateUnifiedNavigationState(3)
            }
        }

        cardDrawerVipBox?.setOnClickListener {
            drawerLayoutMain.closeDrawer(GravityCompat.START)
            Toast.makeText(this, "Movie Universe VIP Hub", Toast.LENGTH_SHORT).show()
        }

        itemDrawerHome?.setOnClickListener {
            drawerLayoutMain.closeDrawer(GravityCompat.START)
            loadFragment(HomeFragment())
            updateUnifiedNavigationState(0)
        }

        itemDrawerExplore?.setOnClickListener {
            drawerLayoutMain.closeDrawer(GravityCompat.START)
            loadFragment(ExploreFragment())
            updateUnifiedNavigationState(1)
        }

        itemDrawerMovies?.setOnClickListener {
            drawerLayoutMain.closeDrawer(GravityCompat.START)
            updateUnifiedNavigationState(5)
        }

        itemDrawerDrama?.setOnClickListener {
            drawerLayoutMain.closeDrawer(GravityCompat.START)
            updateUnifiedNavigationState(6)
        }

        itemDrawerAnime?.setOnClickListener {
            drawerLayoutMain.closeDrawer(GravityCompat.START)
            updateUnifiedNavigationState(7)
        }

        itemDrawerGames?.setOnClickListener {
            drawerLayoutMain.closeDrawer(GravityCompat.START)
            updateUnifiedNavigationState(8)
        }

        itemDrawerRequest?.setOnClickListener {
            drawerLayoutMain.closeDrawer(GravityCompat.START)
            updateUnifiedNavigationState(9)
        }

        itemDrawerMoreApps?.setOnClickListener {
            drawerLayoutMain.closeDrawer(GravityCompat.START)
            updateUnifiedNavigationState(10)
        }

        itemDrawerSettings?.setOnClickListener {
            drawerLayoutMain.closeDrawer(GravityCompat.START)
            updateUnifiedNavigationState(11)
        }

        itemDrawerLogout?.setOnClickListener {
            drawerLayoutMain.closeDrawer(GravityCompat.START)
            UserManager.instance.signOut(this) {
                Toast.makeText(this, "Signed out successfully", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupHeaderListeners() {
        btnHeaderMenu?.setOnClickListener {
            if (!drawerLayoutMain.isDrawerOpen(GravityCompat.START)) {
                drawerLayoutMain.openDrawer(GravityCompat.START)
            }
        }

        btnHeaderSearch?.setOnClickListener {
            Toast.makeText(this, "Search Hub", Toast.LENGTH_SHORT).show()
        }

        btnHeaderNotification?.setOnClickListener {
            dotNotificationUnread?.visibility = View.GONE
            Toast.makeText(this, "Notifications", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupBackPressHandler() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (drawerLayoutMain.isDrawerOpen(GravityCompat.START)) {
                    drawerLayoutMain.closeDrawer(GravityCompat.START)
                } else if (currentNavIndex != 0) {
                    loadFragment(HomeFragment())
                    updateUnifiedNavigationState(0)
                } else {
                    finish()
                }
            }
        })
    }

    private fun handleIncomingDeepLink() {
        val uri: Uri? = intent.data
        if (uri != null && uri.scheme == "https" && uri.host == "movieuniverse.app") {
            val contentId = uri.getQueryParameter("id")
            if (!contentId.isNullOrEmpty()) {
                Toast.makeText(this, "Deep Link ID: $contentId", Toast.LENGTH_LONG).show()
            }
        }
    }
}
