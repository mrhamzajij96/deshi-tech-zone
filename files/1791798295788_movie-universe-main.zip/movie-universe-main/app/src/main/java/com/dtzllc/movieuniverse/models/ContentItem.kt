package com.dtzllc.movieuniverse.models

data class ContentItem(
    val id: String = "",
    val title: String = "",
    val contentType: String = "Movie",
    val maturityRating: String = "Regular",
    val releaseYear: String = "",
    val releaseDate: String = "",
    val duration: String = "",
    val videoQuality: String = "4K Ultra HD",
    val country: Any? = null,
    val rating: Any? = 0.0,
    val ratingCount: Long = 0L,
    val categoryRowIds: Any? = null,
    val categoryRowNames: Any? = null,
    val ottPlatformIds: Any? = null,
    val ottNames: Any? = null,
    val popularCategoryIds: Any? = null,
    val popularCategoryNames: Any? = null,
    val genre: String = "",
    val languages: Any? = null,
    val castIds: Any? = null,
    val directorName: String = "",
    val synopsis: String = "",
    val posterUrl: String = "",
    val bannerUrl: String = "",
    val watchUrl: String = "",
    val downloadUrl: String = "",
    val episodesCount: Any? = 0,
    val viewsCount: Long = 0L,
    val publishedAt: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis()
) {
    fun getRatingDouble(): Double {
        return when (rating) {
            is Number -> rating.toDouble()
            is String -> rating.toDoubleOrNull() ?: 0.0
            else -> 0.0
        }
    }

    fun getEpisodesCountInt(): Int {
        return when (episodesCount) {
            is Number -> episodesCount.toInt()
            is String -> episodesCount.toIntOrNull() ?: 0
            else -> 0
        }
    }

    fun getCategoryRowIdsList(): List<String> {
        return when (categoryRowIds) {
            is List<*> -> categoryRowIds.filterIsInstance<String>()
            is String -> listOf(categoryRowIds)
            else -> emptyList()
        }
    }

    fun getCategoryNamesList(): List<String> {
        return when (popularCategoryNames) {
            is List<*> -> popularCategoryNames.filterIsInstance<String>()
            is String -> listOf(popularCategoryNames)
            else -> emptyList()
        }
    }

    fun getLanguagesList(): List<String> {
        return when (languages) {
            is List<*> -> languages.filterIsInstance<String>()
            is String -> listOf(languages)
            else -> emptyList()
        }
    }
}
