package com.dtzllc.movieuniverse.fragments

import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.dtzllc.movieuniverse.R
import com.dtzllc.movieuniverse.adapters.HeroSliderAdapter
import com.dtzllc.movieuniverse.adapters.HomeCategoryRowAdapter
import com.dtzllc.movieuniverse.models.CategoryRowItem
import com.dtzllc.movieuniverse.models.ContentItem
import com.dtzllc.movieuniverse.models.SliderItem
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class HomeFragment : Fragment() {

    private var vp2HeroSlider: ViewPager2? = null
    private var pbHeroLoading: ProgressBar? = null
    private var layoutSliderDots: LinearLayout? = null
    private var rvCategoryRows: RecyclerView? = null
    private var pbHomeLoading: ProgressBar? = null

    // 6 Quick Category Items
    private var quickItemMovie: LinearLayout? = null
    private var quickItemDrama: LinearLayout? = null
    private var quickItemAnime: LinearLayout? = null
    private var quickItemGames: LinearLayout? = null
    private var quickItemVotes: LinearLayout? = null
    private var quickItemRequest: LinearLayout? = null

    // Adapters & Lists
    private var heroSliderAdapter: HeroSliderAdapter? = null
    private val sliderBannersList = mutableListOf<SliderItem>()

    private var categoryRowAdapter: HomeCategoryRowAdapter? = null
    private val categoryRowsList = mutableListOf<CategoryRowItem>()
    private val contentsMapByRowId = mutableMapOf<String, List<ContentItem>>()

    private val db: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }

    // 4-Second Auto Slider
    private val sliderHandler = Handler(Looper.getMainLooper())
    private val sliderRunnable = object : Runnable {
        override fun run() {
            if (isAdded && sliderBannersList.isNotEmpty()) {
                val slider = vp2HeroSlider ?: return
                val nextItem = (slider.currentItem + 1) % sliderBannersList.size
                slider.setCurrentItem(nextItem, true)
                sliderHandler.postDelayed(this, 4000)
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return try {
            val view = inflater.inflate(R.layout.fragment_home, container, false)
            initViews(view)
            setupHeroSlider()
            setupCategoryRowsRecycler()
            setupQuickActionListeners()
            loadHeroBannersFromFirestore()
            loadCategoryRowsAndMovies()
            view
        } catch (e: Throwable) {
            e.printStackTrace()
            View(requireContext())
        }
    }

    private fun initViews(view: View) {
        vp2HeroSlider = view.findViewById(R.id.vp2HeroSlider)
        pbHeroLoading = view.findViewById(R.id.pbHeroLoading)
        layoutSliderDots = view.findViewById(R.id.layoutSliderDots)
        rvCategoryRows = view.findViewById(R.id.rvCategoryRows)
        pbHomeLoading = view.findViewById(R.id.pbHomeLoading)

        quickItemMovie = view.findViewById(R.id.quickItemMovie)
        quickItemDrama = view.findViewById(R.id.quickItemDrama)
        quickItemAnime = view.findViewById(R.id.quickItemAnime)
        quickItemGames = view.findViewById(R.id.quickItemGames)
        quickItemVotes = view.findViewById(R.id.quickItemVotes)
        quickItemRequest = view.findViewById(R.id.quickItemRequest)
    }

    private fun setupHeroSlider() {
        val slider = vp2HeroSlider ?: return
        heroSliderAdapter = HeroSliderAdapter(sliderBannersList) { sliderItem ->
            if (isAdded) {
                Toast.makeText(requireContext(), "Streaming: ${sliderItem.title}", Toast.LENGTH_SHORT).show()
            }
        }
        slider.adapter = heroSliderAdapter

        slider.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                updateSliderDots(position)
                sliderHandler.removeCallbacks(sliderRunnable)
                sliderHandler.postDelayed(sliderRunnable, 4000)
            }
        })
    }

    private fun loadHeroBannersFromFirestore() {
        pbHeroLoading?.visibility = View.VISIBLE

        db.collection("home_banners")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .limit(10)
            .addSnapshotListener { snapshot, error ->
                if (!isAdded) return@addSnapshotListener
                pbHeroLoading?.visibility = View.GONE
                if (error != null) return@addSnapshotListener

                val banners = snapshot?.documents?.mapNotNull { doc ->
                    try {
                        doc.toObject(SliderItem::class.java)
                    } catch (_: Exception) {
                        null
                    }
                } ?: emptyList()

                sliderBannersList.clear()
                sliderBannersList.addAll(banners)
                heroSliderAdapter?.updateList(sliderBannersList)

                setupSliderDots(sliderBannersList.size)
                startAutoSlider()
            }
    }

    private fun setupSliderDots(count: Int) {
        if (!isAdded) return
        val dotsContainer = layoutSliderDots ?: return
        dotsContainer.removeAllViews()
        if (count <= 1) return

        val safeContext: Context = context ?: return
        for (i in 0 until count) {
            val dot = ImageView(safeContext).apply {
                setImageDrawable(ContextCompat.getDrawable(safeContext, R.drawable.bg_center_play_inactive))
                val params = LinearLayout.LayoutParams(16, 16).apply {
                    setMargins(6, 0, 6, 0)
                }
                layoutParams = params
            }
            dotsContainer.addView(dot)
        }
        updateSliderDots(0)
    }

    private fun updateSliderDots(selectedIndex: Int) {
        if (!isAdded) return
        val dotsContainer = layoutSliderDots ?: return
        val childCount = dotsContainer.childCount
        val safeContext: Context = context ?: return

        for (i in 0 until childCount) {
            val dot = dotsContainer.getChildAt(i) as? ImageView ?: continue
            if (i == selectedIndex) {
                dot.setImageDrawable(ContextCompat.getDrawable(safeContext, R.drawable.bg_center_play_active))
                val params = LinearLayout.LayoutParams(28, 16).apply {
                    setMargins(6, 0, 6, 0)
                }
                dot.layoutParams = params
            } else {
                dot.setImageDrawable(ContextCompat.getDrawable(safeContext, R.drawable.bg_center_play_inactive))
                val params = LinearLayout.LayoutParams(16, 16).apply {
                    setMargins(6, 0, 6, 0)
                }
                dot.layoutParams = params
            }
        }
    }

    private fun startAutoSlider() {
        sliderHandler.removeCallbacks(sliderRunnable)
        if (sliderBannersList.size > 1) {
            sliderHandler.postDelayed(sliderRunnable, 4000)
        }
    }

    private fun setupCategoryRowsRecycler() {
        val recyclerView = rvCategoryRows ?: return
        val ctx = context ?: return

        categoryRowAdapter = HomeCategoryRowAdapter(
            rows = categoryRowsList,
            contentsMap = contentsMapByRowId,
            onMovieClick = { movie ->
                if (isAdded) {
                    Toast.makeText(requireContext(), "Selected: ${movie.title}", Toast.LENGTH_SHORT).show()
                }
            },
            onViewAllClick = { row ->
                if (isAdded) {
                    Toast.makeText(requireContext(), "View All: ${row.name}", Toast.LENGTH_SHORT).show()
                }
            }
        )
        recyclerView.layoutManager = LinearLayoutManager(ctx)
        recyclerView.adapter = categoryRowAdapter
    }

    private fun loadCategoryRowsAndMovies() {
        pbHomeLoading?.visibility = View.VISIBLE

        db.collection("category_rows")
            .orderBy("position", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, error ->
                if (!isAdded) return@addSnapshotListener
                if (error != null) {
                    pbHomeLoading?.visibility = View.GONE
                    return@addSnapshotListener
                }

                val rows = snapshot?.documents?.mapNotNull { doc ->
                    try {
                        doc.toObject(CategoryRowItem::class.java)
                    } catch (_: Exception) {
                        null
                    }
                } ?: emptyList()

                categoryRowsList.clear()
                categoryRowsList.addAll(rows)

                loadContentsForCategoryRows()
            }
    }

    private fun loadContentsForCategoryRows() {
        db.collection("contents")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, error ->
                if (!isAdded) return@addSnapshotListener
                pbHomeLoading?.visibility = View.GONE
                if (error != null) return@addSnapshotListener

                val allContents = snapshot?.documents?.mapNotNull { doc ->
                    try {
                        doc.toObject(ContentItem::class.java)
                    } catch (_: Exception) {
                        null
                    }
                } ?: emptyList()

                contentsMapByRowId.clear()
                for (row in categoryRowsList) {
                    val taggedMovies = allContents.filter { content ->
                        content.getCategoryRowIdsList().contains(row.id)
                    }
                    contentsMapByRowId[row.id] = taggedMovies
                }

                categoryRowAdapter?.updateData(categoryRowsList, contentsMapByRowId)
            }
    }

    private fun setupQuickActionListeners() {
        quickItemMovie?.setOnClickListener {
            if (isAdded) Toast.makeText(requireContext(), "Movies Filter", Toast.LENGTH_SHORT).show()
        }

        quickItemDrama?.setOnClickListener {
            if (isAdded) Toast.makeText(requireContext(), "Drama Series Hub", Toast.LENGTH_SHORT).show()
        }

        quickItemAnime?.setOnClickListener {
            if (isAdded) Toast.makeText(requireContext(), "Anime Universe Hub", Toast.LENGTH_SHORT).show()
        }

        quickItemGames?.setOnClickListener {
            if (isAdded) Toast.makeText(requireContext(), "HTML5 Web Games", Toast.LENGTH_SHORT).show()
        }

        quickItemVotes?.setOnClickListener {
            if (isAdded) Toast.makeText(requireContext(), "Community & Public Votes", Toast.LENGTH_SHORT).show()
        }

        quickItemRequest?.setOnClickListener {
            if (isAdded) Toast.makeText(requireContext(), "Request Movie / Drama", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        startAutoSlider()
    }

    override fun onPause() {
        super.onPause()
        sliderHandler.removeCallbacks(sliderRunnable)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        sliderHandler.removeCallbacks(sliderRunnable)
    }
}
