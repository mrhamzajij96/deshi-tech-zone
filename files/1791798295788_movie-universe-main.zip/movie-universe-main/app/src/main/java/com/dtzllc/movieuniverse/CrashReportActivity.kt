package com.dtzllc.movieuniverse

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class CrashReportActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_crash_report)

        val tvCrashLog = findViewById<TextView>(R.id.tvCrashLog)
        val btnRestart = findViewById<Button>(R.id.btnRestartApp)

        val errorLog = intent.getStringExtra("error_log") ?: "No error stacktrace provided."
        tvCrashLog.text = errorLog

        btnRestart.setOnClickListener {
            val intent = Intent(this, SplashActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            startActivity(intent)
            finish()
        }
    }
}
