package com.dtzllc.movieuniverse.models

data class SliderItem(
    val id: String = "",
    val targetId: String = "",
    val title: String = "",
    val subtitle: String = "",
    val badgeText: String = "POPULAR",
    val bannerUrl: String = "",
    val sliderType: String = "home",
    val createdAt: Long = System.currentTimeMillis()
)
