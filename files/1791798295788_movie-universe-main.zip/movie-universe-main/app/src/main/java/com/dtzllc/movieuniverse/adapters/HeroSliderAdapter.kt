package com.dtzllc.movieuniverse.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dtzllc.movieuniverse.R
import com.dtzllc.movieuniverse.models.SliderItem

class HeroSliderAdapter(
    private var items: List<SliderItem>,
    private val onWatchNowClick: (SliderItem) -> Unit
) : RecyclerView.Adapter<HeroSliderAdapter.SliderViewHolder>() {

    fun updateList(newItems: List<SliderItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SliderViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_hero_slider, parent, false)
        return SliderViewHolder(view)
    }

    override fun onBindViewHolder(holder: SliderViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class SliderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivHeroBackdrop: ImageView = itemView.findViewById(R.id.ivHeroBackdrop)
        private val tvHeroBadge: TextView = itemView.findViewById(R.id.tvHeroBadge)
        private val tvHeroTitle: TextView = itemView.findViewById(R.id.tvHeroTitle)
        private val tvHeroSubtitle: TextView = itemView.findViewById(R.id.tvHeroSubtitle)
        private val btnHeroWatchNow: FrameLayout = itemView.findViewById(R.id.btnHeroWatchNow)

        fun bind(item: SliderItem) {
            tvHeroTitle.text = item.title ?: ""
            tvHeroSubtitle.text = item.subtitle ?: ""

            if (!item.badgeText.isNullOrEmpty()) {
                tvHeroBadge.visibility = View.VISIBLE
                tvHeroBadge.text = item.badgeText.uppercase()
            } else {
                tvHeroBadge.visibility = View.GONE
            }

            Glide.with(itemView.context)
                .load(item.bannerUrl ?: "")
                .placeholder(R.drawable.ic_movie_universe_brand)
                .error(R.drawable.ic_movie_universe_brand)
                .into(ivHeroBackdrop)

            btnHeroWatchNow.setOnClickListener {
                onWatchNowClick(item)
            }
        }
    }
}
