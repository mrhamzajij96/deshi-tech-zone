package com.dtzllc.movieuniverse.utils

import android.content.Context
import android.content.SharedPreferences
import com.dtzllc.movieuniverse.models.UserItem
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

object UserManager {

    private const val PREFS_NAME = "movie_universe_user_prefs"
    private const val KEY_UID = "pref_uid"
    private const val KEY_NAME = "pref_name"
    private const val KEY_EMAIL = "pref_email"
    private const val KEY_PHOTO = "pref_photo"
    private const val KEY_IS_PREMIUM = "pref_is_premium"

    private var currentUser: UserItem? = null
    private var firestoreListener: ListenerRegistration? = null
    private var onProfileUpdatedListener: ((UserItem?) -> Unit)? = null

    fun setProfileUpdateListener(listener: (UserItem?) -> Unit) {
        onProfileUpdatedListener = listener
        listener.invoke(currentUser)
    }

    fun initSession(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val uid = prefs.getString(KEY_UID, null)

        if (!uid.isNullOrEmpty()) {
            currentUser = UserItem(
                uid = uid,
                name = prefs.getString(KEY_NAME, "User") ?: "User",
                email = prefs.getString(KEY_EMAIL, "") ?: "",
                photoUrl = prefs.getString(KEY_PHOTO, "") ?: "",
                isPremium = prefs.getBoolean(KEY_IS_PREMIUM, false)
            )
            onProfileUpdatedListener?.invoke(currentUser)
            listenToUserRealtimeChanges(context, uid)
        }
    }

    fun syncFirebaseUser(
        context: Context,
        uid: String,
        name: String,
        email: String,
        photoUrl: String,
        onComplete: ((UserItem) -> Unit)? = null
    ) {
        val finalName = if (name.isNotEmpty()) name else email.substringBefore("@")
        val initialUser = UserItem(
            uid = uid,
            name = finalName,
            email = email,
            photoUrl = photoUrl,
            isPremium = false
        )

        // Instantly save locally so UI updates in 0.01 seconds without waiting
        saveUserSession(context, initialUser)
        onComplete?.invoke(initialUser)

        // Sync with Cloud Firestore
        val db = FirebaseFirestore.getInstance()
        val userDoc = db.collection("users").document(uid)

        userDoc.get().addOnSuccessListener { snapshot ->
            if (snapshot.exists()) {
                val existingUser = snapshot.toObject(UserItem::class.java)
                if (existingUser != null) {
                    saveUserSession(context, existingUser)
                    listenToUserRealtimeChanges(context, uid)
                    onComplete?.invoke(existingUser)
                }
            } else {
                val newUser = UserItem(
                    uid = uid,
                    name = finalName,
                    email = email,
                    photoUrl = photoUrl,
                    isPremium = false,
                    createdAt = System.currentTimeMillis()
                )
                userDoc.set(newUser).addOnSuccessListener {
                    saveUserSession(context, newUser)
                    listenToUserRealtimeChanges(context, uid)
                    onComplete?.invoke(newUser)
                }
            }
        }.addOnFailureListener {
            // Even if network is slow, local session remains active
            listenToUserRealtimeChanges(context, uid)
        }
    }

    private fun listenToUserRealtimeChanges(context: Context, uid: String) {
        firestoreListener?.remove()
        firestoreListener = FirebaseFirestore.getInstance().collection("users").document(uid)
            .addSnapshotListener { snapshot, error ->
                if (error != null) return@addSnapshotListener
                if (snapshot != null && snapshot.exists()) {
                    val updatedUser = snapshot.toObject(UserItem::class.java)
                    if (updatedUser != null) {
                        saveUserSession(context, updatedUser)
                    }
                }
            }
    }

    private fun saveUserSession(context: Context, user: UserItem) {
        currentUser = user
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_UID, user.uid)
            .putString(KEY_NAME, user.name)
            .putString(KEY_EMAIL, user.email)
            .putString(KEY_PHOTO, user.photoUrl)
            .putBoolean(KEY_IS_PREMIUM, user.isPremium)
            .apply()

        onProfileUpdatedListener?.invoke(user)
    }

    fun clearSession(context: Context) {
        firestoreListener?.remove()
        firestoreListener = null
        currentUser = null

        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().clear().apply()

        onProfileUpdatedListener?.invoke(null)
    }

    fun getCurrentUser(): UserItem? = currentUser

    fun isLoggedIn(): Boolean = currentUser != null
}
