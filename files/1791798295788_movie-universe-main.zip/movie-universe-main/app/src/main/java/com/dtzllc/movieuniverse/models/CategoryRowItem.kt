package com.dtzllc.movieuniverse.models

data class CategoryRowItem(
    val id: String = "",
    val name: String = "",
    val position: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)
