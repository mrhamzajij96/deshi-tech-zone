package com.dtzllc.movieuniverse.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dtzllc.movieuniverse.R
import com.dtzllc.movieuniverse.models.ContentItem

class HomeMovieAdapter(
    private var items: List<ContentItem>,
    private val onMovieClick: (ContentItem) -> Unit
) : RecyclerView.Adapter<HomeMovieAdapter.MovieViewHolder>() {

    fun updateList(newItems: List<ContentItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MovieViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_home_movie_card, parent, false)
        return MovieViewHolder(view)
    }

    override fun onBindViewHolder(holder: MovieViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class MovieViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivCardPoster: ImageView = itemView.findViewById(R.id.ivCardPoster)
        private val tvCardTitle: TextView = itemView.findViewById(R.id.tvCardTitle)
        private val tvCardCategory: TextView = itemView.findViewById(R.id.tvCardCategory)
        private val badgeCard18Plus: TextView = itemView.findViewById(R.id.badgeCard18Plus)
        private val badgeCardNew: TextView = itemView.findViewById(R.id.badgeCardNew)
        private val badgeCardAudio: TextView = itemView.findViewById(R.id.badgeCardAudio)
        private val layoutComingSoonOverlay: FrameLayout = itemView.findViewById(R.id.layoutComingSoonOverlay)

        fun bind(item: ContentItem) {
            tvCardTitle.text = item.title ?: ""

            val categoryList = item.getCategoryNamesList()
            tvCardCategory.text = if (categoryList.isNotEmpty()) categoryList.first() else (item.contentType ?: "")

            // 1. [18+] vs [NEW] Badge Logic
            val maturity = item.maturityRating ?: ""
            if (maturity.contains("18+")) {
                badgeCard18Plus.visibility = View.VISIBLE
                badgeCardNew.visibility = View.GONE
            } else {
                badgeCard18Plus.visibility = View.GONE
                val diffHours = (System.currentTimeMillis() - item.publishedAt) / (1000 * 60 * 60)
                badgeCardNew.visibility = if (diffHours < 72) View.VISIBLE else View.GONE
            }

            // 2. Audio Badge Logic
            val languages = item.getLanguagesList()
            if (languages.size >= 2) {
                badgeCardAudio.visibility = View.VISIBLE
                badgeCardAudio.text = if (languages.size == 2) "Dual Audio" else "Multi Audio"
            } else if (languages.size == 1) {
                badgeCardAudio.visibility = View.VISIBLE
                badgeCardAudio.text = languages.first()
            } else {
                badgeCardAudio.visibility = View.GONE
            }

            // 3. COMING SOON Logic
            val type = item.contentType ?: ""
            val isMovie = (type == "Movie" || type == "Anime Movie")
            val isComingSoon = if (isMovie) item.watchUrl.isNullOrEmpty() else item.getEpisodesCountInt() == 0
            layoutComingSoonOverlay.visibility = if (isComingSoon) View.VISIBLE else View.GONE

            Glide.with(itemView.context)
                .load(item.posterUrl ?: "")
                .placeholder(R.drawable.ic_movie_universe_brand)
                .error(R.drawable.ic_movie_universe_brand)
                .into(ivCardPoster)

            itemView.setOnClickListener {
                onMovieClick(item)
            }
        }
    }
}
