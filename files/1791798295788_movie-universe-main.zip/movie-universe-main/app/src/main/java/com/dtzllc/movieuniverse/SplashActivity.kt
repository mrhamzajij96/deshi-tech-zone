package com.dtzllc.movieuniverse

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {

    private lateinit var ivSplashLogo: ImageView
    private lateinit var ivAmbientGlow: ImageView
    private lateinit var layoutSplashBottomText: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        ivSplashLogo = findViewById(R.id.ivSplashLogo)
        ivAmbientGlow = findViewById(R.id.ivAmbientGlow)
        layoutSplashBottomText = findViewById(R.id.layoutSplashBottomText)

        startCinematicAnimations()

        // Transition to MainActivity after 2.5 seconds
        Handler(Looper.getMainLooper()).postDelayed({
            navigateToMainActivity()
        }, 2500)
    }

    private fun startCinematicAnimations() {
        // 1. Central 3D Logo Pop & Scale Animation with Overshoot Spring
        ivSplashLogo.scaleX = 0f
        ivSplashLogo.scaleY = 0f
        ivSplashLogo.alpha = 0f

        ivAmbientGlow.scaleX = 0f
        ivAmbientGlow.scaleY = 0f
        ivAmbientGlow.alpha = 0f

        ivSplashLogo.animate()
            .scaleX(1f)
            .scaleY(1f)
            .alpha(1f)
            .setDuration(900)
            .setInterpolator(OvershootInterpolator(1.2f))
            .start()

        ivAmbientGlow.animate()
            .scaleX(1f)
            .scaleY(1f)
            .alpha(0.85f)
            .setDuration(1100)
            .start()

        // 2. Bottom Footer Typography Slide Up & Fade In
        layoutSplashBottomText.alpha = 0f
        layoutSplashBottomText.translationY = 40f

        layoutSplashBottomText.animate()
            .alpha(1f)
            .translationY(0f)
            .setStartDelay(350)
            .setDuration(750)
            .start()
    }

    private fun navigateToMainActivity() {
        val intent = Intent(this, MainActivity::class.java)
        intent.data = this.intent.data
        startActivity(intent)
        finish()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }
}
