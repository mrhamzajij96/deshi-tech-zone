package com.dtzllc.movieuniverse

import android.app.Application
import android.content.Intent
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.PersistentCacheSettings

class MovieUniverseApp : Application() {

    override fun onCreate() {
        super.onCreate()
        setupGlobalCrashHandler()
        initializeFirebaseDirectly()
        enableZeroCostPersistentCache()
        initializeAnalytics()
    }

    private fun setupGlobalCrashHandler() {
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            Log.e("FATAL_CRASH", "Crash on ${thread.name}: ${throwable.message}", throwable)
            try {
                val intent = Intent(this, CrashReportActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    putExtra("error_log", Log.getStackTraceString(throwable))
                }
                startActivity(intent)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            android.os.Process.killProcess(android.os.Process.myPid())
            System.exit(10)
        }
    }

    private fun initializeFirebaseDirectly() {
        try {
            if (FirebaseApp.getApps(this).isEmpty()) {
                val options = FirebaseOptions.Builder()
                    .setApplicationId("1:333190139280:android:58f51a6a3a70392717b715")
                    .setApiKey("AIzaSyDyewSWdXgO--rRdYWEl3r3QQGPw1Nehgk")
                    .setProjectId("movie-universe-dtzllc")
                    .setStorageBucket("movie-universe-dtzllc.firebasestorage.app")
                    .setGcmSenderId("333190139280")
                    .build()

                FirebaseApp.initializeApp(this, options)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun enableZeroCostPersistentCache() {
        try {
            val settings = FirebaseFirestoreSettings.Builder()
                .setLocalCacheSettings(
                    PersistentCacheSettings.newBuilder()
                        .setSizeBytes(FirebaseFirestoreSettings.CACHE_SIZE_UNLIMITED)
                        .build()
                )
                .build()

            FirebaseFirestore.getInstance().firestoreSettings = settings
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun initializeAnalytics() {
        try {
            FirebaseAnalytics.getInstance(this)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
