<?php
// OPTIONAL. The whole site works without this file.
// Scanner, Job Match, summary and bullet helpers all run without any API key.
// Only if you want smarter AI wording for summary/bullets, copy this file to
// secrets.php and add an Anthropic API key. Never share secrets.php.
return [
    'anthropic_key' => '',
    'model'         => 'claude-haiku-5-5',
    'daily_limit'   => 40,
    'minute_limit'  => 8,
];
