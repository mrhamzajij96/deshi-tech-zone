<?php
defined('CV_SITE') || exit;
$view      = $view ?? 'home';
$title     = $title ?? SITE_NAME;
$desc      = $desc ?? SITE_DESC;
$bodyClass = 'page-' . $view;
$full      = $title === SITE_NAME ? SITE_NAME : $title . ' | ' . SITE_NAME;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#4f46e5">
<title><?= e($full) ?></title>
<meta name="description" content="<?= e($desc) ?>">
<meta property="og:type" content="website">
<meta property="og:site_name" content="<?= e(SITE_NAME) ?>">
<meta property="og:title" content="<?= e($full) ?>">
<meta property="og:description" content="<?= e($desc) ?>">
<?php if (!empty($noindex)): ?><meta name="robots" content="noindex"><?php endif; ?>
<script>document.documentElement.classList.add('js');try{var s=(JSON.parse(localStorage.getItem('cvmaker.v1')||'{}').settings)||{},t=s.theme||'system';document.documentElement.dataset.theme=t==='system'?(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'):t}catch(e){}</script>
<link rel="icon" type="image/svg+xml" href="assets/img/logo.svg">
<link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
<link rel="stylesheet" href="<?= e(asset('css/site.css')) ?>">
</head>
<body class="<?= e($bodyClass) ?>">
<a class="skip-link" href="#content">Skip to content</a>
<header class="site-header">
  <div class="wrap bar">
    <a class="brand" href="index.php"><img class="logo-img" src="assets/img/logo.svg" alt="" width="36" height="36"><span><?= e(SITE_NAME) ?></span></a>
    <button class="menu-btn" id="menuBtn" aria-expanded="false" aria-controls="mainNav" aria-label="Menu"><span></span><span></span><span></span></button>
    <nav id="mainNav" class="mainnav" aria-label="Main">
      <?php foreach (NAV as $k => $n): ?>
        <a href="<?= e($n[1]) ?>"<?= $view === $k ? ' class="on" aria-current="page"' : '' ?>><?= e($n[0]) ?></a>
      <?php endforeach; ?>
      <a class="btn sm nav-cta" href="builder.php?new=1">Create CV</a>
    </nav>
  </div>
</header>
