<?php
defined('CV_SITE') || exit;
const SITE_NAME = 'CV Maker';
const ADS_ENABLED = true; // false = no ads anywhere
const SITE_DESC = 'Build a professional CV online in minutes. Five clean templates, live A4 preview, AI-assisted wording and one-click PDF export. Your data stays on your device.';
const NAV = [
    'home'      => ['Home',      'index.php'],
    'mycvs'     => ['My CVs',    'my-cvs.php'],
    'templates' => ['Templates', 'templates.php'],
    'scan'      => ['Scan CV',   'scan.php'],
    'match'     => ['Job Match', 'job-match.php'],
    'settings'  => ['Settings',  'settings.php'],
];
function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function asset($f) {
    $p = __DIR__ . '/../assets/' . $f;
    return 'assets/' . $f . '?v=' . (is_file($p) ? filemtime($p) : 1);
}
function js_pages() {
    $m = ['builder' => 'builder.php'];
    foreach (NAV as $k => $v) $m[$k] = $v[1];
    return $m;
}

/* ---- AI (server-side proxy; the key never reaches the browser) ---- */
function ai_config() {
    static $c = null;
    if ($c !== null) return $c;
    $f = __DIR__ . '/secrets.php';
    $s = is_file($f) ? (array)(include $f) : [];
    $c = [
        'key'    => $s['anthropic_key'] ?? (getenv('ANTHROPIC_API_KEY') ?: ''),
        'model'  => $s['model'] ?? 'claude-haiku-5-5',
        'daily'  => (int)($s['daily_limit'] ?? 40),
        'minute' => (int)($s['minute_limit'] ?? 8),
    ];
    return $c;
}
function ai_enabled() { return ai_config()['key'] !== ''; }
