<?php
define('CV_SITE', 1);
require __DIR__ . '/includes/config.php';
$view  = 'home';
$title = SITE_NAME;
$desc  = SITE_DESC;

$features = [
    ['Guided step-by-step builder', 'Personal details, summary, education, experience, skills, projects and more - one clear step at a time.'],
    ['Live A4 preview', 'See every change instantly on a real A4 page, with zoom and multi-page support.'],
    ['Five professional templates', 'Modern, Professional, Creative, Classic and ATS-friendly. Switch any time without losing data.'],
    ['AI-assisted writing', 'Improve, shorten or fix wording. It only rephrases what you wrote and never invents facts.'],
    ['Scan your old CV', 'Upload a photo or PDF of an old CV and get an editable, structured CV in seconds.'],
    ['Match a CV to any job', 'Paste a job description to see your match score, missing keywords and honest improvement tips.'],
    ['Clean PDF export', 'Download an A4 PDF with selectable text and clickable links, ready to send.'],
    ['Private by design', 'Your CVs live in your browser. Export a backup file whenever you like.'],
];
$steps = [
    ['Fill in your details', 'Follow the short guided steps. Add only the sections you need.'],
    ['Pick a template', 'Choose a layout, accent colour, font and spacing. The preview updates live.'],
    ['Export and apply', 'Save as PDF or share as text, then keep improving it later.'],
];
$tpls = [
    ['Modern', 'Bold coloured header'], ['Professional', 'Clean and corporate'], ['Creative', 'Expressive with pills'],
    ['Classic', 'Traditional serif layout'], ['ATS-Friendly', 'Plain, parser-safe format'],
];
$faq = [
    ['How do I get a PDF?', 'Open a CV, go to the last step, choose Download or Print, then pick "Save as PDF". Text stays selectable and links stay clickable.'],
    ['Is my data uploaded?', 'No. CVs are stored in your own browser. Nothing is sent anywhere unless you configure an AI service in Settings.'],
    ['Does the AI invent facts?', 'It is designed only to rephrase what you wrote. Always review suggestions before adding them.'],
    ['Will an ATS-friendly template get me hired?', 'It improves readability for parsers, but no format can guarantee selection.'],
    ['Can I move my CVs to another device?', 'Yes. Export a backup from Settings and import it on the other device.'],
];
require __DIR__ . '/includes/header.php';
?>
<main id="content">
<section class="lp lp-hero">
  <div class="wrap hero-grid">
    <div>
      <span class="pill">Free &middot; No sign-up &middot; Private</span>
      <h1>Create your professional future with a CV that stands out.</h1>
      <p class="lead">Build a clean, modern CV in minutes. Guided steps, live preview, AI-assisted wording and PDF export - all in your browser.</p>
      <div class="cta-row">
        <a class="btn big" href="builder.php?new=1">Create your CV</a>
        <a class="btn big line" href="templates.php">Browse templates</a>
      </div>
    </div>
    <div class="mock" aria-hidden="true">
      <div class="m-head"><i></i><div><b></b><s></s></div></div>
      <span class="m-h"></span><p></p><p></p><p class="short"></p>
      <span class="m-h"></span><p></p><p class="short"></p>
      <span class="m-h"></span><div class="m-chips"><u></u><u></u><u></u><u></u></div>
    </div>
  </div>
</section>

<section class="lp wrap" id="features">
  <h2 class="lp-title">Everything you need to get hired</h2>
  <div class="feat-grid">
    <?php foreach ($features as $f): ?>
      <article class="card feat"><h3><?= e($f[0]) ?></h3><p class="muted"><?= e($f[1]) ?></p></article>
    <?php endforeach; ?>
  </div>
</section>

<section class="lp alt">
  <div class="wrap">
    <h2 class="lp-title">How it works</h2>
    <ol class="steps">
      <?php foreach ($steps as $i => $s): ?>
        <li><span class="num"><?= $i + 1 ?></span><div><h3><?= e($s[0]) ?></h3><p class="muted"><?= e($s[1]) ?></p></div></li>
      <?php endforeach; ?>
    </ol>
  </div>
</section>

<section class="lp wrap">
  <h2 class="lp-title">Templates for every career</h2>
  <div class="tpl-row">
    <?php foreach ($tpls as $t): ?>
      <a class="card tpl" href="templates.php"><b><?= e($t[0]) ?></b><span class="muted"><?= e($t[1]) ?></span></a>
    <?php endforeach; ?>
  </div>
</section>

<section class="lp alt" id="saved">
  <div class="wrap"><h2 class="lp-title" style="margin-bottom:0">Your saved CVs</h2></div>
  <div id="app"></div>
</section>

<section class="lp wrap faq" id="faq">
  <h2 class="lp-title">Frequently asked questions</h2>
  <?php foreach ($faq as $q): ?>
    <details><summary><?= e($q[0]) ?></summary><p><?= e($q[1]) ?></p></details>
  <?php endforeach; ?>
</section>

<section class="lp wrap">
  <div class="cta-band">
    <h2>Ready to build your CV?</h2>
    <p>It takes a few minutes and costs nothing.</p>
    <a class="btn big" href="builder.php?new=1">Get started</a>
  </div>
</section>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
