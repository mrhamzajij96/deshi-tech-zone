<?php
define('CV_SITE', 1);
require __DIR__ . '/includes/config.php';
$view  = 'mycvs';
$title = 'My CVs';
$desc  = 'Manage, edit, duplicate and export every CV you have saved on this device.';
require __DIR__ . '/includes/header.php';
?>
<main id="content"><div id="app"></div></main>
<?php require __DIR__ . '/includes/footer.php'; ?>
