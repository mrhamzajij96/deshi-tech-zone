<?php
define('CV_SITE', 1);
require __DIR__ . '/includes/config.php';
$view  = 'templates';
$title = 'Templates';
$desc  = 'Five professional CV templates - Modern, Professional, Creative, Classic and ATS-friendly.';
require __DIR__ . '/includes/header.php';
?>
<main id="content"><div id="app"></div></main>
<?php require __DIR__ . '/includes/footer.php'; ?>
