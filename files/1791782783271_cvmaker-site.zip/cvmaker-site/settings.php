<?php
define('CV_SITE', 1);
require __DIR__ . '/includes/config.php';
$view  = 'settings';
$title = 'Settings';
$desc  = 'Language, theme, auto-save, backup and privacy settings for CV Maker.';
require __DIR__ . '/includes/header.php';
?>
<main id="content"><div id="app"></div></main>
<?php require __DIR__ . '/includes/footer.php'; ?>
