<?php
define('CV_SITE', 1);
require __DIR__ . '/../includes/config.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

function out($code, $a) { http_response_code($code); echo json_encode($a, JSON_UNESCAPED_UNICODE); exit; }

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') out(405, ['error' => 'method']);
$cfg = ai_config();
if ($cfg['key'] === '') out(503, ['error' => 'ai_disabled']);

// Same-origin only
$o = $_SERVER['HTTP_ORIGIN'] ?? ($_SERVER['HTTP_REFERER'] ?? '');
$host = parse_url('//' . ($_SERVER['HTTP_HOST'] ?? ''), PHP_URL_HOST);
if ($o !== '' && parse_url($o, PHP_URL_HOST) !== $host) out(403, ['error' => 'origin']);

$raw = file_get_contents('php://input', false, null, 0, 30001);
if (strlen($raw) > 30000) out(413, ['error' => 'too_large']);
$in = json_decode($raw, true);
if (!is_array($in)) out(400, ['error' => 'bad_json']);

// Rate limit per IP (per minute + per day)
$ip  = $_SERVER['REMOTE_ADDR'] ?? '0';
$rl  = sys_get_temp_dir() . '/cvm_rl_' . md5($ip) . '.json';
$fh  = fopen($rl, 'c+');
if ($fh && flock($fh, LOCK_EX)) {
    $d = json_decode(stream_get_contents($fh), true) ?: [];
    $now = time(); $day = date('Ymd');
    if (($d['day'] ?? '') !== $day) $d = ['day' => $day, 'n' => 0, 'hits' => []];
    $d['hits'] = array_values(array_filter($d['hits'], fn($t) => $t > $now - 60));
    if ($d['n'] >= $cfg['daily'] || count($d['hits']) >= $cfg['minute']) {
        flock($fh, LOCK_UN); fclose($fh);
        out(429, ['error' => 'rate_limited']);
    }
    $d['n']++; $d['hits'][] = $now;
    ftruncate($fh, 0); rewind($fh); fwrite($fh, json_encode($d)); fflush($fh);
    flock($fh, LOCK_UN);
}
if ($fh) fclose($fh);

function clip($s, $n = 3000) { return mb_substr(trim((string)$s), 0, $n); }
function lst($a, $n = 20) { return is_array($a) ? array_slice(array_map(fn($x) => clip($x, 80), $a), 0, $n) : []; }

$SYS = "You are a careful CV/resume editor. Rules: use ONLY facts present in the input. Never invent employers, dates, numbers, degrees, skills, tools or achievements. "
     . "Write in the same language as the input text (English if there is no text). Output ONLY the final text: no quotes, no preface, no markdown, no explanation.";

$action = $in['action'] ?? '';
$max = 500;
switch ($action) {
    case 'generateSummary':
        $c = $in['context'] ?? [];
        $data = json_encode([
            'title' => clip($c['title'] ?? '', 120), 'skills' => lst($c['skills'] ?? []),
            'roles' => lst($c['roles'] ?? []), 'education' => $c['education'] ?? null,
        ], JSON_UNESCAPED_UNICODE);
        if (empty(json_decode($data, true)['title']) && empty(json_decode($data, true)['skills']) && empty(json_decode($data, true)['roles'])) out(422, ['error' => 'empty']);
        $p = "Write a professional CV summary of 2-3 sentences (max 60 words). Do not use the word \"I\". Avoid clichés. Use only this data:\n" . $data;
        break;
    case 'improveText':
        $t = clip($in['text'] ?? '');
        if ($t === '') out(422, ['error' => 'empty']);
        $mode = $in['mode'] ?? 'improve';
        $rule = [
            'grammar'      => 'Fix only spelling, grammar and punctuation. Do not change the wording or meaning otherwise.',
            'shorten'      => 'Shorten it to at most 55 words while keeping the key points.',
            'professional' => 'Rewrite it in a clear, confident, professional tone. Keep the meaning and a similar length.',
        ][$mode] ?? 'Improve clarity and flow, keeping the meaning and a similar length.';
        $p = $rule . "\n\nText:\n" . $t;
        break;
    case 'improveExperience':
        $t = clip($in['text'] ?? '');
        if ($t === '') out(422, ['error' => 'empty']);
        $p = "Rewrite this as 3-6 concise CV bullet points, one per line, with no bullet symbols or numbering. Start each with a strong action verb. Keep every number and fact exactly; do not add metrics that are not in the text.\n\nText:\n" . $t;
        break;
    case 'improveProject':
        $t = clip($in['text'] ?? '');
        if ($t === '') out(422, ['error' => 'empty']);
        $p = "Rewrite this project description in 1-3 clear, professional sentences. Keep every fact and tool name; add nothing new.\n\nText:\n" . $t;
        break;
    default:
        out(400, ['error' => 'unsupported_action']);
}

$ch = curl_init('https://api.anthropic.com/v1/messages');
curl_setopt_array($ch, [
    CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 25,
    CURLOPT_HTTPHEADER => ['content-type: application/json', 'x-api-key: ' . $cfg['key'], 'anthropic-version: 2023-06-01'],
    CURLOPT_POSTFIELDS => json_encode([
        'model' => $cfg['model'], 'max_tokens' => $max, 'system' => $SYS,
        'messages' => [['role' => 'user', 'content' => $p]],
    ], JSON_UNESCAPED_UNICODE),
]);
$res  = curl_exec($ch);
$code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
if ($res === false || $code !== 200) out(502, ['error' => 'upstream']);

$j = json_decode($res, true);
$text = trim($j['content'][0]['text'] ?? '');
$text = trim($text, "\"'` \n");
if ($action === 'improveExperience') {
    $text = implode("\n", array_filter(array_map(fn($l) => trim(preg_replace('/^\s*(?:[-•*·▪●]+|\d+[.)])\s*/u', '', $l)), explode("\n", $text))));
}
if ($text === '') out(502, ['error' => 'empty_reply']);
out(200, ['text' => $text]);
