/* CV Maker engine - website build */
'use strict';
/* =====================================================================
   CV Maker - single-file offline-first app
   ===================================================================== */

/* ---------- Bengali UI strings (keys are the English UI strings) ---------- */
const BN={
'Home':'হোম','My CVs':'আমার সিভি','Templates':'টেমপ্লেট','Settings':'সেটিংস',
'CV Maker':'সিভি মেকার','Create your professional future.':'গড়ে তুলুন আপনার পেশাদার ভবিষ্যৎ।',
'Create Your Professional CV':'আপনার পেশাদার সিভি তৈরি করুন','Continue Editing':'সম্পাদনা চালিয়ে যান',
'Build. Improve. Export. Get Ready.':'তৈরি করুন। উন্নত করুন। এক্সপোর্ট করুন। প্রস্তুত হোন।',
'Saved CVs':'সংরক্ষিত সিভি','Search CVs':'সিভি খুঁজুন','Last edited':'সর্বশেষ সম্পাদিত','Name (A-Z)':'নাম (A-Z)','Date created':'তৈরির তারিখ',
'No CVs yet':'এখনও কোনো সিভি নেই','Create a professional CV in a few minutes.':'কয়েক মিনিটেই একটি পেশাদার সিভি তৈরি করুন।','Create My CV':'আমার সিভি তৈরি করুন','Try demo CV':'ডেমো সিভি দেখুন',
'No CVs match your search.':'আপনার খোঁজের সাথে কোনো সিভি মেলেনি।','Create New CV':'নতুন সিভি তৈরি করুন',
'Edit':'এডিট','Duplicate':'কপি','Export':'এক্সপোর্ট','Delete':'মুছুন','Edited':'সম্পাদিত','Demo data':'ডেমো ডেটা',
'This is demo data. Edit it or create your own CV.':'এটি ডেমো ডেটা। এডিট করুন বা নিজের সিভি তৈরি করুন।',
'Skip':'বাদ দিন','Next':'পরবর্তী','Get Started':'শুরু করুন','Back':'পিছনে','Save':'সংরক্ষণ','Saved':'সংরক্ষিত হয়েছে',
'Write Better With AI':'এআই দিয়ে আরও ভালো লিখুন','Export & Share':'এক্সপোর্ট ও শেয়ার',
'Fill in simple steps and watch your CV update live with five professional templates.':'সহজ ধাপে তথ্য দিন এবং পাঁচটি পেশাদার টেমপ্লেটে লাইভ সিভি দেখুন।',
'Improve your wording with AI. It only uses what you wrote and never invents facts.':'এআই দিয়ে আপনার লেখা উন্নত করুন। এটি শুধু আপনার দেওয়া তথ্য ব্যবহার করে, নতুন কিছু বানায় না।',
'Download a clean A4 PDF with selectable text and clickable links, then share it.':'নির্বাচনযোগ্য লেখা ও ক্লিকযোগ্য লিংকসহ পরিষ্কার A4 পিডিএফ ডাউনলোড করে শেয়ার করুন।',
'Step':'ধাপ','of':'/',
'Personal':'ব্যক্তিগত','Summary':'সারসংক্ষেপ','Education':'শিক্ষা','Experience':'অভিজ্ঞতা','Skills':'দক্ষতা','Projects':'প্রজেক্ট','Languages':'ভাষা','Certificates':'সনদ','Achievements':'অর্জন','Template':'টেমপ্লেট','Preview':'প্রিভিউ',
'CV Name':'সিভির নাম','Full Name':'পুরো নাম','Professional Title':'পেশাগত পদবি','Phone':'ফোন','Email':'ইমেইল','Location':'ঠিকানা','LinkedIn':'লিংকডইন','GitHub':'গিটহাব','Portfolio':'পোর্টফোলিও','Behance':'বিহান্স','Dribbble':'ড্রিবল','Other link':'অন্য লিংক','Other link label':'অন্য লিংকের নাম',
'Other links':'অন্যান্য লিংক','Camera':'ক্যামেরা','Gallery':'গ্যালারি','Remove photo':'ছবি সরান','Profile Photo':'প্রোফাইল ছবি',
'Please choose an image file.':'অনুগ্রহ করে একটি ছবি বেছে নিন।','Could not load the image.':'ছবিটি লোড করা যায়নি।',
'Full name is required.':'পুরো নাম আবশ্যক।','Enter a valid email address.':'সঠিক ইমেইল ঠিকানা দিন।','Enter a valid phone number.':'সঠিক ফোন নম্বর দিন।','Enter a valid link (e.g. example.com).':'সঠিক লিংক দিন (যেমন example.com)।','Enter a 4-digit year.':'৪ অঙ্কের সাল দিন।',
'Please fix the highlighted fields.':'চিহ্নিত ঘরগুলো ঠিক করুন।',
'Professional Summary':'পেশাগত সারসংক্ষেপ','Write 2-4 sentences about who you are and what you do best.':'আপনি কে এবং কী ভালো পারেন তা ২-৪ বাক্যে লিখুন।',
'Generate Summary':'সারসংক্ষেপ তৈরি','Improve':'উন্নত করুন','Shorten':'ছোট করুন','Make Professional':'পেশাদার করুন','Fix Grammar':'ব্যাকরণ ঠিক করুন',
'AI suggestions should be reviewed before adding them to your CV.':'সিভিতে যোগ করার আগে এআই-এর পরামর্শ যাচাই করে নিন।',
'Add some text first.':'আগে কিছু লিখুন।','Add a job title, skills or experience first, then try again.':'আগে পদবি, দক্ষতা বা অভিজ্ঞতা যোগ করুন, তারপর আবার চেষ্টা করুন।',
'Working...':'কাজ চলছে...','AI suggestion':'এআই পরামর্শ','Current text':'বর্তমান লেখা','Suggestion (you can edit it)':'পরামর্শ (আপনি এডিট করতে পারবেন)','Replace':'প্রতিস্থাপন','Use this':'এটি ব্যবহার করুন','Cancel':'বাতিল','Close':'বন্ধ',
'The AI service could not be reached. Check your connection or try the built-in helper.':'এআই সার্ভিসে সংযোগ করা যায়নি। ইন্টারনেট দেখুন অথবা বিল্ট-ইন সহায়ক ব্যবহার করুন।','Use built-in helper':'বিল্ট-ইন সহায়ক ব্যবহার করুন','You appear to be offline.':'আপনি অফলাইনে আছেন বলে মনে হচ্ছে।',
'Add your degrees, diplomas and courses.':'আপনার ডিগ্রি, ডিপ্লোমা ও কোর্স যোগ করুন।','No education added yet.':'এখনও কোনো শিক্ষা যোগ করা হয়নি।','Add Education':'শিক্ষা যোগ করুন','Degree':'ডিগ্রি','Institution':'প্রতিষ্ঠান','Field of Study':'বিষয়','Start Year':'শুরুর সাল','End Year':'শেষের সাল','GPA / Grade':'জিপিএ / গ্রেড','Description':'বিবরণ',
'Add jobs, internships and volunteer work. Write one point per line.':'চাকরি, ইন্টার্নশিপ ও স্বেচ্ছাসেবা যোগ করুন। প্রতি লাইনে একটি করে পয়েন্ট লিখুন।','No work experience added yet.':'এখনও কোনো কাজের অভিজ্ঞতা যোগ করা হয়নি।','Add Experience':'অভিজ্ঞতা যোগ করুন','Job Title':'পদবি','Company':'কোম্পানি','Start Date':'শুরুর তারিখ','End Date':'শেষের তারিখ','Currently working here':'বর্তমানে এখানে কাজ করছি','Description / Bullets (one per line)':'বিবরণ / পয়েন্ট (প্রতি লাইনে একটি)','Improve Description':'বিবরণ উন্নত করুন',
'Add skill chips. Levels are optional.':'দক্ষতা যোগ করুন। লেভেল ঐচ্ছিক।','No skills added yet.':'এখনও কোনো দক্ষতা যোগ করা হয়নি।','Add a skill':'একটি দক্ষতা লিখুন','Add':'যোগ','No level':'লেভেল নেই','Beginner':'শিক্ষানবিস','Intermediate':'মধ্যম','Advanced':'দক্ষ','Expert':'বিশেষজ্ঞ','Suggest Skills':'দক্ষতার পরামর্শ','Suggested skills':'প্রস্তাবিত দক্ষতা','Only add skills you genuinely have.':'শুধু সেই দক্ষতাই যোগ করুন যা আপনার সত্যিই আছে।','No new suggestions for now. Add a professional title first.':'এখন নতুন কোনো পরামর্শ নেই। আগে পেশাগত পদবি দিন।',
'Add projects you built or contributed to.':'আপনার তৈরি বা অবদান রাখা প্রজেক্ট যোগ করুন।','No projects added yet.':'এখনও কোনো প্রজেক্ট যোগ করা হয়নি।','Add Project':'প্রজেক্ট যোগ করুন','Project':'প্রজেক্ট','Project Name':'প্রজেক্টের নাম','Technologies (comma separated)':'প্রযুক্তি (কমা দিয়ে আলাদা)','Project URL':'প্রজেক্ট লিংক','GitHub URL':'গিটহাব লিংক','Improve Project Description':'প্রজেক্টের বিবরণ উন্নত করুন',
'Add the languages you speak.':'আপনি যে ভাষাগুলো জানেন তা যোগ করুন।','No languages added yet.':'এখনও কোনো ভাষা যোগ করা হয়নি।','Add Language':'ভাষা যোগ করুন','Language':'ভাষা','Proficiency':'দক্ষতার স্তর','Native':'মাতৃভাষা','Fluent':'সাবলীল','Professional':'পেশাদার','Basic':'প্রাথমিক',
'Add licences and certificates with their details.':'সনদ ও সার্টিফিকেট বিস্তারিতসহ যোগ করুন।','No certificates added yet.':'এখনও কোনো সনদ যোগ করা হয়নি।','Add Certificate':'সনদ যোগ করুন','Certificate':'সনদ','Certificate Name':'সনদের নাম','Issuing Organization':'প্রদানকারী প্রতিষ্ঠান','Issue Date':'প্রদানের তারিখ','Credential ID':'ক্রেডেনশিয়াল আইডি','Credential URL':'ক্রেডেনশিয়াল লিংক',
'Add awards, honours and notable results.':'পুরস্কার, সম্মাননা ও উল্লেখযোগ্য ফলাফল যোগ করুন।','No achievements added yet.':'এখনও কোনো অর্জন যোগ করা হয়নি।','Add Achievement':'অর্জন যোগ করুন','Achievement':'অর্জন','Title':'শিরোনাম','Date':'তারিখ',
'Choose a template':'টেমপ্লেট বেছে নিন','Customize':'কাস্টমাইজ','Font style':'ফন্ট স্টাইল','Template default':'টেমপ্লেট অনুযায়ী','Sans-serif':'সানস-সেরিফ','Serif':'সেরিফ','Monospace':'মনোস্পেস','Font size':'ফন্ট সাইজ','Small':'ছোট','Medium':'মাঝারি','Large':'বড়','Section spacing':'সেকশনের ফাঁক','Compact':'ঘন','Normal':'স্বাভাবিক','Relaxed':'ঢিলা','Heading style':'হেডিং স্টাইল','Underline':'আন্ডারলাইন','Plain':'সাধারণ','Side bar':'পাশের বার','Boxed':'বক্স','Show profile photo':'প্রোফাইল ছবি দেখান','Accent color':'অ্যাকসেন্ট রং','Reset':'রিসেট','Show sections':'যে সেকশন দেখাবেন',
'Modern':'মডার্ন','Professional ':'প্রফেশনাল','Creative':'ক্রিয়েটিভ','Classic':'ক্লাসিক','ATS-Friendly':'এটিএস-ফ্রেন্ডলি',
'Bold colored header':'গাঢ় রঙের হেডার','Clean and corporate':'পরিচ্ছন্ন ও কর্পোরেট','Expressive with pills':'পিল স্টাইলের সৃজনশীল ডিজাইন','Traditional serif layout':'ঐতিহ্যবাহী সেরিফ লেআউট','Plain text for recruiter software':'রিক্রুটার সফটওয়্যারের জন্য সাধারণ টেক্সট',
'ATS-friendly formatting can improve readability, but no format can guarantee selection.':'এটিএস-ফ্রেন্ডলি ফরম্যাট পড়তে সুবিধা দিতে পারে, তবে কোনো ফরম্যাটই নির্বাচনের নিশ্চয়তা দেয় না।',
'Live preview':'লাইভ প্রিভিউ','Zoom in':'বড় করুন','Zoom out':'ছোট করুন','Fit width':'প্রস্থ অনুযায়ী','Fit':'ফিট','Previous page':'আগের পৃষ্ঠা','Next page':'পরের পৃষ্ঠা','Full screen':'ফুল স্ক্রিন','Page':'পৃষ্ঠা','pages':'পৃষ্ঠা',
'Generate PDF':'পিডিএফ তৈরি','Download':'ডাউনলোড','Share':'শেয়ার','Print':'প্রিন্ট','AI Resume Assistant':'এআই রিজিউমে সহকারী','File name':'ফাইলের নাম',
'Tip: in the print window choose "Save as PDF". Text stays selectable and links stay clickable.':'টিপ: প্রিন্ট উইন্ডোতে "Save as PDF" বেছে নিন। লেখা নির্বাচনযোগ্য ও লিংক ক্লিকযোগ্য থাকবে।',
'Please enter your full name first.':'আগে আপনার পুরো নাম দিন।','PDF generation failed. Please try again.':'পিডিএফ তৈরি ব্যর্থ হয়েছে। আবার চেষ্টা করুন।','ready':'প্রস্তুত','Choose "Save as PDF" in the print window.':'প্রিন্ট উইন্ডোতে "Save as PDF" বেছে নিন।','Copied to clipboard.':'ক্লিপবোর্ডে কপি হয়েছে।','Could not share.':'শেয়ার করা যায়নি।',
'Improve a section':'একটি অংশ উন্নত করুন','Suggest Resume Keywords':'রিজিউমে কীওয়ার্ডের পরামর্শ','Resume keywords':'রিজিউমে কীওয়ার্ড','Use these only where they truthfully describe your experience.':'এগুলো শুধু সেখানেই ব্যবহার করুন যেখানে তা আপনার অভিজ্ঞতার সাথে সত্যিই মেলে।','Nothing to suggest yet. Add more details first.':'এখনও পরামর্শ দেওয়ার মতো কিছু নেই। আগে আরও তথ্য যোগ করুন।',
'Delete this entry?':'এই এন্ট্রিটি মুছবেন?','Delete this CV?':'এই সিভিটি মুছবেন?','This cannot be undone.':'এটি আর ফেরানো যাবে না।','Save changes?':'পরিবর্তন সংরক্ষণ করবেন?','Discard':'বাতিল করুন','Added.':'যোগ হয়েছে।','Duplicated.':'কপি হয়েছে।','Deleted.':'মুছে ফেলা হয়েছে।',
'Storage is full or unavailable. Your changes may not be saved.':'স্টোরেজ ভরা বা অনুপলব্ধ। আপনার পরিবর্তন সংরক্ষিত নাও হতে পারে।','Could not read saved data.':'সংরক্ষিত ডেটা পড়া যায়নি।','Something went wrong':'কিছু একটা ভুল হয়েছে','Back to Home':'হোমে ফিরুন',
'Set as default':'ডিফল্ট করুন','Default':'ডিফল্ট','Use in my CV':'আমার সিভিতে ব্যবহার করুন','Pick a layout. All templates share the same data, so switching never deletes anything.':'একটি লেআউট বেছে নিন। সব টেমপ্লেট একই ডেটা ব্যবহার করে, তাই বদলালে কিছু মুছে যায় না।','Template applied.':'টেমপ্লেট প্রয়োগ হয়েছে।','Create a CV first to use this template.':'এই টেমপ্লেট ব্যবহার করতে আগে একটি সিভি তৈরি করুন।',
'Language ':'ভাষা','Theme':'থিম','Light':'লাইট','Dark':'ডার্ক','System default':'সিস্টেম ডিফল্ট','Default template':'ডিফল্ট টেমপ্লেট','Auto save':'অটো সেভ','Privacy':'গোপনীয়তা','Help & Support':'সাহায্য ও সহায়তা','About':'সম্পর্কে','Data':'ডেটা','AI service URL (optional)':'এআই সার্ভিস ইউআরএল (ঐচ্ছিক)',
'Your CVs are stored only on this device. When you use an AI feature, only the selected text (plus job titles and skills for summaries) is sent to the AI service you configure. Your name, phone and email are never sent. Never put API keys in this app: use a secure server proxy.':'আপনার সিভি শুধু এই ডিভাইসে সংরক্ষিত থাকে। এআই ফিচার ব্যবহার করলে শুধু নির্বাচিত লেখা (সারসংক্ষেপের জন্য পদবি ও দক্ষতাসহ) আপনার ঠিক করা এআই সার্ভিসে যায়। নাম, ফোন ও ইমেইল কখনো পাঠানো হয় না। এই অ্যাপে কখনো এপিআই কী রাখবেন না: নিরাপদ সার্ভার প্রক্সি ব্যবহার করুন।',
'Without a URL, the built-in offline helper is used.':'ইউআরএল না দিলে বিল্ট-ইন অফলাইন সহায়ক ব্যবহার হবে।','AI service URL must start with https://':'এআই সার্ভিস ইউআরএল https:// দিয়ে শুরু হতে হবে।',
'Add example CVs':'উদাহরণ সিভি যোগ করুন','Export backup':'ব্যাকআপ এক্সপোর্ট','Import backup':'ব্যাকআপ ইমপোর্ট','Delete all data':'সব ডেটা মুছুন','Delete ALL CVs and settings?':'সব সিভি ও সেটিংস মুছবেন?','Example CVs added (demo data).':'উদাহরণ সিভি যোগ হয়েছে (ডেমো ডেটা)।','Backup imported.':'ব্যাকআপ ইমপোর্ট হয়েছে।','Could not import this file.':'এই ফাইল ইমপোর্ট করা যায়নি।','Backup could not be exported.':'ব্যাকআপ এক্সপোর্ট করা যায়নি।',
'Version 1.0 - Build. Improve. Export. Get Ready.':'সংস্করণ ১.০ - তৈরি করুন। উন্নত করুন। এক্সপোর্ট করুন। প্রস্তুত হোন।',
'How do I get a PDF?':'পিডিএফ কীভাবে পাব?','Open a CV, go to the Preview step, tap Download or Print, then choose "Save as PDF".':'একটি সিভি খুলুন, প্রিভিউ ধাপে যান, Download বা Print চাপুন, তারপর "Save as PDF" বেছে নিন।',
'Is my data uploaded?':'আমার ডেটা কি আপলোড হয়?','No. Everything is kept on this device unless you use an AI service you configured.':'না। আপনি নিজে কোনো এআই সার্ভিস সেট না করলে সবকিছু এই ডিভাইসেই থাকে।',
'Does AI invent facts?':'এআই কি তথ্য বানায়?','It is designed to only rephrase what you wrote. Always review suggestions.':'এটি শুধু আপনার লেখা নতুনভাবে সাজায়। পরামর্শ সবসময় যাচাই করুন।',
'Where is Coming Soon?':'কামিং সুন কোথায়?','Cloud backup, sync, online CV links and cover letters are planned for later versions.':'ক্লাউড ব্যাকআপ, সিঙ্ক, অনলাইন সিভি লিংক ও কভার লেটার পরবর্তী সংস্করণে আসছে।',
'Language of your CV content is whatever you type. Section headings in the CV stay in English for ATS compatibility.':'সিভির বিষয়বস্তুর ভাষা আপনি যা লিখবেন তা-ই। এটিএস সামঞ্জস্যের জন্য সিভির সেকশন শিরোনাম ইংরেজিতে থাকে।',
'English':'English','Bengali':'বাংলা','Save before leaving?':'বের হওয়ার আগে সংরক্ষণ করবেন?','Unsaved changes':'অসংরক্ষিত পরিবর্তন','All changes saved':'সব পরিবর্তন সংরক্ষিত','Coming Soon':'শীঘ্রই আসছে'
};
function t(s){return(DB.settings.lang==='bn'&&BN[s])||s}

/* ---------- icons ---------- */
const IC={home:'<path d="M3 11l9-8 9 8M5 10v10h5v-6h4v6h5V10"/>',files:'<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8zM14 3v5h5"/>',layout:'<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/>',settings:'<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1"/>',plus:'<path d="M12 5v14M5 12h14"/>',trash:'<path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/>',copy:'<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h8"/>',edit:'<path d="M12 20h9M16.5 3.5l4 4L8 20l-5 1 1-5z"/>',download:'<path d="M12 3v12M7 10l5 5 5-5M4 21h16"/>',search:'<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',back:'<path d="M15 18l-6-6 6-6"/>',next:'<path d="M9 18l6-6-6-6"/>',spark:'<path d="M12 3l2 5 5 2-5 2-2 5-2-5-5-2 5-2zM19 15l1 2 2 1-2 1-1 2-1-2-2-1 2-1z"/>',x:'<path d="M18 6L6 18M6 6l12 12"/>',zin:'<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3M11 8v6M8 11h6"/>',zout:'<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3M8 11h6"/>',full:'<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',print:'<path d="M6 9V3h12v6M6 18H4v-7h16v7h-2M7 14h10v7H7z"/>',share:'<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4"/>',camera:'<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>',image:'<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/>',file:'<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8zM14 3v5h5M9 13h6M9 17h6"/>'};
const ic=(n,s=20)=>`<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${IC[n]||''}</svg>`;

/* ---------- helpers ---------- */
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,8);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const clone=o=>JSON.parse(JSON.stringify(o));
const getPath=(o,p)=>p.split('.').reduce((a,k)=>a==null?a:a[k],o);
function setPath(o,p,v){const ks=p.split('.');const last=ks.pop();ks.reduce((a,k)=>a[k],o)[last]=v}
const EMAIL=/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const normUrl=u=>{u=(u||'').trim();return !u?'':/^https?:\/\//i.test(u)?u:'https://'+u};
const shortUrl=u=>u.replace(/^https?:\/\/(www\.)?/i,'').replace(/\/$/,'');
function validUrl(u){u=(u||'').trim();if(!u)return true;try{const x=new URL(normUrl(u));return /\./.test(x.hostname)&&!/\s/.test(u)}catch(e){return false}}
function fmtMonth(v){const m=/^(\d{4})-(\d{2})$/.exec(v||'');if(!m)return v||'';return['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][+m[2]-1]+' '+m[1]}
const fmtDay=ms=>new Date(ms).toLocaleDateString(DB.settings.lang==='bn'?'bn-BD':'en-GB',{day:'numeric',month:'short',year:'numeric'});

/* ---------- data model + storage ---------- */
const KEY='cvmaker.v1';
const DB={cvs:[],settings:{lang:'en',theme:'system',defaultTemplate:'modern',autoSave:true,onboarded:false,aiProxy:''}};
const TPL={
  modern:{name:'Modern',desc:'Bold colored header',accent:'#4f46e5'},
  professional:{name:'Professional',desc:'Clean and corporate',accent:'#1e3a5f'},
  creative:{name:'Creative',desc:'Expressive with pills',accent:'#7c3aed'},
  classic:{name:'Classic',desc:'Traditional serif layout',accent:'#111111'},
  ats:{name:'ATS-Friendly',desc:'Plain text for recruiter software',accent:'#000000'}
};
const SECS=[['summary','Summary'],['experience','Experience'],['education','Education'],['projects','Projects'],['skills','Skills'],['certifications','Certificates'],['languages','Languages'],['achievements','Achievements']];
function defaultCustom(){return{font:'auto',size:'medium',spacing:'normal',heading:'default',showPhoto:true,accent:'',sections:{summary:true,experience:true,education:true,projects:true,skills:true,certifications:true,languages:true,achievements:true}}}
function blankCV(){const n=Date.now();return{id:uid(),name:'My CV',createdAt:n,updatedAt:n,demo:false,personalInfo:{fullName:'',title:'',photo:'',phone:'',email:'',location:'',linkedin:'',github:'',portfolio:''},summary:'',education:[],experience:[],skills:[],projects:[],languages:[],certifications:[],achievements:[],socialLinks:{behance:'',dribbble:'',other:'',otherLabel:''},templateId:DB.settings.defaultTemplate||'modern',customization:defaultCustom()}}
function migrate(cv){const b=blankCV();const o={...b,...cv};o.personalInfo={...b.personalInfo,...(cv.personalInfo||{})};o.socialLinks={...b.socialLinks,...(cv.socialLinks||{})};o.customization={...b.customization,...(cv.customization||{}),sections:{...b.customization.sections,...((cv.customization||{}).sections||{})}};['education','experience','skills','projects','languages','certifications','achievements'].forEach(k=>{if(!Array.isArray(o[k]))o[k]=[]});if(!TPL[o.templateId])o.templateId='modern';return o}
function load(){try{const r=localStorage.getItem(KEY);if(r){const d=JSON.parse(r);DB.cvs=Array.isArray(d.cvs)?d.cvs.map(migrate):[];Object.assign(DB.settings,d.settings||{})}}catch(e){setTimeout(()=>toast(t('Could not read saved data.'),'err'),300)}}
function persist(){try{localStorage.setItem(KEY,JSON.stringify(DB));return true}catch(e){toast(t('Storage is full or unavailable. Your changes may not be saved.'),'err');return false}}

/* ---------- state ---------- */
let R={view:'home',step:0,ob:0};
let CUR=null,ERR={},DIRTY=false,Q='',SORT='updated',PENDING=null,CONFIRM=null;
const PV={zoom:1,s:1,pages:[]};
const STEPS=[['personal','Personal'],['summary','Summary'],['education','Education'],['experience','Experience'],['skills','Skills'],['projects','Projects'],['languages','Languages'],['certificates','Certificates'],['achievements','Achievements'],['template','Template'],['preview','Preview']];
const SK_LEVELS=['','Beginner','Intermediate','Advanced','Expert'],LANG_LEVELS=['Native','Fluent','Professional','Intermediate','Basic'];

/* ---------- toast / modal ---------- */
let toastT;
function toast(m,type){const el=$('#toast');el.textContent=m;el.className=type==='err'?'err':'';el.style.display='block';clearTimeout(toastT);toastT=setTimeout(()=>el.style.display='none',3200)}
function openModal(html){$('#modal').innerHTML=`<div class="ov" data-act="ovclick"><div class="sheet" role="dialog" aria-modal="true">${html}</div></div>`}
function closeModal(){$('#modal').innerHTML=''}
function confirmBox(title,sub,okLabel,cb,danger){CONFIRM=cb;openModal(`<h3>${esc(title)}</h3><p class="muted">${esc(sub||'')}</p><div class="row"><button class="btn line" data-act="closeModal">${t('Cancel')}</button><button class="btn ${danger?'danger':''}" data-act="confirmOk">${esc(okLabel)}</button></div>`)}

/* =====================================================================
   CV RENDERING + PAGINATION (shared by thumbnails, preview and PDF)
   ===================================================================== */
function contactItems(cv){const p=cv.personalInfo,s=cv.socialLinks,a=[];
  if(p.phone)a.push(`<a href="tel:${esc(p.phone.replace(/[^\d+]/g,''))}">${esc(p.phone)}</a>`);
  if(p.email)a.push(`<a href="mailto:${esc(p.email)}">${esc(p.email)}</a>`);
  if(p.location)a.push(`<span>${esc(p.location)}</span>`);
  [['linkedin',p.linkedin,'LinkedIn'],['github',p.github,'GitHub'],['portfolio',p.portfolio,'Portfolio'],['behance',s.behance,'Behance'],['dribbble',s.dribbble,'Dribbble'],['other',s.other,s.otherLabel||'Link']].forEach(([k,u,l])=>{if(u&&u.trim()){const n=normUrl(u);a.push(`<a href="${esc(n)}">${esc(l)}: ${esc(shortUrl(n))}</a>`)}});
  return a}
function buildBlocks(cv){
  const p=cv.personalInfo,c=cv.customization,show=c.sections,ats=cv.templateId==='ats',B=[];
  const photo=c.showPhoto&&p.photo&&!ats;
  B.push(`<div class="blk hdr"><div class="hdr-main"><h1>${esc(p.fullName||'Your Name')}</h1>${p.title?`<div class="ttl">${esc(p.title)}</div>`:''}<div class="contact">${contactItems(cv).join('')}</div></div>${photo?`<img class="photo" src="${esc(p.photo)}" alt="">`:''}</div>`);
  const S=(key,title,items)=>{if(!show[key]||!items.length)return;items.forEach((h,i)=>B.push(`<div class="blk">${i===0?`<h2>${title}</h2>`:''}${h}</div>`))};
  const lnk=(u,l)=>{const n=normUrl(u);return n?`<a href="${esc(n)}">${esc(l||shortUrl(n))}</a>`:''};
  S('summary','Professional Summary',cv.summary.trim()?[`<p>${esc(cv.summary.trim()).replace(/\n/g,'<br>')}</p>`]:[]);
  S('experience','Work Experience',cv.experience.filter(e=>e.jobTitle||e.company).map(e=>`<div class="item"><div class="row"><b>${esc(e.jobTitle)}</b><span class="dt">${esc([fmtMonth(e.startDate),e.current?'Present':fmtMonth(e.endDate)].filter(Boolean).join(' – '))}</span></div><div class="sub">${esc([e.company,e.location].filter(Boolean).join(' · '))}</div>${(e.description||[]).length?`<ul>${e.description.map(d=>`<li>${esc(d)}</li>`).join('')}</ul>`:''}</div>`));
  S('education','Education',cv.education.filter(e=>e.degree||e.institution).map(e=>`<div class="item"><div class="row"><b>${esc([e.degree,e.field].filter(Boolean).join(', '))}</b><span class="dt">${esc([e.startDate,e.endDate].filter(Boolean).join(' – '))}</span></div><div class="sub">${esc(e.institution)}${e.grade?` · ${esc(e.grade)}`:''}</div>${e.description?`<p>${esc(e.description)}</p>`:''}</div>`));
  S('projects','Projects',cv.projects.filter(x=>x.name).map(x=>`<div class="item"><div class="row"><b>${esc(x.name)}</b></div>${(x.technologies||[]).length?`<div class="sub">${esc(x.technologies.join(', '))}</div>`:''}${x.description?`<p>${esc(x.description)}</p>`:''}${(x.url||x.githubUrl)?`<div class="links">${[x.url&&lnk(x.url),x.githubUrl&&lnk(x.githubUrl)].filter(Boolean).join(' &nbsp;·&nbsp; ')}</div>`:''}</div>`));
  const sk=cv.skills.filter(s=>s.name);
  S('skills','Skills',sk.length?[ats?`<p>${esc(sk.map(s=>s.name+(s.level?` (${s.level})`:'')).join(', '))}</p>`:`<div class="chips">${sk.map(s=>`<span class="chip">${esc(s.name)}${s.level?` <i>${esc(s.level)}</i>`:''}</span>`).join('')}</div>`]:[]);
  S('certifications','Certifications',cv.certifications.filter(x=>x.name).map(x=>`<div class="item"><div class="row"><b>${esc(x.name)}</b><span class="dt">${esc(fmtMonth(x.issueDate))}</span></div><div class="sub">${esc(x.organization)}${x.credentialId?` · ID: ${esc(x.credentialId)}`:''}</div>${x.credentialUrl?`<div class="links">${lnk(x.credentialUrl)}</div>`:''}</div>`));
  const lg=cv.languages.filter(l=>l.name);
  S('languages','Languages',lg.length?[ats?`<p>${esc(lg.map(l=>l.name+(l.proficiency?` (${l.proficiency})`:'')).join(', '))}</p>`:`<div class="chips">${lg.map(l=>`<span class="chip">${esc(l.name)}${l.proficiency?` <i>${esc(l.proficiency)}</i>`:''}</span>`).join('')}</div>`]:[]);
  S('achievements','Achievements',cv.achievements.filter(a=>a.title).map(a=>`<div class="item"><div class="row"><b>${esc(a.title)}</b><span class="dt">${esc(fmtMonth(a.date))}</span></div>${a.description?`<p>${esc(a.description)}</p>`:''}</div>`));
  return B}
function pageEl(cv){const c=cv.customization,pg=document.createElement('div');
  pg.className=`cvpage t-${cv.templateId} hs-${c.heading||'default'} f-${c.font||'auto'}`;
  pg.style.setProperty('--accent',c.accent||TPL[cv.templateId].accent);
  pg.style.setProperty('--fs',{small:'12px',medium:'13.5px',large:'15px'}[c.size]||'13.5px');
  pg.style.setProperty('--gap',{compact:'12px',normal:'18px',relaxed:'26px'}[c.spacing]||'18px');
  pg.innerHTML='<div class="pg-body"></div>';return pg}
function paginate(cv){
  const host=document.createElement('div');host.className='measure';document.body.appendChild(host);
  const pages=[];let body=null;
  const add=()=>{const pg=pageEl(cv);host.appendChild(pg);pages.push(pg);body=pg.firstChild};
  add();
  buildBlocks(cv).forEach(h=>{const d=document.createElement('div');d.innerHTML=h;const el=d.firstElementChild;body.appendChild(el);
    if(body.scrollHeight>body.clientHeight+1&&body.children.length>1){body.removeChild(el);add();body.appendChild(el)}});
  host.remove();return pages}
const THUMBS=new Map();
function thumbFor(cv,tpl){const c2=tpl?{...cv,templateId:tpl}:cv;const k=`${cv.id}|${cv.updatedAt}|${c2.templateId}`;
  if(!THUMBS.has(k)){if(THUMBS.size>60)THUMBS.clear();THUMBS.set(k,`<div class="thumb"><div class="thumb-in">${paginate(c2)[0].outerHTML}</div></div>`)}
  return THUMBS.get(k)}
function fitThumbs(){$$('.thumb').forEach(th=>{const i=th.firstElementChild;if(i&&th.clientWidth)i.style.transform=`scale(${th.clientWidth/794})`})}

/* =====================================================================
   AI SERVICE (swap the provider by changing AIService._call)
   Secrets never live in this app: set a secure HTTPS proxy in Settings.
   ===================================================================== */
const PHR=[[/\bworked on\b/gi,'contributed to'],[/\bworked with\b/gi,'collaborated with'],[/\bhelped\b/gi,'supported'],[/\blooking for\b/gi,'seeking'],[/\bgood at\b/gi,'proficient in'],[/\ba lot of\b/gi,'numerous'],[/\blots of\b/gi,'numerous'],[/\bvery good\b/gi,'strong'],[/\bin charge of\b/gi,'responsible for'],[/\bstuff\b/gi,'tasks']];
const SHORT=[[/\bin order to\b/gi,'to'],[/\bdue to the fact that\b/gi,'because'],[/\bat this point in time\b/gi,'now'],[/\bas well as\b/gi,'and']];
const FILL=/\b(very|really|just|basically|actually|quite|simply)\s+/gi;
const TYPO={teh:'the',recieve:'receive',experiance:'experience',developement:'development',managment:'management',sucessful:'successful',responsibile:'responsible',knowlege:'knowledge',enviroment:'environment',langauge:'language',definately:'definitely',seperate:'separate',occured:'occurred',acheive:'achieve',adress:'address'};
const cap1=s=>s.charAt(0).toUpperCase()+s.slice(1);
const list=a=>a.length<2?(a[0]||''):a.slice(0,-1).join(', ')+' and '+a[a.length-1];
function fixLine(s){s=s.replace(/\s+/g,' ').trim();
  s=s.replace(/\s+([,;!?])/g,'$1').replace(/([,;!?])(?=[^\s\d=&\/])/g,'$1 ');
  s=s.replace(/[A-Za-z]+/g,w=>TYPO[w.toLowerCase()]||w);
  s=s.replace(/\bi\b(?![.'’])/g,'I');
  return s.replace(/(^|[.!?]\s+)([a-z])/g,(m,a,b)=>a+b.toUpperCase())}
const apply=(s,rules)=>rules.reduce((a,[r,x])=>a.replace(r,x),s);
const STOP=new Set('the and for with from that this have has had are was were will your you our their his her its into over under about than then them they who whom what when where which while been being also such more most other some any all can could would should may might not but out off per via using used use work worked working team teams new skilled experience building improved built made'.split(' '));
const ROLEMAP=[[/flutter/i,['Dart','Firebase','State Management','Material Design']],[/android/i,['Kotlin','Java','Android SDK','Jetpack Compose']],[/web|front.?end/i,['HTML','CSS','JavaScript','Responsive Design']],[/back.?end|server/i,['REST APIs','Databases','Authentication']],[/dev|engineer|program|software/i,['Git','REST APIs','Problem Solving','Debugging','Unit Testing','Agile','SQL','Data Structures']],[/design/i,['Figma','Typography','Prototyping','User Research']],[/data|analyst/i,['SQL','Python','Excel','Data Visualization']],[/market|seo|social/i,['SEO','Content Strategy','Analytics','Social Media']],[/account|financ|bookkeep/i,['Excel','Bookkeeping','Financial Reporting']],[/teach|tutor|educat/i,['Lesson Planning','Classroom Management','Communication']],[/student|intern|fresher|graduate/i,['Communication','Teamwork','Time Management','Microsoft Office','Research']],[/freelanc/i,['Client Communication','Time Management','Project Management','Proposal Writing']]];
const Local={
  improveText({text,mode}){let out=text.split('\n').map(fixLine);
    if(mode==='professional'||mode==='improve')out=out.map(l=>apply(l,PHR));
    if(mode==='shorten')out=out.map(l=>apply(l.replace(FILL,''),SHORT));
    out=out.map(l=>l.replace(/(^|[.!?]\s+)([a-z])/g,(m,a,b)=>a+b.toUpperCase()));
    let r=out.join('\n').trim();
    if(mode==='shorten'&&r.length>320){const ss=r.match(/[^.!?]+[.!?]*/g)||[r];let acc='';for(const s of ss){if(acc&&(acc+s).length>300)break;acc+=s}r=acc.trim()}
    if(r&&!r.includes('\n')&&!/[.!?]$/.test(r))r+='.';return r},
  improveExperience({text}){return text.split(/\n+/).flatMap(l=>l.split(/(?<=[.!?])\s+(?=[A-Z])/)).map(l=>l.replace(/^\s*(?:[-•*·▪●]+|\d+[.)])\s+/,'').trim()).filter(Boolean).map(l=>{l=apply(fixLine(l),PHR);l=l.replace(/^I\s+(?:am|was)\s+/i,'').replace(/^I\s+/,'').replace(/\.+$/,'');return cap1(l)}).join('\n')},
  improveProject({text}){return Local.improveText({text,mode:'professional'})},
  generateSummary({context:c}){const parts=[];
    if(c.title)parts.push(`${cap1(c.title)}${c.roles.length?` with experience as ${list(c.roles.slice(0,3))}`:''}.`);
    else if(c.roles.length)parts.push(`Professional with experience as ${list(c.roles.slice(0,3))}.`);
    if(c.skills.length)parts.push(`Skilled in ${list(c.skills.slice(0,6))}.`);
    if(c.education&&(c.education.degree||c.education.institution))parts.push(`Holds ${c.education.degree||'a qualification'}${c.education.field&&!(c.education.degree||'').toLowerCase().includes(c.education.field.toLowerCase())?` in ${c.education.field}`:''}${c.education.institution?` from ${c.education.institution}`:''}.`);
    if(!parts.length)throw new Error('empty');return parts.join(' ')},
  suggestSkills({context:c}){const hay=[c.title,...c.roles,...c.skills].join(' ');const have=new Set(c.skills.map(s=>s.toLowerCase()));const out=[];
    ROLEMAP.forEach(([re,arr])=>{if(re.test(hay))arr.forEach(s=>{if(!have.has(s.toLowerCase())&&!out.includes(s))out.push(s)})});return out.slice(0,12)},
  suggestKeywords({context:c}){const freq={};c.text.toLowerCase().replace(/[^a-z0-9+#.\s-]/g,' ').split(/\s+/).forEach(w=>{w=w.replace(/^[.-]+|[.-]+$/g,'');if(w.length>3&&!STOP.has(w)&&!/^\d+$/.test(w))freq[w]=(freq[w]||0)+1});
    const top=Object.entries(freq).sort((a,b)=>b[1]-a[1]).slice(0,12).map(e=>cap1(e[0]));return[...new Set([...c.skills,...top])].slice(0,16)}
};
const AIService={
  async _call(action,payload,forceLocal){
    const url=DB.settings.aiProxy||SITE.ai;
    if(url&&!forceLocal){if(!navigator.onLine)throw new Error('offline');
      const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,...payload})});
      if(!r.ok)throw new Error('http');const j=await r.json();
      if(typeof j.text==='string')return j.text;if(Array.isArray(j.items))return j.items;throw new Error('bad')}
    return Local[action](payload)},
  generateSummary(context,f){return this._call('generateSummary',{context},f)},
  improveText(text,mode,f){return this._call('improveText',{text,mode},f)},
  improveExperience(text,f){return this._call('improveExperience',{text},f)},
  improveProject(text,f){return this._call('improveProject',{text},f)},
  suggestSkills(context,f){return this._call('suggestSkills',{context},f)},
  suggestKeywords(context,f){return this._call('suggestKeywords',{context},f)}
};
function aiContext(){const c=CUR;return{title:c.personalInfo.title.trim(),skills:c.skills.map(s=>s.name).filter(Boolean),roles:c.experience.map(e=>e.jobTitle).filter(Boolean),education:c.education[0]?{degree:c.education[0].degree,field:c.education[0].field,institution:c.education[0].institution}:null,
  text:[c.personalInfo.title,c.summary,...c.experience.flatMap(e=>[e.jobTitle,...(e.description||[])]),...c.projects.flatMap(p=>[p.description,...(p.technologies||[])])].join(' ')}}
const readText=p=>{const v=getPath(CUR,p);return Array.isArray(v)?v.join('\n'):(v||'')};
function callAI(kind,path,cur,force){
  if(kind==='gen')return AIService.generateSummary(aiContext(),force);
  if(kind==='improve'&&path.startsWith('experience'))return AIService.improveExperience(cur,force);
  if(kind==='improve'&&path.startsWith('projects'))return AIService.improveProject(cur,force);
  return AIService.improveText(cur,kind,force)}
async function runAI(kind,path,force){
  const cur=readText(path);
  if(kind!=='gen'&&!cur.trim()){toast(t('Add some text first.'),'err');return}
  openModal(`<h3>${t('AI suggestion')}</h3><div class="spin" aria-label="${t('Working...')}"></div><p class="muted" style="text-align:center">${t('Working...')}</p>`);
  try{const out=await callAI(kind,path,cur,force);PENDING={path};
    openModal(`<h3>${t('AI suggestion')}</h3><div class="note">${t('AI suggestions should be reviewed before adding them to your CV.')}</div>${cur?`<label class="muted">${t('Current text')}</label><div class="orig">${esc(cur)}</div>`:''}<label class="muted" for="aiOut">${t('Suggestion (you can edit it)')}</label><textarea id="aiOut" rows="7">${esc(out)}</textarea><div class="row"><button class="btn line" data-act="closeModal">${t('Cancel')}</button><button class="btn" data-act="aiApply">${cur?t('Replace'):t('Use this')}</button></div>`)}
  catch(e){closeModal();
    if(e.message==='empty'){toast(t('Add a job title, skills or experience first, then try again.'),'err');return}
    const msg=e.message==='offline'?t('You appear to be offline.'):t('The AI service could not be reached. Check your connection or try the built-in helper.');
    openModal(`<h3>${t('AI suggestion')}</h3><p>${esc(msg)}</p><div class="row"><button class="btn line" data-act="closeModal">${t('Close')}</button><button class="btn" data-act="aiLocal" data-arg="${kind}|${path}">${t('Use built-in helper')}</button></div>`)}}

/* =====================================================================
   VALIDATION
   ===================================================================== */
const URLK=['linkedin','github','portfolio','behance','dribbble','other','url','githubUrl','credentialUrl'];
function validate(path,val){const k=path.split('.').pop();
  if(path==='personalInfo.fullName')return String(val).trim()?'':t('Full name is required.');
  const v=String(val==null?'':val).trim();if(!v)return'';
  if(k==='email')return EMAIL.test(v)?'':t('Enter a valid email address.');
  if(k==='phone'){const d=v.replace(/\D/g,'');return /^[+\d\s\-()]+$/.test(v)&&d.length>=7&&d.length<=15?'':t('Enter a valid phone number.')}
  if(URLK.includes(k))return validUrl(v)?'':t('Enter a valid link (e.g. example.com).');
  if(path.startsWith('education.')&&(k==='startDate'||k==='endDate'))return /^(19|20)\d{2}$/.test(v)?'':t('Enter a 4-digit year.');
  return''}
function collectErrors(cv){const E={};const chk=p=>{const m=validate(p,getPath(cv,p));if(m)E[p]=m};
  Object.keys(cv.personalInfo).forEach(k=>{if(k!=='photo')chk('personalInfo.'+k)});
  ['behance','dribbble','other'].forEach(k=>chk('socialLinks.'+k));
  cv.education.forEach((_,i)=>['startDate','endDate'].forEach(k=>chk(`education.${i}.${k}`)));
  cv.projects.forEach((_,i)=>['url','githubUrl'].forEach(k=>chk(`projects.${i}.${k}`)));
  cv.certifications.forEach((_,i)=>chk(`certifications.${i}.credentialUrl`));
  return E}
const STEP_PREFIX={personal:['personalInfo.','socialLinks.'],education:['education.'],projects:['projects.'],certificates:['certifications.']};

/* =====================================================================
   FORM FIELDS
   ===================================================================== */
function field(path,label,o={}){
  const v=getPath(CUR,path),err=ERR[path],id='f_'+path.replace(/\./g,'_'),type=o.type||'text',dis=o.disabled?' disabled':'';
  const base=`id="${id}" data-path="${path}"${dis}`;let input;
  if(type==='textarea')input=`<textarea ${base} rows="${o.rows||4}" placeholder="${esc(t(o.ph||''))}">${esc(v)}</textarea>`;
  else if(type==='bullets')input=`<textarea ${base} data-kind="bullets" rows="5" placeholder="${esc(t(o.ph||''))}">${esc((v||[]).join('\n'))}</textarea>`;
  else if(type==='csv')input=`<input ${base} data-kind="csv" value="${esc((v||[]).join(', '))}" placeholder="${esc(o.ph||'')}">`;
  else if(type==='select')input=`<select ${base}>${o.options.map(([val,lab])=>`<option value="${esc(val)}"${val===v?' selected':''}>${esc(t(lab))}</option>`).join('')}</select>`;
  else if(type==='check')return `<label class="chk"><input type="checkbox" ${base}${v?' checked':''}> <span>${t(label)}</span></label>`;
  else{const it={tel:'tel',email:'email',url:'url',month:'month',year:'text'}[type]||'text';
    input=`<input ${base} type="${it}"${type==='year'?' inputmode="numeric" maxlength="4"':''}${type==='tel'?' inputmode="tel"':''}${type==='email'?' inputmode="email" autocapitalize="off"':''}${type==='url'?' inputmode="url" autocapitalize="off"':''} value="${esc(v)}" placeholder="${esc(o.ph||'')}">`}
  return `<div class="fld${err?' bad':''}"><label for="${id}">${t(label)}${o.req?' *':''}</label>${input}<div class="err" data-err="${path}">${err?esc(err):''}</div></div>`}
const aiBtn=(kind,path,label)=>`<button class="btn ghost sm" data-act="ai" data-arg="${kind}|${path}">${ic('spark',16)} ${t(label)}</button>`;
const lvOpts=a=>a.map(x=>[x,x||'No level']);
const ENT={
  education:{arr:'education',single:'Education',hint:'Add your degrees, diplomas and courses.',empty:'No education added yet.',add:'Add Education',
    mk:()=>({degree:'',institution:'',field:'',startDate:'',endDate:'',grade:'',description:''}),
    fields:i=>{const p=`education.${i}.`;return field(p+'degree','Degree')+field(p+'institution','Institution')+field(p+'field','Field of Study')+`<div class="two">${field(p+'startDate','Start Year',{type:'year',ph:'2019'})}${field(p+'endDate','End Year',{type:'year',ph:'2023'})}</div>`+field(p+'grade','GPA / Grade')+field(p+'description','Description',{type:'textarea',rows:3})}},
  experience:{arr:'experience',single:'Experience',hint:'Add jobs, internships and volunteer work. Write one point per line.',empty:'No work experience added yet.',add:'Add Experience',
    mk:()=>({jobTitle:'',company:'',location:'',startDate:'',endDate:'',current:false,description:[]}),
    fields:i=>{const p=`experience.${i}.`,cur=CUR.experience[i].current;return field(p+'jobTitle','Job Title')+field(p+'company','Company')+field(p+'location','Location')+`<div class="two">${field(p+'startDate','Start Date',{type:'month'})}${field(p+'endDate','End Date',{type:'month',disabled:cur})}</div>`+field(p+'current','Currently working here',{type:'check'})+field(p+'description','Description / Bullets (one per line)',{type:'bullets'})},
    extra:i=>aiBtn('improve',`experience.${i}.description`,'Improve Description')},
  projects:{arr:'projects',single:'Project',hint:'Add projects you built or contributed to.',empty:'No projects added yet.',add:'Add Project',
    mk:()=>({name:'',description:'',technologies:[],url:'',githubUrl:''}),
    fields:i=>{const p=`projects.${i}.`;return field(p+'name','Project Name')+field(p+'description','Description',{type:'textarea'})+field(p+'technologies','Technologies (comma separated)',{type:'csv',ph:'Flutter, Firebase'})+field(p+'url','Project URL',{type:'url'})+field(p+'githubUrl','GitHub URL',{type:'url'})},
    extra:i=>aiBtn('improve',`projects.${i}.description`,'Improve Project Description')},
  languages:{arr:'languages',single:'Language',hint:'Add the languages you speak.',empty:'No languages added yet.',add:'Add Language',
    mk:()=>({name:'',proficiency:'Professional'}),
    fields:i=>`<div class="two">${field(`languages.${i}.name`,'Language')}${field(`languages.${i}.proficiency`,'Proficiency',{type:'select',options:LANG_LEVELS.map(x=>[x,x])})}</div>`},
  certifications:{arr:'certifications',single:'Certificate',hint:'Add licences and certificates with their details.',empty:'No certificates added yet.',add:'Add Certificate',
    mk:()=>({name:'',organization:'',issueDate:'',credentialId:'',credentialUrl:''}),
    fields:i=>{const p=`certifications.${i}.`;return field(p+'name','Certificate Name')+field(p+'organization','Issuing Organization')+field(p+'issueDate','Issue Date',{type:'month'})+field(p+'credentialId','Credential ID')+field(p+'credentialUrl','Credential URL',{type:'url'})}},
  achievements:{arr:'achievements',single:'Achievement',hint:'Add awards, honours and notable results.',empty:'No achievements added yet.',add:'Add Achievement',
    mk:()=>({title:'',description:'',date:''}),
    fields:i=>{const p=`achievements.${i}.`;return field(p+'title','Title')+field(p+'description','Description',{type:'textarea',rows:3})+field(p+'date','Date',{type:'month'})}}
};
function entrySteps(key){const C=ENT[key],arr=CUR[C.arr];
  let h=`<p class="hint">${t(C.hint)}</p>`;
  if(!arr.length)h+=`<div class="empty sm"><p>${t(C.empty)}</p></div>`;
  arr.forEach((_,i)=>{h+=`<section class="card ent" id="ent_${C.arr}_${i}"><div class="enthead"><h3>${t(C.single)} ${i+1}</h3><button class="icon" data-act="del" data-arg="${C.arr}|${i}" aria-label="${t('Delete')} ${t(C.single)} ${i+1}">${ic('trash')}</button></div>${C.fields(i)}${C.extra?C.extra(i):''}</section>`});
  return h+`<button class="btn ghost big" data-act="add" data-arg="${C.arr}">+ ${t(C.add)}</button>`}

/* =====================================================================
   VIEWS
   ===================================================================== */
const fname=()=>{const n=(CUR&&CUR.personalInfo.fullName||'').trim().replace(/[^\p{L}\p{N}]+/gu,'_').replace(/^_+|_+$/g,'');return(n||'CV')+'_CV.pdf'};
const lastCV=()=>[...DB.cvs].sort((a,b)=>b.updatedAt-a.updatedAt)[0];
function nav(tab){const tabs=[['home','Home','home'],['mycvs','My CVs','files'],['templates','Templates','layout'],['settings','Settings','settings']];
  return `<nav class="nav" aria-label="Main">${tabs.map(([k,l,i])=>`<button class="${tab===k?'on':''}" data-act="tab" data-arg="${k}" ${tab===k?'aria-current="page"':''}>${ic(i,22)}<span>${t(l)}</span></button>`).join('')}</nav>`}
function cvCards(){
  let L=DB.cvs.filter(c=>!Q||(c.name+' '+c.personalInfo.fullName+' '+c.personalInfo.title).toLowerCase().includes(Q.toLowerCase()));
  L.sort((a,b)=>SORT==='name'?a.name.localeCompare(b.name):SORT==='created'?b.createdAt-a.createdAt:b.updatedAt-a.updatedAt);
  if(!DB.cvs.length)return `<div class="empty card">${ic('file',44)}<h3 style="margin-top:8px">${t('No CVs yet')}</h3><p>${t('Create a professional CV in a few minutes.')}</p><button class="btn" data-act="newCV">${t('Create My CV')}</button><br><button class="btn ghost" style="margin-top:8px" data-act="addExample" data-arg="dev">${t('Try demo CV')}</button></div>`;
  if(!L.length)return `<div class="empty"><p>${t('No CVs match your search.')}</p></div>`;
  return L.map(c=>`<article class="cvcard">${thumbFor(c)}<div class="info"><h3>${esc(c.name)}${c.demo?`<span class="badge">${t('Demo data')}</span>`:''}</h3><div class="muted">${esc(c.personalInfo.title||t(TPL[c.templateId].name))}</div>${c.updatedAt>86400000?`<div class="muted">${t('Edited')} ${fmtDay(c.updatedAt)}</div>`:''}<div class="acts"><button data-act="editCV" data-arg="${c.id}">${ic('edit',16)}${t('Edit')}</button><button data-act="dupCV" data-arg="${c.id}">${ic('copy',16)}${t('Duplicate')}</button><button data-act="exportCV" data-arg="${c.id}">${ic('download',16)}${t('Export')}</button><button class="dl" data-act="delCV" data-arg="${c.id}" aria-label="${t('Delete')} ${esc(c.name)}">${ic('trash',16)}${t('Delete')}</button></div></div></article>`).join('')}
function listBlock(){return `<div class="toolbar"><div class="sw">${ic('search',18)}<input type="search" data-q placeholder="${t('Search CVs')}" aria-label="${t('Search CVs')}" value="${esc(Q)}"></div><select data-sort style="width:auto" aria-label="Sort">${[['updated','Last edited'],['name','Name (A-Z)'],['created','Date created']].map(([v,l])=>`<option value="${v}"${SORT===v?' selected':''}>${t(l)}</option>`).join('')}</select></div><div id="cvlist">${cvCards()}</div>`}
function vHome(){const last=lastCV();return `<div class="home-head"><h2 class="sec-title" style="margin:0">${t('Saved CVs')}</h2><div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn" data-act="newCV">${ic('plus')} ${t('Create New CV')}</button><button class="btn ghost" data-act="tab" data-arg="scan">${ic('camera')} ${t('Scan old CV')}</button>${last?`<button class="btn ghost" data-act="editCV" data-arg="${last.id}">${t('Continue Editing')}</button>`:''}</div></div>${listBlock()}`}
const vMyCvs=()=>`<h1 class="page-title">${t('My CVs')}</h1><div class="top-actions"><button class="btn big" data-act="newCV">${ic('plus')} ${t('Create New CV')}</button><button class="btn big ghost" data-act="tab" data-arg="scan">${ic('camera')} ${t('Scan old CV')}</button></div>${listBlock()}`;
function vTemplates(){const base=lastCV()||sample('dev');
  return `<h1 class="page-title">${t('Templates')}</h1><p class="hint">${t('Pick a layout. All templates share the same data, so switching never deletes anything.')}</p><div class="tgrid">${Object.keys(TPL).map(id=>`<div class="tcard">${thumbFor(base,id)}<b>${t(TPL[id].name)}${DB.settings.defaultTemplate===id?` <span class="badge ok">${t('Default')}</span>`:''}</b><span>${t(TPL[id].desc)}</span><div class="tb"><button class="btn ghost sm" data-act="setDefaultTpl" data-arg="${id}">${t('Set as default')}</button><button class="btn sm" data-act="useTpl" data-arg="${id}">${t('Use in my CV')}</button></div></div>`).join('')}</div>`}
function vSettings(){const S=DB.settings;const sel=(k,opts)=>`<select data-set="${k}">${opts.map(([v,l])=>`<option value="${v}"${S[k]===v?' selected':''}>${t(l)}</option>`).join('')}</select>`;
  return `<h1 class="page-title">${t('Settings')}</h1>
<div class="card"><div class="setrow"><label>${t('Language ')}</label>${sel('lang',[['en','English'],['bn','Bengali']])}</div><div class="setrow"><label>${t('Theme')}</label>${sel('theme',[['light','Light'],['dark','Dark'],['system','System default']])}</div><div class="setrow"><label>${t('Default template')}</label>${sel('defaultTemplate',Object.keys(TPL).map(k=>[k,TPL[k].name]))}</div><div class="setrow"><label for="as">${t('Auto save')}</label><input id="as" type="checkbox" data-setchk="autoSave" ${S.autoSave?'checked':''}></div></div>
<div class="card"><h3>${t('Privacy')}</h3><p class="muted" style="margin:6px 0 12px">${t('Your CVs are stored only on this device. When you use an AI feature, only the selected text (plus job titles and skills for summaries) is sent to the AI service you configure. Your name, phone and email are never sent. Never put API keys in this app: use a secure server proxy.')}</p><div class="fld"><label for="aip">${t('AI service URL (optional)')}</label><input id="aip" type="url" data-aiurl placeholder="https://" value="${esc(S.aiProxy)}" autocapitalize="off"><div class="muted" style="margin-top:4px">${t('Without a URL, the built-in offline helper is used.')}</div></div></div>
<div class="card"><h3 style="margin-bottom:8px">${t('Data')}</h3><div style="display:grid;gap:8px"><button class="btn ghost" data-act="addExample" data-arg="all">${t('Add example CVs')}</button><button class="btn ghost" data-act="exportBackup">${ic('download',18)} ${t('Export backup')}</button><button class="btn ghost" data-act="importBackup">${t('Import backup')}</button><button class="btn danger" data-act="wipe">${ic('trash',18)} ${t('Delete all data')}</button></div></div>
<div class="card"><h3>${t('Help & Support')}</h3>${[['How do I get a PDF?','Open a CV, go to the Preview step, tap Download or Print, then choose "Save as PDF".'],['Is my data uploaded?','No. Everything is kept on this device unless you use an AI service you configured.'],['Does AI invent facts?','It is designed to only rephrase what you wrote. Always review suggestions.'],['Where is Coming Soon?','Cloud backup, sync, online CV links and cover letters are planned for later versions.']].map(([q,a])=>`<details><summary>${t(q)}</summary><p>${t(a)}</p></details>`).join('')}<p class="muted" style="margin-top:10px">${t('Language of your CV content is whatever you type. Section headings in the CV stay in English for ATS compatibility.')}</p></div>
<div class="card"><h3>${t('About')}</h3><p class="muted">${t('Version 1.0 - Build. Improve. Export. Get Ready.')}</p></div>`}
/* ===== Local CV text parser (no AI, no key) ===== */
const MON={jan:1,feb:2,mar:3,apr:4,may:5,jun:6,jul:7,aug:8,sep:9,oct:10,nov:11,dec:12};
const DT='(?:(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\\.?\\s*,?\\s*\\d{4}|\\d{1,2}[\\/.-]\\d{4}|\\d{4})';
const RANGE=new RegExp('('+DT+')\\s*(?:-|–|—|to|till|until)\\s*('+DT+'|present|current|now|ongoing|today)','i');
const NOW=/^(present|current|now|ongoing|today)/i;
const BUL=/^[•\-*·▪●◦–>■✓]\s*/;
const ymOf=d=>{d=String(d).trim().toLowerCase();let m=d.match(/([a-z]{3})[a-z]*\.?\s*,?\s*(\d{4})/);if(m)return m[2]+'-'+String(MON[m[1]]||1).padStart(2,'0');m=d.match(/(\d{1,2})[\/.-](\d{4})/);if(m)return m[2]+'-'+String(Math.min(12,+m[1])||1).padStart(2,'0');m=d.match(/(\d{4})/);return m?m[1]+'-01':''};
const SECH={summary:/^(professional\s+|career\s+)?(summary|profile|objective|about me|personal statement|সারসংক্ষেপ|পরিচিতি)$/i,
 experience:/^((work|professional|employment|relevant)\s+)?(experience|history|work history|employment|অভিজ্ঞতা)$/i,
 education:/^(education|academic|academics|academic background|qualifications?|education and training|শিক্ষা|শিক্ষাগত যোগ্যতা)$/i,
 skills:/^((technical|key|core|professional|it)\s+)?(skills|expertise|competenc(y|ies)|technologies|tech stack|দক্ষতা)$/i,
 projects:/^((personal|academic|key)\s+)?(projects?|প্রজেক্ট)$/i,
 languages:/^(languages?|ভাষা)$/i,
 certifications:/^(certifications?|certificates?|courses|training|licenses?|licenses? and certifications?|সার্টিফিকেট)$/i,
 achievements:/^(achievements?|awards?|honou?rs|accomplishments|awards and honou?rs)$/i};
function secKey(l){const s=l.replace(/[:\-–_=|•*#]+/g,' ').replace(/\s+/g,' ').trim();if(!s||s.length>42||s.split(' ').length>5)return null;for(const k in SECH)if(SECH[k].test(s))return k;return null}
function splitSections(L){const sec={header:[]};let cur='header';L.forEach(l=>{const m=l.match(/^([A-Za-z ]{3,30}):\s*(\S.*)$/);if(m&&secKey(m[1])&&cur!=='skills'&&!(cur==='projects'&&/^tech/i.test(m[1]))){cur=secKey(m[1]);sec[cur]=sec[cur]||[];sec[cur].push(m[2]);return}const k=secKey(l);if(k){cur=k;sec[cur]=sec[cur]||[];return}(sec[cur]=sec[cur]||[]).push(l)});return sec}
function parseExp(lines){const out=[];let cur=null,skip=false;
 lines.forEach((l,i)=>{if(skip){skip=false;return}const m=l.match(RANGE);
  if(m&&l.length<=90){const c={jobTitle:'',company:'',location:'',startDate:ymOf(m[1]),endDate:NOW.test(m[2])?'':ymOf(m[2]),current:NOW.test(m[2]),description:[]};
   let rest=l.replace(RANGE,'').replace(/[()]/g,' ').replace(/^[\s|,–—\-]+|[\s|,–—\-]+$/g,'').trim();
   if(rest.length<3&&i>0&&!BUL.test(lines[i-1])&&!RANGE.test(lines[i-1])){rest=lines[i-1];const pv=out[out.length-1];if(pv&&pv.description.length&&pv.description[pv.description.length-1]===rest)pv.description.pop()}
   const p=rest.split(/\s+(?:at|@)\s+|\s*\|\s*|\s+[-–—]\s+|,\s+/).map(x=>x.trim()).filter(Boolean);
   c.jobTitle=p[0]||'';c.company=p[1]||'';if(p[2])c.location=p[2];
   const nx=lines[i+1];if(!c.company&&nx&&!BUL.test(nx)&&!RANGE.test(nx)&&nx.length<=60&&!/[.!?]$/.test(nx)){c.company=nx;skip=true}
   out.push(c);cur=c;return}
  if(cur){const t=l.replace(BUL,'').trim();if(t)cur.description.push(t)}});
 if(!out.length&&lines.length){const c={jobTitle:lines[0].replace(BUL,''),company:'',location:'',startDate:'',endDate:'',current:false,description:lines.slice(1).map(x=>x.replace(BUL,'')).filter(Boolean)};out.push(c)}
 return out.slice(0,12).map(e=>({...e,description:e.description.slice(0,10).map(x=>x.slice(0,300))}))}
function parseEdu(lines){const DEG=/\b(bachelor|master|b\.?\s?sc|m\.?\s?sc|bba|mba|b\.?\s?a\.?|m\.?\s?a\.?|ssc|hsc|diploma|ph\.?\s?d|honou?rs|associate|secondary|a-level|o-level|engineering|b\.?\s?tech|m\.?\s?tech)\b/i,INST=/(university|college|institute|school|academy|polytechnic|বিশ্ববিদ্যালয়|কলেজ|স্কুল)/i;
 const out=[];let cur=null;const flush=()=>{if(cur)out.push(cur);cur=null};const nw=()=>({degree:'',institution:'',field:'',startDate:'',endDate:'',grade:'',description:'',_y:[]});
 lines.forEach(raw=>{const l=raw.replace(BUL,'');const isD=DEG.test(l),isI=INST.test(l);
  if(!cur||(isD&&cur.degree)){flush();cur=nw()}
  (l.match(/\b(19|20)\d{2}\b/g)||[]).forEach(y=>cur._y.push(+y));
  const g=l.match(/(?:cgpa|gpa|grade|result)\s*[:\-]?\s*([\d.]+(?:\s*\/\s*[\d.]+)?)/i);if(g)cur.grade=g[1].replace(/\s/g,'');
  const clean=l.replace(/\(?\b(19|20)\d{2}\b\)?(\s*(?:-|–|—|to)\s*(?:\b(?:19|20)\d{2}\b|present))?/gi,'').replace(/(?:cgpa|gpa|grade|result)\s*[:\-]?\s*[\d.]+(?:\s*\/\s*[\d.]+)?/ig,'').replace(/^[\s,|–—\-•*()]+|[\s,|–—\-•*()]+$/g,'');
  if(!clean)return;
  if(isD&&!cur.degree){if(isI){const p=clean.split(/\s*[,|]\s*|\s+[-–—]\s+/);cur.degree=p.find(x=>DEG.test(x)&&!INST.test(x))||p[0];cur.institution=p.find(x=>INST.test(x))||''}else cur.degree=clean}
  else if(isI&&!cur.institution)cur.institution=clean;
  else if(!cur.degree)cur.degree=clean;
  else if(!cur.field&&clean.length<60)cur.field=clean;
  else cur.description+=(cur.description?' ':'')+clean});
 flush();return out.slice(0,8).map(e=>{const y=e._y.sort();e.startDate=y.length>1?String(y[0]):'';e.endDate=y.length?String(y[y.length-1]):'';delete e._y;return e})}
function parseSkills(lines){const s=[];lines.forEach(l=>{l=l.replace(BUL,'').replace(/^[A-Za-z &]{2,30}:\s*/,'');l.split(/[,;|•·▪●]|\s{2,}|\s[-–]\s/).forEach(x=>{x=x.trim().replace(/^[()\-]+|[()\-.]+$/g,'');if(x&&x.length<=40&&x.split(' ').length<=4&&!s.some(y=>y.toLowerCase()===x.toLowerCase()))s.push(x)})});return s.slice(0,40).map(name=>({name,level:''}))}
function parseProjects(lines){const out=[];let cur=null;
 lines.forEach(raw=>{const l=raw.replace(BUL,'').trim(),isB=BUL.test(raw);if(!l)return;
  const tm=l.match(/^(tech(?:nolog(?:y|ies))?|stack|tools|built with)\s*[:\-]\s*(.+)$/i);
  if(tm&&cur){cur.technologies=tm[2].split(/[,;|]/).map(x=>x.trim()).filter(Boolean).slice(0,15);return}
  const um=l.match(/(https?:\/\/[^\s]+|github\.com\/[^\s]+)/i);
  if(um&&cur){if(/github\.com/i.test(um[1]))cur.githubUrl=um[1];else cur.url=um[1];if(l.length<=um[1].length+12)return}
  if(!isB&&l.length<=70&&(!cur||cur.description)){cur={name:l.replace(/[:\-–]\s*$/,''),description:'',technologies:[],url:'',githubUrl:''};out.push(cur);return}
  if(!cur){cur={name:l.slice(0,60),description:'',technologies:[],url:'',githubUrl:''};out.push(cur);return}
  cur.description+=(cur.description?' ':'')+l});
 return out.slice(0,8).map(p=>({...p,description:p.description.slice(0,600)}))}
const LVL=[[/native|mother|first language|মাতৃভাষা/i,'Native'],[/fluent|advanced|\bc[12]\b/i,'Fluent'],[/professional|proficien|business|working/i,'Professional'],[/intermediate|conversational|\bb[12]\b|good/i,'Intermediate'],[/basic|beginner|elementary|limited|\ba[12]\b/i,'Basic']];
function parseLangs(lines){const out=[];lines.join('\n').split(/[,;|•·\n]/).forEach(x=>{x=x.replace(BUL,'').trim();if(!x)return;const nm=x.split(/\s*[(:\-–]\s*/)[0].trim();if(!nm||nm.length>20||nm.split(' ').length>2||/\d/.test(nm))return;const lv=(LVL.find(([r])=>r.test(x))||[0,'Professional'])[1];if(!out.some(o=>o.name.toLowerCase()===nm.toLowerCase()))out.push({name:nm,proficiency:lv})});return out.slice(0,8)}
function parseCerts(lines){return lines.map(l=>l.replace(BUL,'').trim()).filter(l=>l.length>3).slice(0,10).map(l=>{const y=l.match(/\b(19|20)\d{2}\b/);const base=l.replace(/\(?\b(19|20)\d{2}\b\)?/g,'').replace(/[\s,|–—\-]+$/,'').trim();const p=base.split(/\s+[-–—|]\s+|\s+(?:by|from)\s+/i);return{name:(p[0]||base).slice(0,120),organization:(p[1]||'').slice(0,100),issueDate:y?y[0]+'-01':'',credentialId:'',credentialUrl:''}})}
function parseCVText(raw){
 const L=String(raw).replace(/\r/g,'').split('\n').map(x=>x.replace(/[ \t]+/g,' ').trim()).filter(x=>x.length>0);
 const all=L.join('\n'),sec=splitSections(L),H=sec.header||[];
 const email=(all.match(/[\w.+-]+@[\w-]+\.[\w.-]+/)||[''])[0];
 let phone='';for(const m of all.matchAll(/\+?\d[\d\s().-]{7,17}\d/g)){const d=m[0].replace(/\D/g,'');if(d.length>=9&&d.length<=15&&!/^(19|20)\d{2}\s*[-–]/.test(m[0])){phone=m[0].trim();break}}
 const linkedin=(all.match(/(?:https?:\/\/)?(?:www\.)?linkedin\.com\/[\w\-\/%.]+/i)||[''])[0];
 const github=(all.match(/(?:https?:\/\/)?(?:www\.)?github\.com\/[\w\-.]+/i)||[''])[0];
 let portfolio='';for(const m of all.matchAll(/(?:https?:\/\/|www\.)[^\s,;)]+/gi)){if(!/linkedin|github/i.test(m[0])){portfolio=m[0];break}}
 const isName=l=>!/[@\d:\/]/.test(l)&&/^[\p{L}.'\- ]+$/u.test(l)&&l.split(' ').length>=2&&l.split(' ').length<=5&&!secKey(l);
 let nameIdx=H.findIndex(isName);const fullName=nameIdx>=0?H[nameIdx]:'';
 let title='';if(nameIdx>=0){const n=H.slice(nameIdx+1).find(l=>!/[@\d]/.test(l)&&l.split(' ').length<=8&&l.length<=70&&!/,/.test(l)&&!/^(phone|email|address|mobile|tel)/i.test(l));if(n)title=n}
 const location=(H.find(l=>/,/.test(l)&&!/@/.test(l)&&(l.match(/\d/g)||[]).length<6&&l.split(' ').length<=8&&l!==title&&l!==fullName)||'').replace(/^(address|location)\s*[:\-]\s*/i,'');
 let summary=(sec.summary||[]).join(' ').slice(0,1200);if(!summary){const long=H.filter(l=>l.length>90);summary=long.join(' ').slice(0,1200)}
 return{personalInfo:{fullName,title,phone,email,location,linkedin,github,portfolio,photo:''},summary,
  education:parseEdu(sec.education||[]),experience:parseExp(sec.experience||[]),skills:parseSkills(sec.skills||[]),
  projects:parseProjects(sec.projects||[]),languages:parseLangs(sec.languages||[]),certifications:parseCerts(sec.certifications||[]),
  achievements:(sec.achievements||[]).map(l=>l.replace(BUL,'').trim()).filter(l=>l.length>3).slice(0,8).map(t=>({title:t.slice(0,120),description:'',date:''}))}}

/* ===== Scanner (runs in the browser: no server, no API key) ===== */
let SC={s:'idle'},SCLANG='eng';
const LIB={tess:'https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js',pdf:'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js',pdfw:'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js'};
const loadScript=u=>new Promise((ok,no)=>{if(document.querySelector('script[src="'+u+'"]'))return ok();const s=document.createElement('script');s.src=u;s.onload=ok;s.onerror=()=>no(new Error('lib'));document.head.appendChild(s)});
function setProg(p,msg){const b=$('#scanBar'),m=$('#scanMsg');if(b)b.style.width=p+'%';if(m&&msg)m.textContent=msg}
async function ocrRun(src){await loadScript(LIB.tess);setProg(8,t('Loading the reader (first time only)...'));
  const r=await Tesseract.recognize(src,SCLANG,{logger:m=>{if(m.status==='recognizing text')setProg(30+Math.round(m.progress*65),t('Reading text')+' '+Math.round(m.progress*100)+'%');else if(/load|initiali/.test(m.status))setProg(15,t('Loading the reader (first time only)...'))}});
  return r.data.text||''}
function imgCanvas(f){return new Promise((ok,no)=>{const u=URL.createObjectURL(f),im=new Image();im.onload=()=>{URL.revokeObjectURL(u);const big=Math.max(im.width,im.height),k=big>2400?2400/big:big<1200?Math.min(2,1200/big):1,c=document.createElement('canvas');c.width=Math.round(im.width*k);c.height=Math.round(im.height*k);const x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);x.drawImage(im,0,0,c.width,c.height);ok(c)};im.onerror=()=>{URL.revokeObjectURL(u);no(new Error('img'))};im.src=u})}
async function pdfText(f){await loadScript(LIB.pdf);pdfjsLib.GlobalWorkerOptions.workerSrc=LIB.pdfw;setProg(10,t('Opening PDF...'));
  const doc=await pdfjsLib.getDocument({data:await f.arrayBuffer()}).promise,n=Math.min(doc.numPages,3);let out='';
  for(let i=1;i<=n;i++){const pg=await doc.getPage(i),tc=await pg.getTextContent(),lines=[];let y=null,cur='';tc.items.forEach(it=>{const yy=Math.round(it.transform[5]);if(y!==null&&Math.abs(yy-y)>3){lines.push(cur);cur=''}y=yy;cur+=it.str});lines.push(cur);out+=lines.join('\n')+'\n'}
  if(out.replace(/\s/g,'').length>=120){setProg(90,t('Organising sections'));return out}
  let txt='';for(let i=1;i<=n;i++){const pg=await doc.getPage(i),vp=pg.getViewport({scale:2}),c=document.createElement('canvas');c.width=vp.width;c.height=vp.height;await pg.render({canvasContext:c.getContext('2d'),viewport:vp}).promise;txt+=await ocrRun(c)+'\n'}
  return txt}
function vScan(){
  const head=`<h1 class="page-title">${t('Scan your old CV')}</h1><p class="hint">${t('Upload a photo or PDF of your old CV. It is read on your device and turned into an editable CV for you to review.')}</p>`;
  if(SC.s==='busy')return head+`<div class="card scan-busy"><div class="spin"></div><h3>${t('Reading your CV...')}</h3><p class="muted">${esc(SC.name||'')}</p><div class="pbar"><i id="scanBar" style="width:5%"></i></div><p id="scanMsg" class="muted">${t('Starting...')}</p></div>`;
  if(SC.s==='done'){const c=SC.cv;return head+`<div class="card"><div class="note">${t('Automatic reading can make mistakes. Please review every section in the builder.')}</div><h3 style="margin-top:12px">${esc(c.personalInfo.fullName||t('Name not found'))}</h3><div class="muted">${esc(c.personalInfo.title||'')}</div><div class="scan-stats">${[['Experience',c.experience],['Education',c.education],['Skills',c.skills],['Projects',c.projects],['Languages',c.languages],['Certificates',c.certifications]].map(([k,a])=>`<div><b>${a.length}</b><span>${t(k)}</span></div>`).join('')}</div><details class="jm-raw"><summary>${t('Show the text that was read')}</summary><pre>${esc((SC.raw||'').slice(0,6000))}</pre></details><div class="row"><button class="btn line" data-act="scanReset">${t('Scan another')}</button><button class="btn" data-act="scanCreate">${t('Create CV & review')}</button></div></div>`}
  return head+`<div class="card scan-drop"><div class="scan-ic">${ic('file',44)}</div><h3>${t('Choose your old CV')}</h3><p class="muted">${t('JPG, PNG or PDF. You can also drop a file here.')}</p><label class="jm-l" for="scanLang">${t('Language in the CV')}</label><select id="scanLang" class="jm-in scan-lang"><option value="eng"${SCLANG==='eng'?' selected':''}>English</option><option value="eng+ben"${SCLANG!=='eng'?' selected':''}>English + Bangla</option></select>${SC.err?`<div class="scan-err">${esc(SC.err)}</div>`:''}<div class="scan-btns"><button class="btn" data-act="scanCam">${ic('camera')} ${t('Take a photo')}</button><button class="btn ghost" data-act="scanPick">${ic('image')} ${t('Upload image or PDF')}</button></div><p class="hint">${t('Your file never leaves your device. Works best with clear, typed CVs.')}</p></div>`}
async function scanFile(f){
  if(!f)return;const pdf=f.type==='application/pdf'||/\.pdf$/i.test(f.name),fail=m=>{SC={s:'idle',err:m};render()};
  if(!pdf&&!/^image\//.test(f.type))return fail(t('Please choose a JPG, PNG or PDF file.'));
  if(f.size>25*1024*1024)return fail(t('File is too large.'));
  SC={s:'busy',name:f.name};render();
  try{const text=pdf?await pdfText(f):await ocrRun(await imgCanvas(f));
    if(text.replace(/\s/g,'').length<40)throw new Error('unreadable');
    const cv=parseCVText(text),p=cv.personalInfo;
    if(!p.fullName&&!cv.experience.length&&!cv.education.length&&!cv.skills.length)throw new Error('unreadable');
    SC={s:'done',cv:migrate(cv),raw:text}}
  catch(e){const M={unreadable:t('Could not find CV details in this file. Try a clearer, straight-on photo or a text PDF.'),img:t('This image format is not supported. Try a JPG or PNG.'),lib:t('Could not load the reader. Check your internet connection and try again.')};
    SC={s:'idle',err:M[e.message]||t('Scanning failed. Please try again with a clearer file.')}}
  if(R.view==='scan')render()}

/* ===== Job match (runs in the browser: no server, no API key) ===== */
const SKILLDB=('javascript,typescript,python,java,kotlin,swift,php,c++,c#,rust,ruby,sql,mysql,postgresql,mongodb,firebase,html,css,react,angular,vue,node.js,express,laravel,spring boot,django,flask,android,ios,flutter,react native,docker,kubernetes,aws,azure,gcp,git,github,linux,rest api,graphql,ci/cd,jenkins,figma,photoshop,illustrator,ui/ux,seo,wordpress,excel,power bi,tableau,machine learning,data analysis,data science,tensorflow,pandas,agile,scrum,jira,testing,unit testing,selenium,devops,microservices,tailwind,bootstrap,sass,redux,next.js,oop,algorithms,data structures,networking,cybersecurity,project management,leadership,communication,teamwork,problem solving,time management,customer service,sales,marketing,content writing,copywriting,social media,digital marketing,google analytics,accounting,quickbooks,tally,budgeting,financial analysis,recruitment,negotiation,presentation,research,microsoft office,powerpoint,video editing,premiere pro,after effects,canva,autocad,solidworks,matlab,english,bangla').split(',');
const JSTOP=new Set('about above after again also another any are around because been before being between both build but can candidate company could create day does each either else employer ensure equal every experience from have having help high including into join just keep known like looking make many more most must need needs new not offer one only other our out over own part per plus position preferred provide required requirements responsibilities responsible role same see should some strong such take team than that the their them then there these they this those through time too under until upon use using very want well were what when where which while will with within without work working would year years you your able ability skills skill knowledge good great excellent proven opportunity benefits salary apply application hiring job full part-time based related relevant minimum degree'.split(' '));
const PRETTY={mysql:'MySQL',postgresql:'PostgreSQL',mongodb:'MongoDB',javascript:'JavaScript',typescript:'TypeScript',graphql:'GraphQL',github:'GitHub',wordpress:'WordPress',powerpoint:'PowerPoint',tensorflow:'TensorFlow',devops:'DevOps',quickbooks:'QuickBooks',ios:'iOS','ci/cd':'CI/CD','ui/ux':'UI/UX',sql:'SQL',html:'HTML',css:'CSS',php:'PHP',aws:'AWS',gcp:'GCP',seo:'SEO',oop:'OOP','rest api':'REST API','c++':'C++','c#':'C#','node.js':'Node.js','next.js':'Next.js'};
const pretty=k=>PRETTY[k]||k.replace(/\b\w/g,c=>c.toUpperCase());
const hasTerm=(txt,k)=>new RegExp('(^|[^a-z0-9+#])'+k.replace(/[.*+?^${}()|[\]\\\/]/g,'\\$&')+'($|[^a-z0-9+#])').test(txt);
function cvText(cv){const p=cv.personalInfo;return[p.title,cv.summary,...cv.skills.map(s=>s.name),...cv.experience.flatMap(e=>[e.jobTitle,e.company,...(e.description||[])]),...cv.projects.flatMap(x=>[x.name,x.description,...(x.technologies||[])]),...cv.education.flatMap(e=>[e.degree,e.field,e.institution]),...cv.certifications.map(c=>c.name),...cv.achievements.map(a=>a.title)].filter(Boolean).join(' \n ').toLowerCase()}
function jmCompute(cv,job){
  const jl=job.toLowerCase(),kw=[];SKILLDB.forEach(k=>{if(hasTerm(jl,k))kw.push({k,w:2})});
  const fr={};(jl.match(/[a-z][a-z+#.\-]{3,}/g)||[]).forEach(w=>{w=w.replace(/[.\-]+$/,'');if(w.length>3&&!JSTOP.has(w)&&!kw.some(x=>x.k===w))fr[w]=(fr[w]||0)+1});
  Object.entries(fr).filter(([,n])=>n>=2).sort((a,b)=>b[1]-a[1]).slice(0,6).forEach(([k])=>kw.push({k,w:1}));
  if(kw.length<3)return null;
  const ct=cvText(cv),m=kw.filter(x=>hasTerm(ct,x.k)),x=kw.filter(y=>!hasTerm(ct,y.k)),tot=kw.reduce((a,y)=>a+y.w,0),got=m.reduce((a,y)=>a+y.w,0);
  const bl=cv.experience.flatMap(e=>e.description||[]),withNum=bl.filter(b=>/\d/.test(b)).length,sug=[];
  x.slice(0,3).forEach(y=>sug.push(t('Add')+' "'+pretty(y.k)+'" '+t('to your skills or experience if you have used it.')));
  if(!cv.summary)sug.push(t('Write a short summary that mentions the role you are applying for.'));
  if(!cv.personalInfo.title)sug.push(t('Add a professional title under your name.'));
  if(bl.length>=3&&withNum/bl.length<.25)sug.push(t('Add numbers (percentages, users, time saved) to your experience bullets.'));
  return{score:Math.round(100*got/tot),matched:m.map(y=>pretty(y.k)),missing:x.map(y=>pretty(y.k)),suggestions:sug.slice(0,5)}}
let JM={cvId:'',job:'',s:'idle',res:null,sel:[],err:''};
function vMatch(){
  const head=`<h1 class="page-title">${t('Match CV to a Job')}</h1><p class="hint">${t('Paste a job description to see which keywords your CV already has and which are missing. Nothing is added to your CV without your approval.')}</p>`;
  if(!DB.cvs.length)return head+`<div class="card empty"><h3>${t('You need a CV first')}</h3><button class="btn" data-act="newCV">${ic('plus')} ${t('Create New CV')}</button></div>`;
  if(!DB.cvs.find(c=>c.id===JM.cvId))JM.cvId=(lastCV()||DB.cvs[0]).id;
  const busy=JM.s==='busy';
  let h=head+`<div class="card jm-form"><label class="jm-l" for="jmCv">${t('Your CV')}</label><select id="jmCv" class="jm-in">${DB.cvs.map(c=>`<option value="${c.id}"${c.id===JM.cvId?' selected':''}>${esc(c.name)}</option>`).join('')}</select><label class="jm-l" for="jmJob">${t('Job description')}</label><textarea id="jmJob" class="jm-in" rows="9" placeholder="${t('Paste the full job post here...')}">${esc(JM.job)}</textarea>${JM.err?`<div class="scan-err">${esc(JM.err)}</div>`:''}<button class="btn big" data-act="jmRun"${busy?' disabled':''}>${busy?`<span class="spin"></span> ${t('Analyzing...')}`:`${ic('spark')} ${t('Analyze match')}`}</button></div>`;
  const r=JM.res;if(JM.s!=='done'||!r)return h;
  const col=r.score>=75?'#10b981':r.score>=50?'#f59e0b':'#ef4444',off=Math.round(314*(1-r.score/100)),verdict=r.score>=75?'Strong match':r.score>=50?'Good start - a few gaps':'Needs work for this role';
  h+=`<div id="jmRes" class="card jm-res"><div class="jm-top"><svg class="ring" viewBox="0 0 120 120" width="120" height="120"><circle cx="60" cy="60" r="50" fill="none" stroke="var(--line)" stroke-width="10"/><circle class="ring-v" cx="60" cy="60" r="50" fill="none" stroke="${col}" stroke-width="10" stroke-linecap="round" stroke-dasharray="314" style="--off:${off}" transform="rotate(-90 60 60)"/><text x="60" y="68" text-anchor="middle" font-size="28" font-weight="800" fill="currentColor">${r.score}%</text></svg><div><h3>${t(verdict)}</h3><p class="muted">${t('Keyword match based only on what is written in your CV.')}</p></div></div>`;
  if(r.matched.length)h+=`<h4 class="jm-h">${t('Already in your CV')}</h4><div class="chips">${r.matched.map(m=>`<span class="chip jm-ok">${esc(m)}</span>`).join('')}</div>`;
  if(r.missing.length)h+=`<h4 class="jm-h">${t('Missing from your CV')}</h4><p class="hint">${t('Tap only the ones you genuinely have, then add them as skills.')}</p><div class="chips">${r.missing.map((m,i)=>`<button class="chip jm-miss${JM.sel.includes(i)?' on':''}" data-act="jmTog" data-arg="${i}">${JM.sel.includes(i)?'✓ ':'+ '}${esc(m)}</button>`).join('')}</div><button class="btn ghost" style="margin-top:12px"${JM.sel.length?'':' disabled'} data-act="jmSkills">${t('Add selected as skills')}</button>`;
  if(r.suggestions.length)h+=`<h4 class="jm-h">${t('Suggestions')}</h4><ul class="jm-list">${r.suggestions.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`;
  return h+`<div class="row" style="margin-top:16px"><button class="btn line" data-act="editCV" data-arg="${JM.cvId}">${t('Open in editor')}</button></div></div>`}
function jmRun(){
  const job=JM.job.trim(),cv=DB.cvs.find(c=>c.id===JM.cvId);if(!cv)return;
  if(job.length<40){JM.err=t('Please paste the full job description (at least a few lines).');return render()}
  JM.s='busy';JM.err='';JM.res=null;JM.sel=[];render();
  setTimeout(()=>{const r=jmCompute(cv,job);if(!r){JM.s='idle';JM.err=t('Could not find enough keywords. Paste the full job description.')}else{JM.res=r;JM.s='done'}
    if(R.view==='match'){render();const el=$('#jmRes');if(el)el.scrollIntoView({behavior:'smooth',block:'start'})}},450)}
function vMain(){const body={home:vHome,mycvs:vMyCvs,templates:vTemplates,settings:vSettings,scan:vScan,match:vMatch}[R.view]();return `<div class="screen">${body}</div>`}
function vOnboarding(){const P=[['file','Create Your Professional CV','Fill in simple steps and watch your CV update live with five professional templates.'],['spark','Write Better With AI','Improve your wording with AI. It only uses what you wrote and never invents facts.'],['download','Export & Share','Download a clean A4 PDF with selectable text and clickable links, then share it.']];const [i,ti,tx]=P[R.ob];
  return `<div class="ob"><button class="btn sm line skip" data-act="obSkip">${t('Skip')}</button><div class="mid"><div class="big-ic">${ic(i,60)}</div><h1>${t(ti)}</h1><p class="muted" style="max-width:320px;font-size:16px">${t(tx)}</p></div><div class="dots">${P.map((_,k)=>`<i class="${k===R.ob?'on':''}"></i>`).join('')}</div><button class="btn big" data-act="obNext">${R.ob===2?t('Get Started'):t('Next')}</button></div>`}

/* ---------- builder ---------- */
function stepBody(key){
  const P=CUR.personalInfo,S=CUR.socialLinks;
  switch(key){
  case 'personal':{const ini=(P.fullName||'?').trim().split(/\s+/).map(w=>w[0]).slice(0,2).join('').toUpperCase();
    return `${CUR.demo?`<div class="demo-banner">${t('This is demo data. Edit it or create your own CV.')}</div>`:''}<div class="card">${field('name','CV Name')}</div><div class="card photoCard"><div class="avatar">${P.photo?`<img src="${esc(P.photo)}" alt="${t('Profile Photo')}">`:esc(ini)}</div><div class="pbtn"><button class="btn ghost sm" data-act="photo" data-arg="cam">${ic('camera',16)} ${t('Camera')}</button><button class="btn ghost sm" data-act="photo" data-arg="gal">${ic('image',16)} ${t('Gallery')}</button>${P.photo?`<button class="btn danger sm" data-act="photoRemove">${t('Remove photo')}</button>`:''}</div></div>
<div class="card">${field('personalInfo.fullName','Full Name',{req:1})}${field('personalInfo.title','Professional Title')}${field('personalInfo.phone','Phone',{type:'tel'})}${field('personalInfo.email','Email',{type:'email'})}${field('personalInfo.location','Location')}${field('personalInfo.linkedin','LinkedIn',{type:'url'})}${field('personalInfo.github','GitHub',{type:'url'})}${field('personalInfo.portfolio','Portfolio',{type:'url'})}</div>
<div class="card"><h3 style="margin-bottom:10px">${t('Other links')}</h3>${field('socialLinks.behance','Behance',{type:'url'})}${field('socialLinks.dribbble','Dribbble',{type:'url'})}${field('socialLinks.other','Other link',{type:'url'})}${field('socialLinks.otherLabel','Other link label')}</div>`}
  case 'summary':return `<p class="hint">${t('Write 2-4 sentences about who you are and what you do best.')}</p><div class="card">${field('summary','Professional Summary',{type:'textarea',rows:7})}<div style="display:flex;flex-wrap:wrap;gap:8px">${aiBtn('gen','summary','Generate Summary')}${aiBtn('improve','summary','Improve')}${aiBtn('shorten','summary','Shorten')}${aiBtn('professional','summary','Make Professional')}${aiBtn('grammar','summary','Fix Grammar')}</div><div class="note">${t('AI suggestions should be reviewed before adding them to your CV.')}</div></div>`;
  case 'education':return entrySteps('education');
  case 'experience':return entrySteps('experience');
  case 'projects':return entrySteps('projects');
  case 'languages':return entrySteps('languages');
  case 'certificates':return entrySteps('certifications');
  case 'achievements':return entrySteps('achievements');
  case 'skills':return `<p class="hint">${t('Add skill chips. Levels are optional.')}</p><div class="card"><div class="addrow"><input id="skIn" placeholder="${t('Add a skill')}" aria-label="${t('Add a skill')}" enterkeyhint="done"><select id="skLv" aria-label="${t('Proficiency')}">${SK_LEVELS.map(l=>`<option value="${l}">${t(l||'No level')}</option>`).join('')}</select><button class="btn" data-act="addSkill" aria-label="${t('Add')}">${ic('plus')}</button></div>${CUR.skills.length?CUR.skills.map((s,i)=>`<div class="skrow"><b>${esc(s.name)}</b><select data-path="skills.${i}.level" aria-label="${t('Proficiency')} ${esc(s.name)}">${lvOpts(SK_LEVELS).map(([v,l])=>`<option value="${v}"${s.level===v?' selected':''}>${t(l)}</option>`).join('')}</select><button class="icon" data-act="delSkill" data-arg="${i}" aria-label="${t('Delete')} ${esc(s.name)}">${ic('x')}</button></div>`).join(''):`<div class="empty sm"><p>${t('No skills added yet.')}</p></div>`}<div style="margin-top:12px">${`<button class="btn ghost sm" data-act="suggestSkills">${ic('spark',16)} ${t('Suggest Skills')}</button>`}</div><div class="note">${t('AI suggestions should be reviewed before adding them to your CV.')}</div></div>`;
  case 'template':{const C=CUR.customization;
    const sel=(path,label,opts)=>field(path,label,{type:'select',options:opts});
    return `<h3 style="margin-bottom:10px">${t('Choose a template')}</h3><div class="tgrid">${Object.keys(TPL).map(id=>`<button class="tcard ${CUR.templateId===id?'on':''}" data-act="setTpl" data-arg="${id}" aria-pressed="${CUR.templateId===id}">${thumbFor(CUR,id)}<b>${t(TPL[id].name)}</b><span>${t(TPL[id].desc)}</span></button>`).join('')}</div>
${CUR.templateId==='ats'?`<div class="note">${t('ATS-friendly formatting can improve readability, but no format can guarantee selection.')}</div>`:''}
<div class="card" style="margin-top:14px"><h3 style="margin-bottom:10px">${t('Customize')}</h3>
${sel('customization.font','Font style',[['auto','Template default'],['sans','Sans-serif'],['serif','Serif'],['mono','Monospace']])}
${sel('customization.size','Font size',[['small','Small'],['medium','Medium'],['large','Large']])}
${sel('customization.spacing','Section spacing',[['compact','Compact'],['normal','Normal'],['relaxed','Relaxed']])}
${sel('customization.heading','Heading style',[['default','Template default'],['underline','Underline'],['plain','Plain'],['bar','Side bar'],['box','Boxed']])}
${field('customization.showPhoto','Show profile photo',{type:'check'})}
<div class="fld"><label for="acc">${t('Accent color')}</label><div style="display:flex;gap:8px"><input id="acc" type="color" data-path="customization.accent" value="${C.accent||TPL[CUR.templateId].accent}"><button class="btn ghost" data-act="resetAccent">${t('Reset')}</button></div></div>
<h4 style="margin:6px 0">${t('Show sections')}</h4>${SECS.map(([k,l])=>field('customization.sections.'+k,l,{type:'check'})).join('')}</div>
<h3 style="margin:16px 0 10px">${t('Live preview')}</h3><div id="pvmount"></div>`}
  case 'preview':return `<div id="pvmount"></div>${CUR.templateId==='ats'?`<div class="note">${t('ATS-friendly formatting can improve readability, but no format can guarantee selection.')}</div>`:''}
<div class="card"><div class="muted" style="margin-bottom:8px">${t('File name')}: <b>${esc(fname())}</b></div><div class="exp-grid"><button class="btn" data-act="genPDF">${ic('file',18)} ${t('Generate PDF')}</button><button class="btn" data-act="download">${ic('download',18)} ${t('Download')}</button><button class="btn ghost" data-act="share">${ic('share',18)} ${t('Share')}</button><button class="btn ghost" data-act="print">${ic('print',18)} ${t('Print')}</button></div><button class="btn ghost big" data-act="assistant" style="margin:0">${ic('spark',18)} ${t('AI Resume Assistant')}</button><div class="note">${t('Tip: in the print window choose "Save as PDF". Text stays selectable and links stay clickable.')}</div><div class="note">${t('AI suggestions should be reviewed before adding them to your CV.')}</div></div>`;
  }return''}
function vBuilder(){const n=STEPS.length,[key,label]=STEPS[R.step];
  return `<div class="bhead"><button class="icon" data-act="exitBuilder" aria-label="${t('Back')}">${ic('back',24)}</button><div class="bt"><div class="bstep">${t('Step')} ${R.step+1} ${t('of')} ${n}${DIRTY&&!DB.settings.autoSave?' · '+t('Unsaved changes'):''}</div><h2>${t(label)}</h2></div><button class="btn sm" data-act="saveCV">${t('Save')}</button></div>
<div class="progress" role="progressbar" aria-valuemin="0" aria-valuemax="${n}" aria-valuenow="${R.step+1}"><i style="width:${(R.step+1)/n*100}%"></i></div>
<nav class="pills" aria-label="Steps">${STEPS.map(([k,l],i)=>`<button class="${i===R.step?'on':i<R.step?'done':''}" data-act="gotoStep" data-arg="${i}">${t(l)}</button>`).join('')}</nav>
<div class="bscreen">${stepBody(key)}</div>
<div class="bfoot"><button class="btn line" data-act="back" ${R.step===0?'disabled':''}>${t('Back')}</button>${R.step<n-1?`<button class="btn" data-act="next">${t('Next')}</button>`:`<button class="btn" data-act="saveCV">${t('Save')}</button>`}</div>`}

/* ---------- live preview ---------- */
function mountPreview(){const m=$('#pvmount');if(!m)return;
  m.innerHTML=`<div class="pv" id="pv"><div class="pv-bar"><button class="icon" data-act="zoom" data-arg="-" aria-label="${t('Zoom out')}">${ic('zout')}</button><span class="pvz" id="pvz">100%</span><button class="icon" data-act="zoom" data-arg="+" aria-label="${t('Zoom in')}">${ic('zin')}</button><button class="btn ghost sm" data-act="zoom" data-arg="0" aria-label="${t('Fit width')}">${t('Fit')}</button><span class="sp"></span><button class="icon" data-act="pvpage" data-arg="-1" aria-label="${t('Previous page')}">${ic('back')}</button><span class="pvp" id="pvp"></span><button class="icon" data-act="pvpage" data-arg="1" aria-label="${t('Next page')}">${ic('next')}</button><button class="icon" data-act="pvfs" aria-label="${t('Full screen')}">${ic('full')}</button></div><div class="pv-scroll" id="pvs"></div></div>`;
  $('#pvs').addEventListener('scroll',pvInfo,{passive:true});drawPages()}
let pvT;
function refreshPreview(now){if(!$('#pvs'))return;clearTimeout(pvT);pvT=setTimeout(drawPages,now?0:200)}
function drawPages(){const box=$('#pvs');if(!box)return;const top=box.scrollTop;
  try{const pages=paginate(CUR);PV.pages=pages;box.innerHTML='';pages.forEach(pg=>{const w=document.createElement('div');w.className='pgw';w.appendChild(pg);box.appendChild(w)});layoutPreview();box.scrollTop=top;pvInfo()}
  catch(e){toast(t('Something went wrong'),'err')}}
function layoutPreview(){const box=$('#pvs');if(!box)return;const fit=Math.max(.2,(box.clientWidth-24)/794),s=fit*PV.zoom;PV.s=s;
  $$('.pgw',box).forEach(w=>{w.style.width=794*s+'px';w.style.height=1122*s+'px';w.firstChild.style.transform=`scale(${s})`});const z=$('#pvz');if(z)z.textContent=Math.round(PV.zoom*100)+'%'}
function pvInfo(){const box=$('#pvs'),p=$('#pvp');if(!box||!p)return;const n=PV.pages.length,h=1122*PV.s+12;const i=Math.min(n-1,Math.max(0,Math.floor((box.scrollTop+box.clientHeight/3)/h)));p.textContent=`${i+1}/${n}`;p.title=`${t('Page')} ${i+1} ${t('of')} ${n}`}

/* ---------- render ---------- */
function applyTheme(){const th=DB.settings.theme;document.documentElement.dataset.theme=th==='system'?(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'):th;document.documentElement.lang=DB.settings.lang==='bn'?'bn':'en'}
function render(){applyTheme();const app=$('#app');let html;
  try{html=R.view==='onboarding'?vOnboarding():R.view==='builder'?vBuilder():vMain()}
  catch(e){html=`<div class="screen"><div class="empty card"><h3>${t('Something went wrong')}</h3><button class="btn" data-act="goHome">${t('Back to Home')}</button></div></div>`}
  app.innerHTML=html;
  try{fitThumbs();if(R.view==='builder'&&$('#pvmount'))mountPreview()}catch(e){}}
function keepScroll(fn){const y=window.scrollY;fn();window.scrollTo(0,y)}

/* ---------- save / commit ---------- */
let saveT;
function commit(){if(!CUR)return true;CUR.updatedAt=CUR.updatedAt||Date.now();const i=DB.cvs.findIndex(c=>c.id===CUR.id);const c=clone(CUR);if(i<0)DB.cvs.push(c);else DB.cvs[i]=c;const ok=persist();if(ok)DIRTY=false;return ok}
function markDirty(){CUR.updatedAt=Date.now();DIRTY=true;if(DB.settings.autoSave){clearTimeout(saveT);saveT=setTimeout(commit,500)}else{const b=$('.bstep');if(b&&!b.textContent.includes('·'))b.textContent+=' · '+t('Unsaved changes')}}
function openCV(cv,step){CUR=clone(cv);ERR={};DIRTY=false;PV.zoom=1;R={view:'builder',step:step||0,ob:0};render();window.scrollTo(0,0)}

/* ---------- samples ---------- */
function sample(kind){const b=blankCV();b.demo=true;b.id=kind==='dev'?'demo':uid();b.updatedAt=kind==='dev'?1:Date.now();
  if(kind==='dev'){Object.assign(b,{name:'Software Developer CV (Demo)',templateId:'modern',summary:'Software developer with experience building cross-platform mobile apps. Skilled in Flutter, Dart, Firebase and Git.',
    skills:['Flutter','Dart','Firebase','Git'].map(n=>({name:n,level:n==='Git'?'Advanced':'Intermediate'})),
    education:[{degree:'BSc in Computer Science',institution:'Demo University',field:'Computer Science',startDate:'2018',endDate:'2022',grade:'CGPA 3.6/4.0',description:''}],
    experience:[{jobTitle:'Junior Flutter Developer',company:'Demo Tech Ltd.',location:'Dhaka',startDate:'2022-03',endDate:'',current:true,description:['Built and maintained a cross-platform mobile app using Flutter and Firebase','Fixed bugs and improved screen load times','Worked with designers to implement new features']}],
    projects:[{name:'Task Tracker App',description:'A simple task manager with offline support and cloud sync.',technologies:['Flutter','Firebase'],url:'',githubUrl:'github.com/example/task-tracker'}],
    languages:[{name:'Bengali',proficiency:'Native'},{name:'English',proficiency:'Professional'}],
    certifications:[{name:'Flutter Development Course',organization:'Demo Academy',issueDate:'2022-01',credentialId:'',credentialUrl:''}],
    achievements:[{title:'Hackathon Finalist',description:'Reached the final round of a university hackathon.',date:'2021-11'}]});
    Object.assign(b.personalInfo,{fullName:'Alex Rahman',title:'Software Developer',phone:'+880 1700 000000',email:'alex.rahman@example.com',location:'Dhaka, Bangladesh',github:'github.com/example'})}
  else if(kind==='student'){Object.assign(b,{name:'Student CV (Demo)',templateId:'professional',summary:'Final-year student looking for an entry-level opportunity.',skills:['Communication','Teamwork','Microsoft Office'].map(n=>({name:n,level:''})),education:[{degree:'BBA',institution:'Demo College',field:'Marketing',startDate:'2020',endDate:'2024',grade:'CGPA 3.4',description:''}],languages:[{name:'Bengali',proficiency:'Native'},{name:'English',proficiency:'Fluent'}]});Object.assign(b.personalInfo,{fullName:'Sample Student',title:'BBA Student',email:'student@example.com',location:'Chattogram'})}
  else{Object.assign(b,{name:'Freelance CV (Demo)',templateId:'creative',summary:'Freelance graphic designer working with small businesses on branding and social media visuals.',skills:['Logo Design','Photoshop','Illustrator','Client Communication'].map(n=>({name:n,level:''})),experience:[{jobTitle:'Freelance Graphic Designer',company:'Self-employed',location:'Remote',startDate:'2021-01',endDate:'',current:true,description:['Designed logos and brand kits for local businesses','Created weekly social media graphics']}],projects:[{name:'Local Cafe Branding',description:'Logo, menu and signage design.',technologies:['Illustrator'],url:'',githubUrl:''}]});Object.assign(b.personalInfo,{fullName:'Sample Freelancer',title:'Graphic Designer',email:'freelancer@example.com',location:'Khulna'})}
  return migrate(b)}

/* ---------- plain text (share) ---------- */
function toText(cv){const p=cv.personalInfo,o=[p.fullName,p.title,[p.phone,p.email,p.location].filter(Boolean).join(' | ')].filter(Boolean);
  if(cv.summary.trim())o.push('','PROFESSIONAL SUMMARY',cv.summary.trim());
  if(cv.experience.length){o.push('','WORK EXPERIENCE');cv.experience.forEach(e=>{o.push(`${e.jobTitle} - ${e.company} (${[fmtMonth(e.startDate),e.current?'Present':fmtMonth(e.endDate)].filter(Boolean).join(' - ')})`);(e.description||[]).forEach(d=>o.push('- '+d))})}
  if(cv.education.length){o.push('','EDUCATION');cv.education.forEach(e=>o.push(`${e.degree}, ${e.institution} (${[e.startDate,e.endDate].filter(Boolean).join(' - ')})`))}
  if(cv.skills.length)o.push('','SKILLS',cv.skills.map(s=>s.name).join(', '));
  return o.join('\n')}

/* ---------- PDF / print ---------- */
function buildPrint(){
  if(!CUR.personalInfo.fullName.trim()){toast(t('Please enter your full name first.'),'err');R.step=0;ERR={'personalInfo.fullName':t('Full name is required.')};render();return 0}
  try{const pages=paginate(CUR),root=$('#printRoot');root.innerHTML='';pages.forEach(p=>{p.style.transform='none';root.appendChild(p)});return pages.length}
  catch(e){toast(t('PDF generation failed. Please try again.'),'err');return 0}}
function printNow(){const old=document.title;document.title=fname().replace(/\.pdf$/,'');setTimeout(()=>{try{window.print()}catch(e){toast(t('PDF generation failed. Please try again.'),'err')}document.title=old},150)}
addEventListener('afterprint',()=>{document.title='CV Maker'});

/* =====================================================================
   ACTIONS
   ===================================================================== */
function go(k,q){location.href=(SITE.pages[k]||'index.php')+(q||'')}
const ACT={
  jmRun(){jmRun()},
  jmTog(i){i=+i;const k=JM.sel.indexOf(i);k<0?JM.sel.push(i):JM.sel.splice(k,1);render()},
  jmSkills(){const cv=DB.cvs.find(c=>c.id===JM.cvId);if(!cv||!JM.res)return;let n=0;JM.sel.forEach(i=>{const nm=JM.res.missing[i];if(nm&&!cv.skills.some(s=>s.name.toLowerCase()===nm.toLowerCase())){cv.skills.push({name:nm,level:''});n++}});cv.updatedAt=Date.now();persist();const added=JM.sel.map(i=>JM.res.missing[i]);JM.res.matched=JM.res.matched.concat(added);JM.res.missing=JM.res.missing.filter((_,i)=>!JM.sel.includes(i));JM.sel=[];toast(n+' '+t('skills added'));render()},
  scanPick(){$('#scanFile').click()},
  scanCam(){$('#scanCam').click()},
  scanReset(){SC={s:'idle'};render()},
  scanCreate(){const c=SC.cv;if(!c)return;c.id=uid();c.name=(c.personalInfo.fullName||t('Scanned CV'))+' ('+t('Imported')+')';c.createdAt=c.updatedAt=Date.now();c.demo=false;DB.cvs.push(c);if(persist()){SC={s:'idle'};go('builder','?id='+encodeURIComponent(c.id))}},
  tab(v){go(v)},
  goHome(){go('home')},
  newCV(){go('builder','?new=1')},
  editCV(id){go('builder','?id='+encodeURIComponent(id))},
  exportCV(id){go('builder','?id='+encodeURIComponent(id)+'&step=last')},
  dupCV(id){const c=DB.cvs.find(x=>x.id===id);if(!c)return;const d=clone(c);d.id=uid();d.name=c.name+' (Copy)';d.createdAt=d.updatedAt=Date.now();DB.cvs.push(d);persist();toast(t('Duplicated.'));render()},
  delCV(id){const c=DB.cvs.find(x=>x.id===id);if(!c)return;confirmBox(t('Delete this CV?'),c.name+' — '+t('This cannot be undone.'),t('Delete'),()=>{DB.cvs=DB.cvs.filter(x=>x.id!==id);persist();closeModal();toast(t('Deleted.'));render()},true)},
  exitBuilder(){if(DIRTY&&!DB.settings.autoSave){CONFIRM=null;openModal(`<h3>${t('Save before leaving?')}</h3><div class="row"><button class="btn line" data-act="discardExit">${t('Discard')}</button><button class="btn" data-act="saveExit">${t('Save')}</button></div>`);return}
    if(DIRTY)commit();CUR=null;go('mycvs')},
  discardExit(){closeModal();DIRTY=false;CUR=null;go('mycvs')},
  saveExit(){closeModal();commit();CUR=null;go('mycvs')},
  saveCV(){clearTimeout(saveT);if(commit()){toast(t('Saved'));const b=$('.bstep');if(b)b.textContent=b.textContent.split(' · ')[0]}},
  gotoStep(i){R.step=+i;ERR={};render();window.scrollTo(0,0)},
  back(){if(R.step>0){R.step--;ERR={};render();window.scrollTo(0,0)}},
  next(){const key=STEPS[R.step][0],pre=STEP_PREFIX[key];
    if(pre){const all=collectErrors(CUR),E={};Object.keys(all).filter(k=>pre.some(p=>k.startsWith(p))).forEach(k=>E[k]=all[k]);
      if(Object.keys(E).length){ERR=E;keepScroll(render);toast(t('Please fix the highlighted fields.'),'err');const f=$('.fld.bad input,.fld.bad textarea');if(f)f.scrollIntoView({block:'center'});return}}
    ERR={};R.step=Math.min(R.step+1,STEPS.length-1);render();window.scrollTo(0,0)},
  add(arr){const C=ENT[arr];CUR[arr].push(C.mk());markDirty();render();const el=$(`#ent_${arr}_${CUR[arr].length-1}`);if(el)el.scrollIntoView({block:'start'})},
  del(arg){const[arr,i]=arg.split('|');confirmBox(t('Delete this entry?'),t('This cannot be undone.'),t('Delete'),()=>{CUR[arr].splice(+i,1);markDirty();closeModal();keepScroll(render)},true)},
  confirmOk(){const f=CONFIRM;CONFIRM=null;if(f)f()},
  closeModal,
  ovclick(a,b,e){if(e.target===b)closeModal()},
  photo(w){$(w==='cam'?'#photoCam':'#photoGal').click()},
  photoRemove(){CUR.personalInfo.photo='';markDirty();keepScroll(render)},
  addSkill(){const i=$('#skIn'),n=i.value.trim();if(!n){i.focus();return}if(CUR.skills.some(s=>s.name.toLowerCase()===n.toLowerCase())){i.value='';return}CUR.skills.push({name:n,level:$('#skLv').value});markDirty();keepScroll(render);const x=$('#skIn');if(x)x.focus()},
  delSkill(i){CUR.skills.splice(+i,1);markDirty();keepScroll(render)},
  async suggestSkills(){openModal(`<h3>${t('Suggested skills')}</h3><div class="spin"></div>`);
    try{const items=await AIService.suggestSkills(aiContext());showSuggestions(items)}catch(e){try{showSuggestions(await AIService.suggestSkills(aiContext(),true))}catch(e2){closeModal();toast(t('You appear to be offline.'),'err')}}},
  addSuggested(n,b){if(!CUR.skills.some(s=>s.name.toLowerCase()===n.toLowerCase()))CUR.skills.push({name:n,level:''});markDirty();b.remove();toast(t('Added.'));if(R.view==='builder'&&STEPS[R.step][0]==='skills')keepScroll(render)},
  async keywords(){openModal(`<h3>${t('Resume keywords')}</h3><div class="spin"></div>`);
    let items;try{items=await AIService.suggestKeywords(aiContext())}catch(e){items=await AIService.suggestKeywords(aiContext(),true)}
    openModal(`<h3>${t('Resume keywords')}</h3>${items.length?`<div class="sugs">${items.map(k=>`<span class="sug" style="display:inline-flex;align-items:center">${esc(k)}</span>`).join('')}</div><div class="note">${t('Use these only where they truthfully describe your experience.')}</div>`:`<p class="muted">${t('Nothing to suggest yet. Add more details first.')}</p>`}<div class="row"><button class="btn line" data-act="closeModal">${t('Close')}</button></div>`)},
  ai(arg){const[k,p]=arg.split('|');runAI(k,p)},
  aiLocal(arg){const[k,p]=arg.split('|');runAI(k,p,true)},
  aiApply(){const out=$('#aiOut');if(!out||!PENDING)return;const p=PENDING.path,v=out.value;setPath(CUR,p,Array.isArray(getPath(CUR,p))?v.split('\n').map(s=>s.trim()).filter(Boolean):v);PENDING=null;markDirty();closeModal();keepScroll(render)},
  assistant(){const opts=[['summary',t('Professional Summary')],...CUR.experience.map((e,i)=>[`experience.${i}.description`,`${t('Experience')}: ${e.jobTitle||'#'+(i+1)}`]),...CUR.projects.map((x,i)=>[`projects.${i}.description`,`${t('Project')}: ${x.name||'#'+(i+1)}`])];
    openModal(`<h3>${t('AI Resume Assistant')}</h3><div class="note">${t('AI suggestions should be reviewed before adding them to your CV.')}</div><div class="fld"><label for="aiT">${t('Improve a section')}</label><select id="aiT">${opts.map(([v,l])=>`<option value="${esc(v)}">${esc(l)}</option>`).join('')}</select></div><div class="sugs"><button class="sug" data-act="asst" data-arg="gen">${t('Generate Summary')}</button><button class="sug" data-act="asst" data-arg="improve">${t('Improve')}</button><button class="sug" data-act="asst" data-arg="shorten">${t('Shorten')}</button><button class="sug" data-act="asst" data-arg="professional">${t('Make Professional')}</button><button class="sug" data-act="asst" data-arg="grammar">${t('Fix Grammar')}</button></div><div class="sugs"><button class="sug" data-act="suggestSkills">${t('Suggest Skills')}</button><button class="sug" data-act="keywords">${t('Suggest Resume Keywords')}</button></div><div class="row"><button class="btn line" data-act="closeModal">${t('Close')}</button></div>`)},
  asst(k){const p=$('#aiT').value;if(k==='gen'&&p!=='summary'){toast(t('Add some text first.'),'err');return}runAI(k,p)},
  setTpl(id){CUR.templateId=id;if(!CUR.customization.accent){}markDirty();keepScroll(render)},
  resetAccent(){CUR.customization.accent='';markDirty();keepScroll(render)},
  setDefaultTpl(id){DB.settings.defaultTemplate=id;persist();render()},
  useTpl(id){const l=lastCV();if(!l){toast(t('Create a CV first to use this template.'),'err');return}const c=clone(l);c.templateId=id;c.updatedAt=Date.now();const i=DB.cvs.findIndex(x=>x.id===c.id);DB.cvs[i]=c;persist();go('builder','?id='+encodeURIComponent(c.id)+'&step='+(STEPS.length-2))},
  zoom(d){PV.zoom=d==='0'?1:Math.min(2.5,Math.max(.5,PV.zoom+(d==='+'?.25:-.25)));layoutPreview();pvInfo()},
  pvpage(d){const b=$('#pvs');if(!b)return;const h=1122*PV.s+12,i=Math.round(b.scrollTop/h)+ +d;b.scrollTo({top:Math.max(0,Math.min(PV.pages.length-1,i))*h,behavior:'smooth'})},
  pvfs(){const p=$('#pv');if(!p)return;p.classList.toggle('fs');document.body.style.overflow=p.classList.contains('fs')?'hidden':'';setTimeout(()=>{layoutPreview();pvInfo()},30)},
  genPDF(){const n=buildPrint();if(n)toast(`${fname()} · ${n} ${t('pages')} · ${t('ready')}`)},
  download(){if(buildPrint()){toast(t('Choose "Save as PDF" in the print window.'));printNow()}},
  print(){if(buildPrint())printNow()},
  async share(){const text=toText(CUR);try{if(navigator.share)await navigator.share({title:fname(),text});else{await navigator.clipboard.writeText(text);toast(t('Copied to clipboard.'))}}catch(e){if(e&&e.name!=='AbortError')toast(t('Could not share.'),'err')}},
  obNext(){if(R.ob<2){R.ob++;render()}else ACT.obSkip()},
  obSkip(){DB.settings.onboarded=true;persist();R={view:'home',step:0,ob:0};render()},
  addExample(k){const kinds=k==='all'?['dev','student','freelance']:[k];kinds.forEach(x=>{const s=sample(x);s.id=uid();s.createdAt=s.updatedAt=Date.now();DB.cvs.push(s)});persist();toast(t('Example CVs added (demo data).'));render()},
  exportBackup(){try{const blob=new Blob([JSON.stringify({app:'cvmaker',version:1,cvs:DB.cvs,settings:{...DB.settings,aiProxy:''}})],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='cv-maker-backup.json';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),4000)}catch(e){toast(t('Backup could not be exported.'),'err')}},
  importBackup(){$('#importFile').click()},
  wipe(){confirmBox(t('Delete ALL CVs and settings?'),t('This cannot be undone.'),t('Delete all data'),()=>{try{localStorage.removeItem(KEY)}catch(e){}DB.cvs=[];Object.assign(DB.settings,{lang:'en',theme:'system',defaultTemplate:'modern',autoSave:true,onboarded:true,aiProxy:''});persist();closeModal();render()},true)}
};
function showSuggestions(items){openModal(`<h3>${t('Suggested skills')}</h3>${items.length?`<div class="sugs">${items.map(s=>`<button class="sug" data-act="addSuggested" data-arg="${esc(s)}">+ ${esc(s)}</button>`).join('')}</div>`:`<p class="muted">${t('No new suggestions for now. Add a professional title first.')}</p>`}<div class="note">${t('Only add skills you genuinely have.')}</div><div class="row"><button class="btn line" data-act="closeModal">${t('Close')}</button></div>`)}

/* =====================================================================
   EVENTS
   ===================================================================== */
document.addEventListener('click',e=>{const b=e.target.closest('[data-act]');if(!b)return;const f=ACT[b.dataset.act];if(f){try{f(b.dataset.arg,b,e)}catch(err){toast(t('Something went wrong'),'err')}}});
function onField(e){const el=e.target;
  if(el.hasAttribute&&el.hasAttribute('data-q')){Q=el.value;$('#cvlist').innerHTML=cvCards();fitThumbs();return}
  if(el.hasAttribute&&el.hasAttribute('data-sort')){SORT=el.value;$('#cvlist').innerHTML=cvCards();fitThumbs();return}
  if(el.dataset&&el.dataset.set){DB.settings[el.dataset.set]=el.value;persist();if(['lang','theme','defaultTemplate'].includes(el.dataset.set))keepScroll(render);return}
  if(el.dataset&&el.dataset.setchk){DB.settings[el.dataset.setchk]=el.checked;persist();return}
  if(el.dataset&&el.dataset.aiurl!==undefined&&e.type==='change'){const v=el.value.trim();if(v&&!/^https:\/\//i.test(v)){toast(t('AI service URL must start with https://'),'err');el.value=DB.settings.aiProxy;return}DB.settings.aiProxy=v;persist();return}
  const path=el.dataset&&el.dataset.path;if(!path||!CUR)return;
  let v=el.type==='checkbox'?el.checked:el.value;
  if(el.dataset.kind==='bullets')v=v.split('\n').map(s=>s.trim()).filter(Boolean);
  if(el.dataset.kind==='csv')v=v.split(',').map(s=>s.trim()).filter(Boolean);
  setPath(CUR,path,v);
  const msg=el.type==='checkbox'?'':validate(path,Array.isArray(v)?v.join(','):v);
  const eb=$(`[data-err="${path}"]`);if(eb){eb.textContent=msg;eb.parentElement.classList.toggle('bad',!!msg)}
  if(msg)ERR[path]=msg;else delete ERR[path];
  if(/\.current$/.test(path)){const end=$(`[data-path="${path.replace(/current$/,'endDate')}"]`);if(end){end.disabled=v;if(v){end.value='';setPath(CUR,path.replace(/current$/,'endDate'),'')}}}
  markDirty();refreshPreview()}
document.addEventListener('input',onField);document.addEventListener('change',onField);
document.addEventListener('keydown',e=>{
  if(e.key==='Escape'&&$('#modal').firstChild)closeModal();
  if(e.key==='Enter'&&e.target.id==='skIn'){e.preventDefault();ACT.addSkill()}});
document.addEventListener('input',e=>{if(e.target.id==='jmJob')JM.job=e.target.value});
document.addEventListener('change',e=>{if(e.target.id==='scanLang')SCLANG=e.target.value;if(e.target.id==='jmCv'){JM.cvId=e.target.value;JM.res=null;JM.s='idle'}});
['scanFile','scanCam'].forEach(i=>$('#'+i).addEventListener('change',e=>{const f=e.target.files[0];e.target.value='';scanFile(f)}));
addEventListener('dragover',e=>{if(R.view==='scan')e.preventDefault()});
addEventListener('drop',e=>{if(R.view==='scan'){e.preventDefault();scanFile(e.dataTransfer.files[0])}});
$('#photoCam').addEventListener('change',e=>{handlePhoto(e.target.files[0]);e.target.value=''});
$('#photoGal').addEventListener('change',e=>{handlePhoto(e.target.files[0]);e.target.value=''});
$('#importFile').addEventListener('change',e=>{const f=e.target.files[0];e.target.value='';if(!f)return;const r=new FileReader();
  r.onerror=()=>toast(t('Could not import this file.'),'err');
  r.onload=()=>{try{const d=JSON.parse(r.result);if(!d||!Array.isArray(d.cvs))throw 0;d.cvs.forEach(c=>{const m=migrate(c);m.id=uid();DB.cvs.push(m)});persist();toast(t('Backup imported.'));render()}catch(x){toast(t('Could not import this file.'),'err')}};r.readAsText(f)});
function handlePhoto(file){if(!file)return;
  if(!/^image\//.test(file.type)){toast(t('Please choose an image file.'),'err');return}
  const fr=new FileReader();fr.onerror=()=>toast(t('Could not load the image.'),'err');
  fr.onload=()=>{const img=new Image();img.onerror=()=>toast(t('Could not load the image.'),'err');
    img.onload=()=>{try{const S=480,c=document.createElement('canvas');c.width=c.height=S;const m=Math.min(img.width,img.height),x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,S,S);x.drawImage(img,(img.width-m)/2,(img.height-m)/2,m,m,0,0,S,S);CUR.personalInfo.photo=c.toDataURL('image/jpeg',.82);markDirty();keepScroll(render)}catch(e){toast(t('Could not load the image.'),'err')}};
    img.src=fr.result};fr.readAsDataURL(file)}
addEventListener('resize',()=>{fitThumbs();layoutPreview();pvInfo()});
addEventListener('pagehide',()=>{if(CUR&&DIRTY&&DB.settings.autoSave)commit()});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&CUR&&DIRTY&&DB.settings.autoSave)commit()});
addEventListener('error',()=>toast(t('Something went wrong'),'err'));
addEventListener('unhandledrejection',()=>toast(t('Something went wrong'),'err'));
matchMedia('(prefers-color-scheme: dark)').addEventListener&&matchMedia('(prefers-color-scheme: dark)').addEventListener('change',()=>{if(DB.settings.theme==='system')applyTheme()});

/* ---------- boot ---------- */
addEventListener('beforeunload',e=>{if(CUR&&DIRTY&&!DB.settings.autoSave){e.preventDefault();e.returnValue=''}});
load();
(function(){const P=SITE.page;
if(P==='builder'){const q=new URLSearchParams(location.search),id=q.get('id');let cv=id&&DB.cvs.find(c=>c.id===id);if(!cv)cv=blankCV();
const s=q.get('step');openCV(cv,s==='last'?STEPS.length-1:Math.max(0,Math.min(STEPS.length-1,+s||0)))}
else{R={view:P,step:0,ob:0};render()}})();
