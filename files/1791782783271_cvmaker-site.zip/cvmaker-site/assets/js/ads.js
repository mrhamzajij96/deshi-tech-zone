/* =====================================================================
   ADS - the only file you need to edit to change ad codes.
   ---------------------------------------------------------------------
   HOW TO CHANGE AN AD
   1. Find the slot below (footer / top / content) or the socialBar.
   2. Replace the key / src / html with your new code.
   3. Set enabled: true.  Save, upload this file. Done.

   HOW TO ADD ANOTHER BANNER
   Copy one block inside "banners", give it a new id, set "where".

   WHERE VALUES  (position + CSS selector)
     'before:.site-footer'   put the ad before the footer
     'after:.site-header'    put the ad after the header
     'prepend:main'          first thing inside <main>
     'append:main'           last thing inside <main>

   TURN OFF EVERYTHING: set enabled: false below
   (or set ADS_ENABLED to false in includes/config.php).
   ===================================================================== */
(function () {
  'use strict';

  var ADS = {
    enabled: true,

    // true = show dashed "Ad space" boxes where ads go (handy for design preview)
    showPlaceholders: false,

    /* ---------- SOCIAL BAR (loads on the page itself) ---------- */
    socialBar: {
      enabled: true,
      src: 'https://pl31737997.profitableratecpmnetwork.com/23/7d/af/237daf6e3d4c270d523bf4ca9a1f8f35.js',
      // null = every page, or a list such as ['home', 'templates']
      pages: null
    },

    /* ---------- BANNERS (each runs in a safe sandboxed frame) ---------- */
    banners: [

      {
        id: 'footer',
        enabled: true,
        where: 'before:.site-footer',
        pages: null,                      // null = every page
        type: 'adsterra',                 // 'adsterra' = key + src below, 'html' = paste any code
        key: 'a5a897b0d96f03db9301d40f92cd2fa3',
        src: 'https://www.highrevenueformat.com/a5a897b0d96f03db9301d40f92cd2fa3/invoke.js',
        width: 320,
        height: 50
      },

      {
        id: 'top',
        enabled: false,                   // <- set true after adding your code
        where: 'prepend:main',
        pages: ['home', 'templates'],
        type: 'adsterra',
        key: 'YOUR_BANNER_KEY',
        src: 'https://www.highrevenueformat.com/YOUR_BANNER_KEY/invoke.js',
        width: 728,
        height: 90                        // hidden automatically on screens narrower than 748px
      },

      {
        id: 'content',
        enabled: false,
        where: 'append:main',
        pages: ['mycvs', 'scan', 'match'],
        type: 'html',                     // paste any ad network code between the backticks
        html: `
          <!-- PASTE YOUR AD CODE HERE -->
        `,
        width: 300,
        height: 250
      }

    ]
  };

  /* ===================== engine (no need to edit below) ===================== */
  if (!ADS.enabled || window.__cvAds) return;
  window.__cvAds = true;

  var page = (window.SITE && window.SITE.page) || '';
  var isPlaceholder = function (v) { return !v || /YOUR_/i.test(v); };
  var allowed = function (pages) { return !pages || pages.indexOf(page) !== -1; };

  function place(el, where) {
    var p = String(where).split(':'), mode = p[0], target = document.querySelector(p.slice(1).join(':'));
    if (!target) return false;
    if (mode === 'before') target.parentNode.insertBefore(el, target);
    else if (mode === 'after') target.parentNode.insertBefore(el, target.nextSibling);
    else if (mode === 'prepend') target.insertBefore(el, target.firstChild);
    else target.appendChild(el);
    return true;
  }

  function docFor(b) {
    var head = '<!doctype html><html><head><meta charset="utf-8"><style>html,body{margin:0;padding:0;overflow:hidden;background:transparent}</style></head><body>';
    if (b.type === 'html') return head + (b.html || '') + '</body></html>';
    return head +
      '<script>atOptions={"key":"' + b.key + '","format":"iframe","height":' + b.height + ',"width":' + b.width + ',"params":{}};<\/script>' +
      '<script src="' + b.src + '"><\/script></body></html>';
  }

  function isLive(b) {
    return b.type === 'html' ? !!(b.html && b.html.replace(/<!--[\s\S]*?-->/g, '').trim()) : !isPlaceholder(b.key);
  }

  function addBanner(b) {
    if (!allowed(b.pages)) return;
    if (window.innerWidth < b.width + 20) return;          // too wide for this screen
    if (document.querySelector('[data-ad="' + b.id + '"]')) return;

    var live = b.enabled && isLive(b);
    if (!live && !ADS.showPlaceholders) return;

    var box = document.createElement('div');
    box.className = 'ad-slot';
    box.setAttribute('data-ad', b.id);

    var label = document.createElement('span');
    label.className = 'ad-label';
    label.textContent = 'Advertisement';
    box.appendChild(label);

    if (live) {
      // Sandboxed: the ad code cannot read this site's storage (visitors' saved CVs).
      var f = document.createElement('iframe');
      f.width = b.width;
      f.height = b.height;
      f.title = 'Advertisement';
      f.loading = 'lazy';
      f.setAttribute('scrolling', 'no');
      f.setAttribute('sandbox', 'allow-scripts allow-popups allow-popups-to-escape-sandbox allow-top-navigation-by-user-activation');
      f.srcdoc = docFor(b);
      box.appendChild(f);
    } else {
      var ph = document.createElement('div');
      ph.className = 'ad-ph';
      ph.style.width = b.width + 'px';
      ph.style.maxWidth = '100%';
      ph.style.height = b.height + 'px';
      ph.innerHTML = '<b>Ad space</b><span>' + b.width + ' x ' + b.height + ' &middot; ' + b.id + '</span>';
      box.appendChild(ph);
    }
    if (!place(box, b.where)) box.remove();
  }

  function addSocialBar() {
    var s = ADS.socialBar;
    if (!s || !s.enabled || isPlaceholder(s.src) || !allowed(s.pages)) return;
    var el = document.createElement('script');
    el.src = s.src;
    el.async = true;
    document.body.appendChild(el);
  }

  function run() {
    ADS.banners.forEach(addBanner);
    setTimeout(addSocialBar, 400);
  }

  if (document.readyState === 'complete') run();
  else window.addEventListener('load', run);
})();
