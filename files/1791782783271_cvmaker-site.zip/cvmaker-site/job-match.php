<?php
define('CV_SITE', 1);
require __DIR__ . '/includes/config.php';
$view  = 'match';
$title = 'Match CV to a Job';
$desc  = 'Paste a job description and see how well your CV matches, which keywords are missing and how to improve it.';
require __DIR__ . '/includes/header.php';
?>
<main id="content"><div id="app"></div></main>
<?php require __DIR__ . '/includes/footer.php'; ?>
