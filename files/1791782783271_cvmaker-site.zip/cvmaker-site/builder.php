<?php
define('CV_SITE', 1);
require __DIR__ . '/includes/config.php';
$view    = 'builder';
$title   = 'CV Builder';
$desc    = 'Fill in simple steps and watch your CV update live.';
$noindex = true;
require __DIR__ . '/includes/header.php';
?>
<main id="content"><div id="app"></div></main>
<?php require __DIR__ . '/includes/footer.php'; ?>
