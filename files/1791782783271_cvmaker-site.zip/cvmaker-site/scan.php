<?php
define('CV_SITE', 1);
require __DIR__ . '/includes/config.php';
$view  = 'scan';
$title = 'Scan Old CV';
$desc  = 'Upload a photo or PDF of your old CV and let AI fill in a new, editable CV for you.';
require __DIR__ . '/includes/header.php';
?>
<main id="content"><div id="app"></div></main>
<?php require __DIR__ . '/includes/footer.php'; ?>
