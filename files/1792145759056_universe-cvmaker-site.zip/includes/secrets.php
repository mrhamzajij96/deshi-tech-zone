<?php
defined('CV_SITE') || exit;

return [
    'gemini_key'   => 'AQ.Ab8RN6IVquNqA-OjDUHYAn6KbQSqiI9oMfSStKQE2wrb-cd6zA',
    'model'        => 'gemini-1.5-flash',
    'daily_limit'  => 100, // দিনে ১০০টি কল
    'minute_limit' => 15,  // ফ্রি টায়ারের লিমিট অনুযায়ী মিনিটে ১৫টি
];