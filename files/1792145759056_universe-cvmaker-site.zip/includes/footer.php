<?php defined('CV_SITE') || exit; ?>
<footer class="site-footer">
  <div class="wrap foot-grid">
    <div>
      <a class="brand" href="index.php"><img class="logo-img" src="assets/img/logo.png?v=2" alt="Logo" width="36" height="36"><span><?= e(SITE_NAME) ?></span></a>
      <p class="muted" style="margin-top:10px;max-width:320px">Build. Improve. Export. Get Ready.<br>Your CVs are stored in your browser, never on our server.</p>
    </div>
    <div>
      <h4>Product</h4>
      <a href="builder.php?new=1">Create a CV</a>
      <a href="templates.php">Templates</a>
      <a href="my-cvs.php">My CVs</a>
    </div>
    <div>
      <h4>Account</h4>
      <a href="settings.php">Settings</a>
      <a href="settings.php">Backup &amp; restore</a>
      <a href="index.php#faq">Help &amp; FAQ</a>
    </div>
  </div>
  <div class="wrap copy">&copy; <?= date('Y') ?> <?= e(SITE_NAME) ?>. All rights reserved.</div>
</footer>

<div id="modal"></div>
<div id="toast" role="status" aria-live="polite"></div>
<div id="printRoot"></div>
<div id="fileHost">
  <input type="file" id="photoCam" accept="image/*" capture="user">
  <input type="file" id="photoGal" accept="image/*">
  <input type="file" id="scanFile" accept="image/*,application/pdf">
  <input type="file" id="scanCam" accept="image/*" capture="environment">
  <input type="file" id="importFile" accept="application/json,.json">
</div>
<script>window.SITE=<?= json_encode(['page' => $view, 'pages' => js_pages(), 'ai' => ai_enabled() ? 'api/ai.php' : ''], JSON_UNESCAPED_SLASHES) ?>;</script>
<script src="<?= e(asset('js/app.js')) ?>"></script>
<?php if (ADS_ENABLED): ?><script src="<?= e(asset('js/ads.js')) ?>" defer></script><?php endif; ?>
<script>
(function(){var b=document.getElementById('menuBtn'),n=document.getElementById('mainNav');
b.addEventListener('click',function(){var o=n.classList.toggle('open');b.classList.toggle('x',o);b.setAttribute('aria-expanded',o)});
var hd=document.querySelector('.site-header');function sc(){hd.classList.toggle('scrolled',scrollY>8)}sc();addEventListener('scroll',sc,{passive:true});
var q=document.querySelectorAll('.feat,.steps li,.tpl,.faq details,.cta-band,.lp-title,#saved .wrap');
if('IntersectionObserver' in window&&!matchMedia('(prefers-reduced-motion: reduce)').matches){
var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}})},{threshold:.12,rootMargin:'0px 0px -6% 0px'});
q.forEach(function(el,i){el.classList.add('rv');el.style.transitionDelay=(i%3)*70+'ms';io.observe(el)})}
})();
</script>
</body>
</html>